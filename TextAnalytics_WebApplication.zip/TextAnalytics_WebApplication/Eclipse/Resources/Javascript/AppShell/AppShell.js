/*
Copyright(c) 2012 Verint Systems
*/
/**
 * Copyright 2009 Tim Down.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
Ext.define("AppShell.util.log4javascript", {});
Ext.define("AppShell.util.PluggableServices", {});

/**
 * log4javascript
 *
 * log4javascript is a logging framework for JavaScript based on log4j
 * for Java. This file contains all core log4javascript code and is the only
 * file required to use log4javascript, unless you require support for
 * document.domain, in which case you will also need console.html, which must be
 * stored in the same directory as the main log4javascript.js file.
 *
 * Author: Tim Down <tim@log4javascript.org>
 * Version: 1.4.2
 * Edition: log4javascript
 * Build date: 14 October 2011
 * Website: http://log4javascript.org
 */

/**
 * @class log4javascript.Logger 
 * @see http://log4javascript.org/docs/manual.html
 */
/**
 * 
 *@method addAppender
 * @param {log4javascript.Appender} appender
 * Adds the given appender.
 */

/**
 *@method removeAppender
 * @param {log4javascript.Appender} appender
 * Removes the given appender.
 */    

/**
 *@method removeAllAppenders
 *     Clears all appenders for the current logger.
 */

/**
 *@method setLevel
 * @param {log4javascript.Level} level
 *     Sets the level. Log messages of a lower level than level will not be logged. Default value is DEBUG.
 */

/**
 *@method getLevel
 *
 * @returns {log4javascript.Level} the level explicitly set for this logger or null if none has been set.
 */

/**
 *@method getEffectiveLevel
 *     @returns {log4javascript.Level} the level at which the logger is operating. This is either the level explicitly set on the logger or, if no level has been set, the effective level of the logger's parent.
 */    

/**
 *@method setAdditivity
 * @param {Boolean} additivity
 *     Sets whether appender additivity is enabled (the default) or disabled. If set to false, this particular logger will not inherit any appenders form its ancestors. Any descendant of this logger, however, will inherit from its ancestors as normal, unless its own additivity is explicitly set to false.
 * 
 * Default value is true.
 */    
 
 /**
  *@method getAdditivity
  * @returns {Boolean} whether additivity is enabled for this logger. 
  */
 
 /**
  *@method log
  * @param {log4javascript.Level} level
  * @param {Object} params 
  * Generic logging method used by wrapper methods such as debug, error etc.
  */
 
 /**
  * @method trace
  * @param {Object...} message
  * @param {Error} exception (optional)
  * Logs one or more messages and optionally an error at level TRACE. 
  */
 /**
  * @method debug
  * @param {Object...} message
  * @param {Error} exception (optional)
  * Logs one or more messages and optionally an error at level DEBUG. 
  */
 /**
  * @method warn
  * @param {Object...} message
  * @param {Error} exception (optional)
  * Logs one or more messages and optionally an error at level WARN. 
  */
 /**
  * @method info
  * @param {Object...} message
  * @param {Error} exception (optional)
  * Logs one or more messages and optionally an error at level INFO. 
  */
 /**
  * @method error
  * @param {Object...} message
  * @param {Error} exception (optional)
  * Logs one or more messages and optionally an error at level ERROR. 
  */
 /**
  * @method fatal
  * @param {Object...} message
  * @param {Error} exception (optional)
  * Logs one or more messages and optionally an error at level FATAL. 
  */

/**
 *@method isEnabledFor
 * @param {log4javascript.Level} level
 * @param {Error} exception
 * @returns {Boolean} whether the logger is enabled for the specified level.
 */ 

/**
 * @method isTraceEnabled
 * @returns {Boolean} whether the logger is enabled for TRACE messages  
 */
 
/**
 * @method isDebugEnabled
 * @returns {Boolean} whether the logger is enabled for DEBUG messages  
 */
 
/**
 * @method isInfoEnabled
 * @returns {Boolean} whether the logger is enabled for INFO messages  
 */
 
/**
 * @method isWarnEnabled
 * @returns {Boolean} whether the logger is enabled for WARN messages  
 */
 
/**
 * @method isErrorEnabled
 * @returns {Boolean} whether the logger is enabled for ERROR messages  
 */
 
/**
 * @method isFatalEnabled
 * @returns {Boolean} whether the logger is enabled for FATAL messages  
 */

/**
 *@method group
 * @param {String} name
 * @param {Boolean} initiallyExpanded (optional)
 *  Starts a new group of log messages. In appenders that support grouping (currently PopUpAppender and InPageAppender), a group appears as an expandable section in the console, labelled with the name specified. Specifying initiallyExpanded determines whether the group starts off expanded (the default is true). Groups may be nested.
 */
 
 /**
  * @method groupEnd
  *  Ends the current group. If there is no group then this function has no effect.
  */

/**
 *@method time
 * @param {String} name
 * @param {log4javascript.Level} level (optional)
 * Starts a timer with name name. When the timer is ended with a call to timeEnd using the same name, the amount of time that has elapsed in milliseconds since the timer was started is logged at level level. If not level is supplied, the level defaults to INFO. 
 */

/**
 *@method timeEnd
 * @param {String} name
 * Ends the timer with name name and logs the time elapsed. 
 */
 
 /**
  *@method assert
  * @param {Object} expr
  * Asserts the given expression is true or evaluates to true. If so, nothing is logged. If not, an error is logged at the ERROR level. 
  */
    


/* -------------------------------------------------------------------------- */
// Array-related stuff

// Next three methods are solely for IE5, which is missing them
if (!Array.prototype.push) {
	Array.prototype.push = function() {
		for (var i = 0, len = arguments.length; i < len; i++){
			this[this.length] = arguments[i];
		}
		return this.length;
	};
}

if (!Array.prototype.shift) {
	Array.prototype.shift = function() {
		if (this.length > 0) {
			var firstItem = this[0];
			for (var i = 0, len = this.length - 1; i < len; i++) {
				this[i] = this[i + 1];
			}
			this.length = this.length - 1;
			return firstItem;
		}
	};
}

if (!Array.prototype.splice) {
	Array.prototype.splice = function(startIndex, deleteCount) {
		var itemsAfterDeleted = this.slice(startIndex + deleteCount);
		var itemsDeleted = this.slice(startIndex, startIndex + deleteCount);
		this.length = startIndex;
		// Copy the arguments into a proper Array object
		var argumentsArray = [];
		for (var i = 0, len = arguments.length; i < len; i++) {
			argumentsArray[i] = arguments[i];
		}
		var itemsToAppend = (argumentsArray.length > 2) ?
			itemsAfterDeleted = argumentsArray.slice(2).concat(itemsAfterDeleted) : itemsAfterDeleted;
		for (i = 0, len = itemsToAppend.length; i < len; i++) {
			this.push(itemsToAppend[i]);
		}
		return itemsDeleted;
	};
}

/* -------------------------------------------------------------------------- */

var log4javascript = (function() {

	function isUndefined(obj) {
		return typeof obj == "undefined";
	}

	/* ---------------------------------------------------------------------- */
	// Custom event support

	function EventSupport() {}

	EventSupport.prototype = {
		eventTypes: [],
		eventListeners: {},
		setEventTypes: function(eventTypesParam) {
			if (eventTypesParam instanceof Array) {
				this.eventTypes = eventTypesParam;
				this.eventListeners = {};
				for (var i = 0, len = this.eventTypes.length; i < len; i++) {
					this.eventListeners[this.eventTypes[i]] = [];
				}
			} else {
				handleError("log4javascript.EventSupport [" + this + "]: setEventTypes: eventTypes parameter must be an Array");
			}
		},

		addEventListener: function(eventType, listener) {
			if (typeof listener == "function") {
				if (!array_contains(this.eventTypes, eventType)) {
					handleError("log4javascript.EventSupport [" + this + "]: addEventListener: no event called '" + eventType + "'");
				}
				this.eventListeners[eventType].push(listener);
			} else {
				handleError("log4javascript.EventSupport [" + this + "]: addEventListener: listener must be a function");
			}
		},

		removeEventListener: function(eventType, listener) {
			if (typeof listener == "function") {
				if (!array_contains(this.eventTypes, eventType)) {
					handleError("log4javascript.EventSupport [" + this + "]: removeEventListener: no event called '" + eventType + "'");
				}
				array_remove(this.eventListeners[eventType], listener);
			} else {
				handleError("log4javascript.EventSupport [" + this + "]: removeEventListener: listener must be a function");
			}
		},

		dispatchEvent: function(eventType, eventArgs) {
			if (array_contains(this.eventTypes, eventType)) {
				var listeners = this.eventListeners[eventType];
				for (var i = 0, len = listeners.length; i < len; i++) {
					listeners[i](this, eventType, eventArgs);
				}
			} else {
				handleError("log4javascript.EventSupport [" + this + "]: dispatchEvent: no event called '" + eventType + "'");
			}
		}
	};

	/* -------------------------------------------------------------------------- */

	var applicationStartDate = new Date();
	var uniqueId = "log4javascript_" + applicationStartDate.getTime() + "_" +
		Math.floor(Math.random() * 100000000);
	var emptyFunction = function() {};
	var newLine = "\r\n";
	var pageLoaded = false;

	// Create main log4javascript object; this will be assigned public properties
	function Log4JavaScript() {}
	Log4JavaScript.prototype = new EventSupport();

	log4javascript = new Log4JavaScript();
	log4javascript.version = "1.4.2";
	log4javascript.edition = "log4javascript";

	/* -------------------------------------------------------------------------- */
	// Utility functions

	function toStr(obj) {
		if (obj && obj.toString) {
			return obj.toString();
		} else {
			return String(obj);
		}
	}

	function getExceptionMessage(ex) {
		if (ex.message) {
			return ex.message;
		} else if (ex.description) {
			return ex.description;
		} else {
			return toStr(ex);
		}
	}

	// Gets the portion of the URL after the last slash
	function getUrlFileName(url) {
		var lastSlashIndex = Math.max(url.lastIndexOf("/"), url.lastIndexOf("\\"));
		return url.substr(lastSlashIndex + 1);
	}

	// Returns a nicely formatted representation of an error
	function getExceptionStringRep(ex) {
		if (ex) {
			var exStr = "Exception: " + getExceptionMessage(ex);
			try {
				if (ex.lineNumber) {
					exStr += " on line number " + ex.lineNumber;
				}
				if (ex.fileName) {
					exStr += " in file " + getUrlFileName(ex.fileName);
				}
			} catch (localEx) {
				logLog.warn("Unable to obtain file and line information for error");
			}
			if (showStackTraces && ex.stack) {
				exStr += newLine + "Stack trace:" + newLine + ex.stack;
			}
			return exStr;
		}
		return null;
	}

	function bool(obj) {
		return Boolean(obj);
	}

	function trim(str) {
		return str.replace(/^\s+/, "").replace(/\s+$/, "");
	}

	function splitIntoLines(text) {
		// Ensure all line breaks are \n only
		var text2 = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
		return text2.split("\n");
	}

	var urlEncode = (typeof window.encodeURIComponent != "undefined") ?
		function(str) {
			return encodeURIComponent(str);
		}: 
		function(str) {
			return escape(str).replace(/\+/g, "%2B").replace(/"/g, "%22").replace(/'/g, "%27").replace(/\//g, "%2F").replace(/=/g, "%3D");
		};

	var urlDecode = (typeof window.decodeURIComponent != "undefined") ?
		function(str) {
			return decodeURIComponent(str);
		}: 
		function(str) {
			return unescape(str).replace(/%2B/g, "+").replace(/%22/g, "\"").replace(/%27/g, "'").replace(/%2F/g, "/").replace(/%3D/g, "=");
		};

	function array_remove(arr, val) {
		var index = -1;
		for (var i = 0, len = arr.length; i < len; i++) {
			if (arr[i] === val) {
				index = i;
				break;
			}
		}
		if (index >= 0) {
			arr.splice(index, 1);
			return true;
		} else {
			return false;
		}
	}

	function array_contains(arr, val) {
		for(var i = 0, len = arr.length; i < len; i++) {
			if (arr[i] == val) {
				return true;
			}
		}
		return false;
	}

	function extractBooleanFromParam(param, defaultValue) {
		if (isUndefined(param)) {
			return defaultValue;
		} else {
			return bool(param);
		}
	}

	function extractStringFromParam(param, defaultValue) {
		if (isUndefined(param)) {
			return defaultValue;
		} else {
			return String(param);
		}
	}

	function extractIntFromParam(param, defaultValue) {
		if (isUndefined(param)) {
			return defaultValue;
		} else {
			try {
				var value = parseInt(param, 10);
				return isNaN(value) ? defaultValue : value;
			} catch (ex) {
				logLog.warn("Invalid int param " + param, ex);
				return defaultValue;
			}
		}
	}

	function extractFunctionFromParam(param, defaultValue) {
		if (typeof param == "function") {
			return param;
		} else {
			return defaultValue;
		}
	}

	function isError(err) {
		return (err instanceof Error);
	}

	if (!Function.prototype.apply){
		Function.prototype.apply = function(obj, args) {
			var methodName = "__apply__";
			if (typeof obj[methodName] != "undefined") {
				methodName += String(Math.random()).substr(2);
			}
			obj[methodName] = this;

			var argsStrings = [];
			for (var i = 0, len = args.length; i < len; i++) {
				argsStrings[i] = "args[" + i + "]";
			}
			var script = "obj." + methodName + "(" + argsStrings.join(",") + ")";
			var returnValue = eval(script);
			delete obj[methodName];
			return returnValue;
		};
	}

	if (!Function.prototype.call){
		Function.prototype.call = function(obj) {
			var args = [];
			for (var i = 1, len = arguments.length; i < len; i++) {
				args[i - 1] = arguments[i];
			}
			return this.apply(obj, args);
		};
	}

	function getListenersPropertyName(eventName) {
		return "__log4javascript_listeners__" + eventName;
	}

	function addEvent(node, eventName, listener, useCapture, win) {
		win = win ? win : window;
		if (node.addEventListener) {
			node.addEventListener(eventName, listener, useCapture);
		} else if (node.attachEvent) {
			node.attachEvent("on" + eventName, listener);
		} else {
			var propertyName = getListenersPropertyName(eventName);
			if (!node[propertyName]) {
				node[propertyName] = [];
				// Set event handler
				node["on" + eventName] = function(evt) {
					evt = getEvent(evt, win);
					var listenersPropertyName = getListenersPropertyName(eventName);

					// Clone the array of listeners to leave the original untouched
					var listeners = this[listenersPropertyName].concat([]);
					var currentListener;

					// Call each listener in turn
					while ((currentListener = listeners.shift())) {
						currentListener.call(this, evt);
					}
				};
			}
			node[propertyName].push(listener);
		}
	}

	function removeEvent(node, eventName, listener, useCapture) {
		if (node.removeEventListener) {
			node.removeEventListener(eventName, listener, useCapture);
		} else if (node.detachEvent) {
			node.detachEvent("on" + eventName, listener);
		} else {
			var propertyName = getListenersPropertyName(eventName);
			if (node[propertyName]) {
				array_remove(node[propertyName], listener);
			}
		}
	}

	function getEvent(evt, win) {
		win = win ? win : window;
		return evt ? evt : win.event;
	}

	function stopEventPropagation(evt) {
		if (evt.stopPropagation) {
			evt.stopPropagation();
		} else if (typeof evt.cancelBubble != "undefined") {
			evt.cancelBubble = true;
		}
		evt.returnValue = false;
	}

	/* ---------------------------------------------------------------------- */
	// Simple logging for log4javascript itself

	var logLog = {
		quietMode: false,

		debugMessages: [],

		setQuietMode: function(quietMode) {
			this.quietMode = bool(quietMode);
		},

		numberOfErrors: 0,

		alertAllErrors: false,

		setAlertAllErrors: function(alertAllErrors) {
			this.alertAllErrors = alertAllErrors;
		},

		debug: function(message) {
			this.debugMessages.push(message);
		},

		displayDebug: function() {
			alert(this.debugMessages.join(newLine));
		},

		warn: function(message, exception) {
		},

		error: function(message, exception) {
			if (++this.numberOfErrors == 1 || this.alertAllErrors) {
				if (!this.quietMode) {
					var alertMessage = "log4javascript error: " + message;
					if (exception) {
						alertMessage += newLine + newLine + "Original error: " + getExceptionStringRep(exception);
					}
					alert(alertMessage);
				}
			}
		}
	};
	log4javascript.logLog = logLog;

	log4javascript.setEventTypes(["load", "error"]);

	function handleError(message, exception) {
		logLog.error(message, exception);
		log4javascript.dispatchEvent("error", { "message": message, "exception": exception });
	}

	log4javascript.handleError = handleError;

	/* ---------------------------------------------------------------------- */

	var enabled = !((typeof log4javascript_disabled != "undefined") &&
					log4javascript_disabled);

	log4javascript.setEnabled = function(enable) {
		enabled = bool(enable);
	};

	log4javascript.isEnabled = function() {
		return enabled;
	};

	var useTimeStampsInMilliseconds = true;

	log4javascript.setTimeStampsInMilliseconds = function(timeStampsInMilliseconds) {
		useTimeStampsInMilliseconds = bool(timeStampsInMilliseconds);
	};

	log4javascript.isTimeStampsInMilliseconds = function() {
		return useTimeStampsInMilliseconds;
	};
	

	// This evaluates the given expression in the current scope, thus allowing
	// scripts to access private variables. Particularly useful for testing
	log4javascript.evalInScope = function(expr) {
		return eval(expr);
	};

	var showStackTraces = false;

	log4javascript.setShowStackTraces = function(show) {
		showStackTraces = bool(show);
	};

	/* ---------------------------------------------------------------------- */
	// Levels

	var Level = function(level, name) {
		this.level = level;
		this.name = name;
	};

	Level.prototype = {
		toString: function() {
			return this.name;
		},
		equals: function(level) {
			return this.level == level.level;
		},
		isGreaterOrEqual: function(level) {
			return this.level >= level.level;
		}
	};

	Level.ALL = new Level(Number.MIN_VALUE, "ALL");
	Level.TRACE = new Level(10000, "TRACE");
	Level.DEBUG = new Level(20000, "DEBUG");
	Level.INFO = new Level(30000, "INFO");
	Level.WARN = new Level(40000, "WARN");
	Level.ERROR = new Level(50000, "ERROR");
	Level.FATAL = new Level(60000, "FATAL");
	Level.OFF = new Level(Number.MAX_VALUE, "OFF");

	log4javascript.Level = Level;

	/* ---------------------------------------------------------------------- */
	// Timers

	function Timer(name, level) {
		this.name = name;
		this.level = isUndefined(level) ? Level.INFO : level;
		this.start = new Date();
	}

	Timer.prototype.getElapsedTime = function() {
		return new Date().getTime() - this.start.getTime();
	};

	/* ---------------------------------------------------------------------- */
	// Loggers

	var anonymousLoggerName = "[anonymous]";
	var defaultLoggerName = "[default]";
	var nullLoggerName = "[null]";
	var rootLoggerName = "root";

	function Logger(name) {
		this.name = name;
		this.parent = null;
		this.children = [];

		var appenders = [];
		var loggerLevel = null;
		var isRoot = (this.name === rootLoggerName);
		var isNull = (this.name === nullLoggerName);

		var appenderCache = null;
		var appenderCacheInvalidated = false;
		
		this.addChild = function(childLogger) {
			this.children.push(childLogger);
			childLogger.parent = this;
			childLogger.invalidateAppenderCache();
		};

		// Additivity
		var additive = true;
		this.getAdditivity = function() {
			return additive;
		};

		this.setAdditivity = function(additivity) {
			var valueChanged = (additive != additivity);
			additive = additivity;
			if (valueChanged) {
				this.invalidateAppenderCache();
			}
		};

		// Create methods that use the appenders variable in this scope
		this.addAppender = function(appender) {
			if (isNull) {
				handleError("Logger.addAppender: you may not add an appender to the null logger");
			} else {
				if (appender instanceof log4javascript.Appender) {
					if (!array_contains(appenders, appender)) {
						appenders.push(appender);
						appender.setAddedToLogger(this);
						this.invalidateAppenderCache();
					}
				} else {
					handleError("Logger.addAppender: appender supplied ('" +
						toStr(appender) + "') is not a subclass of Appender");
				}
			}
		};

		this.removeAppender = function(appender) {
			array_remove(appenders, appender);
			appender.setRemovedFromLogger(this);
			this.invalidateAppenderCache();
		};

		this.removeAllAppenders = function() {
			var appenderCount = appenders.length;
			if (appenderCount > 0) {
				for (var i = 0; i < appenderCount; i++) {
					appenders[i].setRemovedFromLogger(this);
				}
				appenders.length = 0;
				this.invalidateAppenderCache();
			}
		};

		this.getEffectiveAppenders = function() {
			if (appenderCache === null || appenderCacheInvalidated) {
				// Build appender cache
				var parentEffectiveAppenders = (isRoot || !this.getAdditivity()) ?
					[] : this.parent.getEffectiveAppenders();
				appenderCache = parentEffectiveAppenders.concat(appenders);
				appenderCacheInvalidated = false;
			}
			return appenderCache;
		};
		
		this.invalidateAppenderCache = function() {
			appenderCacheInvalidated = true;
			for (var i = 0, len = this.children.length; i < len; i++) {
				this.children[i].invalidateAppenderCache();
			}
		};

		this.log = function(level, params) {
			if (enabled && level.isGreaterOrEqual(this.getEffectiveLevel())) {
				// Check whether last param is an exception
				var exception;
				var finalParamIndex = params.length - 1;
				var lastParam = params[finalParamIndex];
				if (params.length > 1 && isError(lastParam)) {
					exception = lastParam;
					finalParamIndex--;
				}

				// Construct genuine array for the params
				var messages = [];
				for (var i = 0; i <= finalParamIndex; i++) {
					messages[i] = params[i];
				}

				var loggingEvent = new LoggingEvent(
					this, new Date(), level, messages, exception);

				this.callAppenders(loggingEvent);
			}
		};

		this.callAppenders = function(loggingEvent) {
			var effectiveAppenders = this.getEffectiveAppenders();
			for (var i = 0, len = effectiveAppenders.length; i < len; i++) {
				effectiveAppenders[i].doAppend(loggingEvent);
			}
		};

		this.setLevel = function(level) {
			// Having a level of null on the root logger would be very bad.
			if (isRoot && level === null) {
				handleError("Logger.setLevel: you cannot set the level of the root logger to null");
			} else if (level instanceof Level) {
				loggerLevel = level;
			} else {
				handleError("Logger.setLevel: level supplied to logger " +
					this.name + " is not an instance of log4javascript.Level");
			}
		};

		this.getLevel = function() {
			return loggerLevel;
		};

		this.getEffectiveLevel = function() {
			for (var logger = this; logger !== null; logger = logger.parent) {
				var level = logger.getLevel();
				if (level !== null) {
					return level;
				}
			}
		};

		this.group = function(name, initiallyExpanded) {
			if (enabled) {
				var effectiveAppenders = this.getEffectiveAppenders();
				for (var i = 0, len = effectiveAppenders.length; i < len; i++) {
					effectiveAppenders[i].group(name, initiallyExpanded);
				}
			}
		};

		this.groupEnd = function(name) {
			if (enabled) {
				var effectiveAppenders = this.getEffectiveAppenders();
				for (var i = 0, len = effectiveAppenders.length; i < len; i++) {
					effectiveAppenders[i].groupEnd();
				}
			}
		};

		var timers = {};

		this.time = function(name, level) {
			if (enabled) {
				if (isUndefined(name)) {
					handleError("Logger.time: a name for the timer must be supplied");
				} else if (level && !(level instanceof Level)) {
					handleError("Logger.time: level supplied to timer " +
						name + " is not an instance of log4javascript.Level");
				} else {
					timers[name] = new Timer(name, level);
				}
			}
		};

		this.timeEnd = function(name) {
			if (enabled) {
				if (isUndefined(name)) {
					handleError("Logger.timeEnd: a name for the timer must be supplied");
				} else if (timers[name]) {
					var timer = timers[name];
					var milliseconds = timer.getElapsedTime();
					this.log(timer.level, ["Timer " + toStr(name) + " completed in " + milliseconds + "ms"]);
					delete timers[name];
				} else {
					logLog.warn("Logger.timeEnd: no timer found with name " + name);
				}
			}
		};

		this.assert = function(expr) {
			if (enabled && !expr) {
				var args = [];
				for (var i = 1, len = arguments.length; i < len; i++) {
					args.push(arguments[i]);
				}
				args = (args.length > 0) ? args : ["Assertion Failure"];
				args.push(newLine);
				args.push(expr);
				this.log(Level.ERROR, args);
			}
		};

		this.toString = function() {
			return "Logger[" + this.name + "]";
		};
	}

	Logger.prototype = {
		trace: function() {
			this.log(Level.TRACE, arguments);
		},

		debug: function() {
			this.log(Level.DEBUG, arguments);
		},

		info: function() {
			this.log(Level.INFO, arguments);
		},

		warn: function() {
			this.log(Level.WARN, arguments);
		},

		error: function() {
			this.log(Level.ERROR, arguments);
		},

		fatal: function() {
			this.log(Level.FATAL, arguments);
		},

		isEnabledFor: function(level) {
			return level.isGreaterOrEqual(this.getEffectiveLevel());
		},

		isTraceEnabled: function() {
			return this.isEnabledFor(Level.TRACE);
		},

		isDebugEnabled: function() {
			return this.isEnabledFor(Level.DEBUG);
		},

		isInfoEnabled: function() {
			return this.isEnabledFor(Level.INFO);
		},

		isWarnEnabled: function() {
			return this.isEnabledFor(Level.WARN);
		},

		isErrorEnabled: function() {
			return this.isEnabledFor(Level.ERROR);
		},

		isFatalEnabled: function() {
			return this.isEnabledFor(Level.FATAL);
		}
	};

	Logger.prototype.trace.isEntryPoint = true;
	Logger.prototype.debug.isEntryPoint = true;
	Logger.prototype.info.isEntryPoint = true;
	Logger.prototype.warn.isEntryPoint = true;
	Logger.prototype.error.isEntryPoint = true;
	Logger.prototype.fatal.isEntryPoint = true;

	/* ---------------------------------------------------------------------- */
	// Logger access methods

	// Hashtable of loggers keyed by logger name
	var loggers = {};
	var loggerNames = [];

	var ROOT_LOGGER_DEFAULT_LEVEL = Level.DEBUG;
	var rootLogger = new Logger(rootLoggerName);
	rootLogger.setLevel(ROOT_LOGGER_DEFAULT_LEVEL);

	log4javascript.getRootLogger = function() {
		return rootLogger;
	};

	log4javascript.getLogger = function(loggerName) {
		// Use default logger if loggerName is not specified or invalid
		if (!(typeof loggerName == "string")) {
			loggerName = anonymousLoggerName;
			logLog.warn("log4javascript.getLogger: non-string logger name "	+
				toStr(loggerName) + " supplied, returning anonymous logger");
		}

		// Do not allow retrieval of the root logger by name
		if (loggerName == rootLoggerName) {
			handleError("log4javascript.getLogger: root logger may not be obtained by name");
		}

		// Create the logger for this name if it doesn't already exist
		if (!loggers[loggerName]) {
			var logger = new Logger(loggerName);
			loggers[loggerName] = logger;
			loggerNames.push(loggerName);

			// Set up parent logger, if it doesn't exist
			var lastDotIndex = loggerName.lastIndexOf(".");
			var parentLogger;
			if (lastDotIndex > -1) {
				var parentLoggerName = loggerName.substring(0, lastDotIndex);
				parentLogger = log4javascript.getLogger(parentLoggerName); // Recursively sets up grandparents etc.
			} else {
				parentLogger = rootLogger;
			}
			parentLogger.addChild(logger);
		}
		return loggers[loggerName];
	};

	var defaultLogger = null;
	log4javascript.getDefaultLogger = function() {
		if (!defaultLogger) {
			defaultLogger = log4javascript.getLogger(defaultLoggerName);
			var a = new log4javascript.PopUpAppender();
			defaultLogger.addAppender(a);
		}
		return defaultLogger;
	};

	var nullLogger = null;
	log4javascript.getNullLogger = function() {
		if (!nullLogger) {
			nullLogger = new Logger(nullLoggerName);
			nullLogger.setLevel(Level.OFF);
		}
		return nullLogger;
	};

	// Destroys all loggers
	log4javascript.resetConfiguration = function() {
		rootLogger.setLevel(ROOT_LOGGER_DEFAULT_LEVEL);
		loggers = {};
	};

	/* ---------------------------------------------------------------------- */
	// Logging events

	var LoggingEvent = function(logger, timeStamp, level, messages,
			exception) {
		this.logger = logger;
		this.timeStamp = timeStamp;
		this.timeStampInMilliseconds = timeStamp.getTime();
		this.timeStampInSeconds = Math.floor(this.timeStampInMilliseconds / 1000);
		this.milliseconds = this.timeStamp.getMilliseconds();
		this.level = level;
		this.messages = messages;
		this.exception = exception;
	};

	LoggingEvent.prototype = {
		getThrowableStrRep: function() {
			return this.exception ?
				getExceptionStringRep(this.exception) : "";
		},
		getCombinedMessages: function() {
			return (this.messages.length == 1) ? this.messages[0] :
				   this.messages.join(newLine);
		},
		toString: function() {
			return "LoggingEvent[" + this.level + "]";
		}
	};

	log4javascript.LoggingEvent = LoggingEvent;

	/* ---------------------------------------------------------------------- */
	// Layout prototype

	var Layout = function() {
	};

	Layout.prototype = {
		defaults: {
			loggerKey: "logger",
			timeStampKey: "timestamp",
			millisecondsKey: "milliseconds",
			levelKey: "level",
			messageKey: "message",
			exceptionKey: "exception",
			urlKey: "url"
		},
		loggerKey: "logger",
		timeStampKey: "timestamp",
		millisecondsKey: "milliseconds",
		levelKey: "level",
		messageKey: "message",
		exceptionKey: "exception",
		urlKey: "url",
		batchHeader: "",
		batchFooter: "",
		batchSeparator: "",
		returnsPostData: false,
		overrideTimeStampsSetting: false,
		useTimeStampsInMilliseconds: null,

		format: function() {
			handleError("Layout.format: layout supplied has no format() method");
		},

		ignoresThrowable: function() {
			handleError("Layout.ignoresThrowable: layout supplied has no ignoresThrowable() method");
		},

		getContentType: function() {
			return "text/plain";
		},

		allowBatching: function() {
			return true;
		},

		setTimeStampsInMilliseconds: function(timeStampsInMilliseconds) {
			this.overrideTimeStampsSetting = true;
			this.useTimeStampsInMilliseconds = bool(timeStampsInMilliseconds);
		},

		isTimeStampsInMilliseconds: function() {
			return this.overrideTimeStampsSetting ?
				this.useTimeStampsInMilliseconds : useTimeStampsInMilliseconds;
		},

		getTimeStampValue: function(loggingEvent) {
			return this.isTimeStampsInMilliseconds() ?
				loggingEvent.timeStampInMilliseconds : loggingEvent.timeStampInSeconds;
		},

		getDataValues: function(loggingEvent, combineMessages) {
			var dataValues = [
				[this.loggerKey, loggingEvent.logger.name],
				[this.timeStampKey, this.getTimeStampValue(loggingEvent)],
				[this.levelKey, loggingEvent.level.name],
				[this.urlKey, window.location.href],
				[this.messageKey, combineMessages ? loggingEvent.getCombinedMessages() : loggingEvent.messages]
			];
			if (!this.isTimeStampsInMilliseconds()) {
				dataValues.push([this.millisecondsKey, loggingEvent.milliseconds]);
			}
			if (loggingEvent.exception) {
				dataValues.push([this.exceptionKey, getExceptionStringRep(loggingEvent.exception)]);
			}
			if (this.hasCustomFields()) {
				for (var i = 0, len = this.customFields.length; i < len; i++) {
					var val = this.customFields[i].value;

					// Check if the value is a function. If so, execute it, passing it the
					// current layout and the logging event
					if (typeof val === "function") {
						val = val(this, loggingEvent);
					}
					dataValues.push([this.customFields[i].name, val]);
				}
			}
			return dataValues;
		},

		setKeys: function(loggerKey, timeStampKey, levelKey, messageKey,
				exceptionKey, urlKey, millisecondsKey) {
			this.loggerKey = extractStringFromParam(loggerKey, this.defaults.loggerKey);
			this.timeStampKey = extractStringFromParam(timeStampKey, this.defaults.timeStampKey);
			this.levelKey = extractStringFromParam(levelKey, this.defaults.levelKey);
			this.messageKey = extractStringFromParam(messageKey, this.defaults.messageKey);
			this.exceptionKey = extractStringFromParam(exceptionKey, this.defaults.exceptionKey);
			this.urlKey = extractStringFromParam(urlKey, this.defaults.urlKey);
			this.millisecondsKey = extractStringFromParam(millisecondsKey, this.defaults.millisecondsKey);
		},

		setCustomField: function(name, value) {
			var fieldUpdated = false;
			for (var i = 0, len = this.customFields.length; i < len; i++) {
				if (this.customFields[i].name === name) {
					this.customFields[i].value = value;
					fieldUpdated = true;
				}
			}
			if (!fieldUpdated) {
				this.customFields.push({"name": name, "value": value});
			}
		},

		hasCustomFields: function() {
			return (this.customFields.length > 0);
		},

		toString: function() {
			handleError("Layout.toString: all layouts must override this method");
		}
	};

	log4javascript.Layout = Layout;

	/* ---------------------------------------------------------------------- */
	// Appender prototype

	var Appender = function() {};

	Appender.prototype = new EventSupport();

	Appender.prototype.layout = new PatternLayout();
	Appender.prototype.threshold = Level.ALL;
	Appender.prototype.loggers = [];

	// Performs threshold checks before delegating actual logging to the
	// subclass's specific append method.
	Appender.prototype.doAppend = function(loggingEvent) {
		if (enabled && loggingEvent.level.level >= this.threshold.level) {
			this.append(loggingEvent);
		}
	};

	Appender.prototype.append = function(loggingEvent) {};

	Appender.prototype.setLayout = function(layout) {
		if (layout instanceof Layout) {
			this.layout = layout;
		} else {
			handleError("Appender.setLayout: layout supplied to " +
				this.toString() + " is not a subclass of Layout");
		}
	};

	Appender.prototype.getLayout = function() {
		return this.layout;
	};

	Appender.prototype.setThreshold = function(threshold) {
		if (threshold instanceof Level) {
			this.threshold = threshold;
		} else {
			handleError("Appender.setThreshold: threshold supplied to " +
				this.toString() + " is not a subclass of Level");
		}
	};

	Appender.prototype.getThreshold = function() {
		return this.threshold;
	};

	Appender.prototype.setAddedToLogger = function(logger) {
		this.loggers.push(logger);
	};

	Appender.prototype.setRemovedFromLogger = function(logger) {
		array_remove(this.loggers, logger);
	};

	Appender.prototype.group = emptyFunction;
	Appender.prototype.groupEnd = emptyFunction;

	Appender.prototype.toString = function() {
		handleError("Appender.toString: all appenders must override this method");
	};

	log4javascript.Appender = Appender;

	/* ---------------------------------------------------------------------- */
	// SimpleLayout 

	function SimpleLayout() {
		this.customFields = [];
	}

	SimpleLayout.prototype = new Layout();

	SimpleLayout.prototype.format = function(loggingEvent) {
		return loggingEvent.level.name + " - " + loggingEvent.getCombinedMessages();
	};

	SimpleLayout.prototype.ignoresThrowable = function() {
	    return true;
	};

	SimpleLayout.prototype.toString = function() {
	    return "SimpleLayout";
	};

	log4javascript.SimpleLayout = SimpleLayout;
	/* ----------------------------------------------------------------------- */
	// NullLayout 

	function NullLayout() {
		this.customFields = [];
	}

	NullLayout.prototype = new Layout();

	NullLayout.prototype.format = function(loggingEvent) {
		return loggingEvent.messages;
	};

	NullLayout.prototype.ignoresThrowable = function() {
	    return true;
	};

	NullLayout.prototype.toString = function() {
	    return "NullLayout";
	};

	log4javascript.NullLayout = NullLayout;
/* ---------------------------------------------------------------------- */
	// XmlLayout

	function XmlLayout(combineMessages) {
		this.combineMessages = extractBooleanFromParam(combineMessages, true);
		this.customFields = [];
	}

	XmlLayout.prototype = new Layout();

	XmlLayout.prototype.isCombinedMessages = function() {
		return this.combineMessages;
	};

	XmlLayout.prototype.getContentType = function() {
		return "text/xml";
	};

	XmlLayout.prototype.escapeCdata = function(str) {
		return str.replace(/\]\]>/, "]]>]]&gt;<![CDATA[");
	};

	XmlLayout.prototype.format = function(loggingEvent) {
		var layout = this;
		var i, len;
		function formatMessage(message) {
			message = (typeof message === "string") ? message : toStr(message);
			return "<log4javascript:message><![CDATA[" +
				layout.escapeCdata(message) + "]]></log4javascript:message>";
		}

		var str = "<log4javascript:event logger=\"" + loggingEvent.logger.name +
			"\" timestamp=\"" + this.getTimeStampValue(loggingEvent) + "\"";
		if (!this.isTimeStampsInMilliseconds()) {
			str += " milliseconds=\"" + loggingEvent.milliseconds + "\"";
		}
		str += " level=\"" + loggingEvent.level.name + "\">" + newLine;
		if (this.combineMessages) {
			str += formatMessage(loggingEvent.getCombinedMessages());
		} else {
			str += "<log4javascript:messages>" + newLine;
			for (i = 0, len = loggingEvent.messages.length; i < len; i++) {
				str += formatMessage(loggingEvent.messages[i]) + newLine;
			}
			str += "</log4javascript:messages>" + newLine;
		}
		if (this.hasCustomFields()) {
			for (i = 0, len = this.customFields.length; i < len; i++) {
				str += "<log4javascript:customfield name=\"" +
					this.customFields[i].name + "\"><![CDATA[" +
					this.customFields[i].value.toString() +
					"]]></log4javascript:customfield>" + newLine;
			}
		}
		if (loggingEvent.exception) {
			str += "<log4javascript:exception><![CDATA[" +
				getExceptionStringRep(loggingEvent.exception) +
				"]]></log4javascript:exception>" + newLine;
		}
		str += "</log4javascript:event>" + newLine + newLine;
		return str;
	};

	XmlLayout.prototype.ignoresThrowable = function() {
	    return false;
	};

	XmlLayout.prototype.toString = function() {
	    return "XmlLayout";
	};

	log4javascript.XmlLayout = XmlLayout;
	/* ---------------------------------------------------------------------- */
	// JsonLayout related

	function escapeNewLines(str) {
		return str.replace(/\r\n|\r|\n/g, "\\r\\n");
	}

	function JsonLayout(readable, combineMessages) {
		this.readable = extractBooleanFromParam(readable, false);
		this.combineMessages = extractBooleanFromParam(combineMessages, true);
		this.batchHeader = this.readable ? "[" + newLine : "[";
		this.batchFooter = this.readable ? "]" + newLine : "]";
		this.batchSeparator = this.readable ? "," + newLine : ",";
		this.setKeys();
		this.colon = this.readable ? ": " : ":";
		this.tab = this.readable ? "\t" : "";
		this.lineBreak = this.readable ? newLine : "";
		this.customFields = [];
	}

	/* ---------------------------------------------------------------------- */
	// JsonLayout

	JsonLayout.prototype = new Layout();

	JsonLayout.prototype.isReadable = function() {
		return this.readable;
	};

	JsonLayout.prototype.isCombinedMessages = function() {
		return this.combineMessages;
	};

    JsonLayout.prototype.format = function(loggingEvent) {
        var layout = this;
        var dataValues = this.getDataValues(loggingEvent, this.combineMessages);
        var str = "{" + this.lineBreak;
        var i, len;

        function formatValue(val, prefix, expand) {
            // Check the type of the data value to decide whether quotation marks
            // or expansion are required
            var formattedValue;
            var valType = typeof val;
            if (val instanceof Date) {
                formattedValue = String(val.getTime());
            } else if (expand && (val instanceof Array)) {
                formattedValue = "[" + layout.lineBreak;
                for (var i = 0, len = val.length; i < len; i++) {
                    var childPrefix = prefix + layout.tab;
                    formattedValue += childPrefix + formatValue(val[i], childPrefix, false);
                    if (i < val.length - 1) {
                        formattedValue += ",";
                    }
                    formattedValue += layout.lineBreak;
                }
                formattedValue += prefix + "]";
            } else if (valType !== "number" && valType !== "boolean") {
                formattedValue = "\"" + escapeNewLines(toStr(val).replace(/\"/g, "\\\"")) + "\"";
            } else {
                formattedValue = val;
            }
            return formattedValue;
        }

        for (i = 0, len = dataValues.length - 1; i <= len; i++) {
            str += this.tab + "\"" + dataValues[i][0] + "\"" + this.colon + formatValue(dataValues[i][1], this.tab, true);
            if (i < len) {
                str += ",";
            }
            str += this.lineBreak;
        }

        str += "}" + this.lineBreak;
        return str;
    };

	JsonLayout.prototype.ignoresThrowable = function() {
	    return false;
	};

	JsonLayout.prototype.toString = function() {
	    return "JsonLayout";
	};

	JsonLayout.prototype.getContentType = function() {
		return "application/json";
	};

	log4javascript.JsonLayout = JsonLayout;
	/* ---------------------------------------------------------------------- */
	// HttpPostDataLayout

	function HttpPostDataLayout() {
		this.setKeys();
		this.customFields = [];
		this.returnsPostData = true;
	}

	HttpPostDataLayout.prototype = new Layout();

	// Disable batching
	HttpPostDataLayout.prototype.allowBatching = function() {
		return false;
	};

	HttpPostDataLayout.prototype.format = function(loggingEvent) {
		var dataValues = this.getDataValues(loggingEvent);
		var queryBits = [];
		for (var i = 0, len = dataValues.length; i < len; i++) {
			var val = (dataValues[i][1] instanceof Date) ?
				String(dataValues[i][1].getTime()) : dataValues[i][1];
			queryBits.push(urlEncode(dataValues[i][0]) + "=" + urlEncode(val));
		}
		return queryBits.join("&");
	};

	HttpPostDataLayout.prototype.ignoresThrowable = function(loggingEvent) {
	    return false;
	};

	HttpPostDataLayout.prototype.toString = function() {
	    return "HttpPostDataLayout";
	};

	log4javascript.HttpPostDataLayout = HttpPostDataLayout;
	/* ---------------------------------------------------------------------- */
	// formatObjectExpansion

	function formatObjectExpansion(obj, depth, indentation) {
		var objectsExpanded = [];

		function doFormat(obj, depth, indentation) {
			var i, j, len, childDepth, childIndentation, childLines, expansion,
				childExpansion;

			if (!indentation) {
				indentation = "";
			}

			function formatString(text) {
				var lines = splitIntoLines(text);
				for (var j = 1, jLen = lines.length; j < jLen; j++) {
					lines[j] = indentation + lines[j];
				}
				return lines.join(newLine);
			}

			if (obj === null) {
				return "null";
			} else if (typeof obj == "undefined") {
				return "undefined";
			} else if (typeof obj == "string") {
				return formatString(obj);
			} else if (typeof obj == "object" && array_contains(objectsExpanded, obj)) {
				try {
					expansion = toStr(obj);
				} catch (ex) {
					expansion = "Error formatting property. Details: " + getExceptionStringRep(ex);
				}
				return expansion + " [already expanded]";
			} else if ((obj instanceof Array) && depth > 0) {
				objectsExpanded.push(obj);
				expansion = "[" + newLine;
				childDepth = depth - 1;
				childIndentation = indentation + "  ";
				childLines = [];
				for (i = 0, len = obj.length; i < len; i++) {
					try {
						childExpansion = doFormat(obj[i], childDepth, childIndentation);
						childLines.push(childIndentation + childExpansion);
					} catch (ex) {
						childLines.push(childIndentation + "Error formatting array member. Details: " +
							getExceptionStringRep(ex) + "");
					}
				}
				expansion += childLines.join("," + newLine) + newLine + indentation + "]";
				return expansion;
			} else if (typeof obj == "object" && depth > 0) {
				objectsExpanded.push(obj);
				expansion = "{" + newLine;
				childDepth = depth - 1;
				childIndentation = indentation + "  ";
				childLines = [];
				for (i in obj) {
					try {
						childExpansion = doFormat(obj[i], childDepth, childIndentation);
						childLines.push(childIndentation + i + ": " + childExpansion);
					} catch (ex) {
						childLines.push(childIndentation + i + ": Error formatting property. Details: " +
							getExceptionStringRep(ex));
					}
				}
				expansion += childLines.join("," + newLine) + newLine + indentation + "}";
				return expansion;
			} else {
				return formatString(toStr(obj));
			}
		}
		return doFormat(obj, depth, indentation);
	}
	/* ---------------------------------------------------------------------- */
	// Date-related stuff

	var SimpleDateFormat;

	(function() {
		var regex = /('[^']*')|(G+|y+|M+|w+|W+|D+|d+|F+|E+|a+|H+|k+|K+|h+|m+|s+|S+|Z+)|([a-zA-Z]+)|([^a-zA-Z']+)/;
		var monthNames = ["January", "February", "March", "April", "May", "June",
			"July", "August", "September", "October", "November", "December"];
		var dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
		var TEXT2 = 0, TEXT3 = 1, NUMBER = 2, YEAR = 3, MONTH = 4, TIMEZONE = 5;
		var types = {
			G : TEXT2,
			y : YEAR,
			M : MONTH,
			w : NUMBER,
			W : NUMBER,
			D : NUMBER,
			d : NUMBER,
			F : NUMBER,
			E : TEXT3,
			a : TEXT2,
			H : NUMBER,
			k : NUMBER,
			K : NUMBER,
			h : NUMBER,
			m : NUMBER,
			s : NUMBER,
			S : NUMBER,
			Z : TIMEZONE
		};
		var ONE_DAY = 24 * 60 * 60 * 1000;
		var ONE_WEEK = 7 * ONE_DAY;
		var DEFAULT_MINIMAL_DAYS_IN_FIRST_WEEK = 1;

		var newDateAtMidnight = function(year, month, day) {
			var d = new Date(year, month, day, 0, 0, 0);
			d.setMilliseconds(0);
			return d;
		};

		Date.prototype.getDifference = function(date) {
			return this.getTime() - date.getTime();
		};

		Date.prototype.isBefore = function(d) {
			return this.getTime() < d.getTime();
		};

		Date.prototype.getUTCTime = function() {
			return Date.UTC(this.getFullYear(), this.getMonth(), this.getDate(), this.getHours(), this.getMinutes(),
					this.getSeconds(), this.getMilliseconds());
		};

		Date.prototype.getTimeSince = function(d) {
			return this.getUTCTime() - d.getUTCTime();
		};

		Date.prototype.getPreviousSunday = function() {
			// Using midday avoids any possibility of DST messing things up
			var midday = new Date(this.getFullYear(), this.getMonth(), this.getDate(), 12, 0, 0);
			var previousSunday = new Date(midday.getTime() - this.getDay() * ONE_DAY);
			return newDateAtMidnight(previousSunday.getFullYear(), previousSunday.getMonth(),
					previousSunday.getDate());
		};

		Date.prototype.getWeekInYear = function(minimalDaysInFirstWeek) {
			if (isUndefined(this.minimalDaysInFirstWeek)) {
				minimalDaysInFirstWeek = DEFAULT_MINIMAL_DAYS_IN_FIRST_WEEK;
			}
			var previousSunday = this.getPreviousSunday();
			var startOfYear = newDateAtMidnight(this.getFullYear(), 0, 1);
			var numberOfSundays = previousSunday.isBefore(startOfYear) ?
				0 : 1 + Math.floor(previousSunday.getTimeSince(startOfYear) / ONE_WEEK);
			var numberOfDaysInFirstWeek =  7 - startOfYear.getDay();
			var weekInYear = numberOfSundays;
			if (numberOfDaysInFirstWeek < minimalDaysInFirstWeek) {
				weekInYear--;
			}
			return weekInYear;
		};

		Date.prototype.getWeekInMonth = function(minimalDaysInFirstWeek) {
			if (isUndefined(this.minimalDaysInFirstWeek)) {
				minimalDaysInFirstWeek = DEFAULT_MINIMAL_DAYS_IN_FIRST_WEEK;
			}
			var previousSunday = this.getPreviousSunday();
			var startOfMonth = newDateAtMidnight(this.getFullYear(), this.getMonth(), 1);
			var numberOfSundays = previousSunday.isBefore(startOfMonth) ?
				0 : 1 + Math.floor(previousSunday.getTimeSince(startOfMonth) / ONE_WEEK);
			var numberOfDaysInFirstWeek =  7 - startOfMonth.getDay();
			var weekInMonth = numberOfSundays;
			if (numberOfDaysInFirstWeek >= minimalDaysInFirstWeek) {
				weekInMonth++;
			}
			return weekInMonth;
		};

		Date.prototype.getDayInYear = function() {
			var startOfYear = newDateAtMidnight(this.getFullYear(), 0, 1);
			return 1 + Math.floor(this.getTimeSince(startOfYear) / ONE_DAY);
		};

		/* ------------------------------------------------------------------ */

		SimpleDateFormat = function(formatString) {
			this.formatString = formatString;
		};

		/*
		 * Sets the minimum number of days in a week in order for that week to
		 * be considered as belonging to a particular month or year
		 */
		SimpleDateFormat.prototype.setMinimalDaysInFirstWeek = function(days) {
			this.minimalDaysInFirstWeek = days;
		};

		SimpleDateFormat.prototype.getMinimalDaysInFirstWeek = function() {
			return isUndefined(this.minimalDaysInFirstWeek)	?
				DEFAULT_MINIMAL_DAYS_IN_FIRST_WEEK : this.minimalDaysInFirstWeek;
		};

		var padWithZeroes = function(str, len) {
			while (str.length < len) {
				str = "0" + str;
			}
			return str;
		};

		var formatText = function(data, numberOfLetters, minLength) {
			return (numberOfLetters >= 4) ? data : data.substr(0, Math.max(minLength, numberOfLetters));
		};

		var formatNumber = function(data, numberOfLetters) {
			var dataString = "" + data;
			// Pad with 0s as necessary
			return padWithZeroes(dataString, numberOfLetters);
		};

		SimpleDateFormat.prototype.format = function(date) {
			var formattedString = "";
			var result;
			var searchString = this.formatString;
			while ((result = regex.exec(searchString))) {
				var quotedString = result[1];
				var patternLetters = result[2];
				var otherLetters = result[3];
				var otherCharacters = result[4];

				// If the pattern matched is quoted string, output the text between the quotes
				if (quotedString) {
					if (quotedString == "''") {
						formattedString += "'";
					} else {
						formattedString += quotedString.substring(1, quotedString.length - 1);
					}
				} else if (otherLetters) {
					// Swallow non-pattern letters by doing nothing here
				} else if (otherCharacters) {
					// Simply output other characters
					formattedString += otherCharacters;
				} else if (patternLetters) {
					// Replace pattern letters
					var patternLetter = patternLetters.charAt(0);
					var numberOfLetters = patternLetters.length;
					var rawData = "";
					switch(patternLetter) {
						case "G":
							rawData = "AD";
							break;
						case "y":
							rawData = date.getFullYear();
							break;
						case "M":
							rawData = date.getMonth();
							break;
						case "w":
							rawData = date.getWeekInYear(this.getMinimalDaysInFirstWeek());
							break;
						case "W":
							rawData = date.getWeekInMonth(this.getMinimalDaysInFirstWeek());
							break;
						case "D":
							rawData = date.getDayInYear();
							break;
						case "d":
							rawData = date.getDate();
							break;
						case "F":
							rawData = 1 + Math.floor((date.getDate() - 1) / 7);
							break;
						case "E":
							rawData = dayNames[date.getDay()];
							break;
						case "a":
							rawData = (date.getHours() >= 12) ? "PM" : "AM";
							break;
						case "H":
							rawData = date.getHours();
							break;
						case "k":
							rawData = date.getHours() || 24;
							break;
						case "K":
							rawData = date.getHours() % 12;
							break;
						case "h":
							rawData = (date.getHours() % 12) || 12;
							break;
						case "m":
							rawData = date.getMinutes();
							break;
						case "s":
							rawData = date.getSeconds();
							break;
						case "S":
							rawData = date.getMilliseconds();
							break;
						case "Z":
							rawData = date.getTimezoneOffset(); // This returns the number of minutes since GMT was this time.
							break;
					}
					// Format the raw data depending on the type
					switch(types[patternLetter]) {
						case TEXT2:
							formattedString += formatText(rawData, numberOfLetters, 2);
							break;
						case TEXT3:
							formattedString += formatText(rawData, numberOfLetters, 3);
							break;
						case NUMBER:
							formattedString += formatNumber(rawData, numberOfLetters);
							break;
						case YEAR:
							if (numberOfLetters <= 3) {
								// Output a 2-digit year
								var dataString = "" + rawData;
								formattedString += dataString.substr(2, 2);
							} else {
								formattedString += formatNumber(rawData, numberOfLetters);
							}
							break;
						case MONTH:
							if (numberOfLetters >= 3) {
								formattedString += formatText(monthNames[rawData], numberOfLetters, numberOfLetters);
							} else {
								// NB. Months returned by getMonth are zero-based
								formattedString += formatNumber(rawData + 1, numberOfLetters);
							}
							break;
						case TIMEZONE:
							var isPositive = (rawData > 0);
							// The following line looks like a mistake but isn't
							// because of the way getTimezoneOffset measures.
							var prefix = isPositive ? "-" : "+";
							var absData = Math.abs(rawData);

							// Hours
							var hours = "" + Math.floor(absData / 60);
							hours = padWithZeroes(hours, 2);
							// Minutes
							var minutes = "" + (absData % 60);
							minutes = padWithZeroes(minutes, 2);

							formattedString += prefix + hours + minutes;
							break;
					}
				}
				searchString = searchString.substr(result.index + result[0].length);
			}
			return formattedString;
		};
	})();

	log4javascript.SimpleDateFormat = SimpleDateFormat;

	/* ---------------------------------------------------------------------- */
	// PatternLayout

	function PatternLayout(pattern) {
		if (pattern) {
			this.pattern = pattern;
		} else {
			this.pattern = PatternLayout.DEFAULT_CONVERSION_PATTERN;
		}
		this.customFields = [];
	}

	PatternLayout.TTCC_CONVERSION_PATTERN = "%r %p %c - %m%n";
	PatternLayout.DEFAULT_CONVERSION_PATTERN = "%m%n";
	PatternLayout.ISO8601_DATEFORMAT = "yyyy-MM-dd HH:mm:ss,SSS";
	PatternLayout.DATETIME_DATEFORMAT = "dd MMM yyyy HH:mm:ss,SSS";
	PatternLayout.ABSOLUTETIME_DATEFORMAT = "HH:mm:ss,SSS";

	PatternLayout.prototype = new Layout();

	PatternLayout.prototype.format = function(loggingEvent) {
		var regex = /%(-?[0-9]+)?(\.?[0-9]+)?([acdfmMnpr%])(\{([^\}]+)\})?|([^%]+)/;
		var formattedString = "";
		var result;
		var searchString = this.pattern;

		// Cannot use regex global flag since it doesn't work with exec in IE5
		while ((result = regex.exec(searchString))) {
			var matchedString = result[0];
			var padding = result[1];
			var truncation = result[2];
			var conversionCharacter = result[3];
			var specifier = result[5];
			var text = result[6];

			// Check if the pattern matched was just normal text
			if (text) {
				formattedString += "" + text;
			} else {
				// Create a raw replacement string based on the conversion
				// character and specifier
				var replacement = "";
				switch(conversionCharacter) {
					case "a": // Array of messages
					case "m": // Message
						var depth = 0;
						if (specifier) {
							depth = parseInt(specifier, 10);
							if (isNaN(depth)) {
								handleError("PatternLayout.format: invalid specifier '" +
									specifier + "' for conversion character '" + conversionCharacter +
									"' - should be a number");
								depth = 0;
							}
						}
						var messages = (conversionCharacter === "a") ? loggingEvent.messages[0] : loggingEvent.messages;
						for (var i = 0, len = messages.length; i < len; i++) {
							if (i > 0 && (replacement.charAt(replacement.length - 1) !== " ")) {
								replacement += " ";
							}
							if (depth === 0) {
								replacement += messages[i];
							} else {
								replacement += formatObjectExpansion(messages[i], depth);
							}
						}
						break;
					case "c": // Logger name
						var loggerName = loggingEvent.logger.name;
						if (specifier) {
							var precision = parseInt(specifier, 10);
							var loggerNameBits = loggingEvent.logger.name.split(".");
							if (precision >= loggerNameBits.length) {
								replacement = loggerName;
							} else {
								replacement = loggerNameBits.slice(loggerNameBits.length - precision).join(".");
							}
						} else {
							replacement = loggerName;
						}
						break;
					case "d": // Date
						var dateFormat = PatternLayout.ISO8601_DATEFORMAT;
						if (specifier) {
							dateFormat = specifier;
							// Pick up special cases
							if (dateFormat == "ISO8601") {
								dateFormat = PatternLayout.ISO8601_DATEFORMAT;
							} else if (dateFormat == "ABSOLUTE") {
								dateFormat = PatternLayout.ABSOLUTETIME_DATEFORMAT;
							} else if (dateFormat == "DATE") {
								dateFormat = PatternLayout.DATETIME_DATEFORMAT;
							}
						}
						// Format the date
						replacement = (new SimpleDateFormat(dateFormat)).format(loggingEvent.timeStamp);
						break;
					case "f": // Custom field
						if (this.hasCustomFields()) {
							var fieldIndex = 0;
							if (specifier) {
								fieldIndex = parseInt(specifier, 10);
								if (isNaN(fieldIndex)) {
									handleError("PatternLayout.format: invalid specifier '" +
										specifier + "' for conversion character 'f' - should be a number");
								} else if (fieldIndex === 0) {
									handleError("PatternLayout.format: invalid specifier '" +
										specifier + "' for conversion character 'f' - must be greater than zero");
								} else if (fieldIndex > this.customFields.length) {
									handleError("PatternLayout.format: invalid specifier '" +
										specifier + "' for conversion character 'f' - there aren't that many custom fields");
								} else {
									fieldIndex = fieldIndex - 1;
								}
							}
							replacement = this.customFields[fieldIndex].value;
						}
						break;
					case "n": // New line
						replacement = newLine;
						break;
					case "p": // Level
						replacement = loggingEvent.level.name;
						break;
					case "r": // Milliseconds since log4javascript startup
						replacement = "" + loggingEvent.timeStamp.getDifference(applicationStartDate);
						break;
					case "%": // Literal % sign
						replacement = "%";
						break;
					default:
						replacement = matchedString;
						break;
				}
				// Format the replacement according to any padding or
				// truncation specified
				var l;

				// First, truncation
				if (truncation) {
					l = parseInt(truncation.substr(1), 10);
					var strLen = replacement.length;
					if (l < strLen) {
						replacement = replacement.substring(strLen - l, strLen);
					}
				}
				// Next, padding
				if (padding) {
					if (padding.charAt(0) == "-") {
						l = parseInt(padding.substr(1), 10);
						// Right pad with spaces
						while (replacement.length < l) {
							replacement += " ";
						}
					} else {
						l = parseInt(padding, 10);
						// Left pad with spaces
						while (replacement.length < l) {
							replacement = " " + replacement;
						}
					}
				}
				formattedString += replacement;
			}
			searchString = searchString.substr(result.index + result[0].length);
		}
		return formattedString;
	};

	PatternLayout.prototype.ignoresThrowable = function() {
	    return true;
	};

	PatternLayout.prototype.toString = function() {
	    return "PatternLayout";
	};

	log4javascript.PatternLayout = PatternLayout;
	/* ---------------------------------------------------------------------- */
	// AlertAppender

	function AlertAppender() {}

	AlertAppender.prototype = new Appender();

	AlertAppender.prototype.layout = new SimpleLayout();

	AlertAppender.prototype.append = function(loggingEvent) {
		var formattedMessage = this.getLayout().format(loggingEvent);
		if (this.getLayout().ignoresThrowable()) {
			formattedMessage += loggingEvent.getThrowableStrRep();
		}
		alert(formattedMessage);
	};

	AlertAppender.prototype.toString = function() {
		return "AlertAppender";
	};

	log4javascript.AlertAppender = AlertAppender;
	/* ---------------------------------------------------------------------- */
	// BrowserConsoleAppender (only works in Opera and Safari and Firefox with
	// Firebug extension)

	function BrowserConsoleAppender() {}

	BrowserConsoleAppender.prototype = new log4javascript.Appender();
	BrowserConsoleAppender.prototype.layout = new NullLayout();
	BrowserConsoleAppender.prototype.threshold = Level.DEBUG;

	BrowserConsoleAppender.prototype.append = function(loggingEvent) {
		var appender = this;

		var getFormattedMessage = function() {
			var layout = appender.getLayout();
			var formattedMessage = layout.format(loggingEvent);
			if (layout.ignoresThrowable() && loggingEvent.exception) {
				formattedMessage += loggingEvent.getThrowableStrRep();
			}
			return formattedMessage;
		};

		if ((typeof opera != "undefined") && opera.postError) { // Opera
			opera.postError(getFormattedMessage());
		} else if (window.console && window.console.log) { // Safari and Firebug
			var formattedMesage = getFormattedMessage();
			// Log to Firebug using its logging methods or revert to the console.log
			// method in Safari
			if (window.console.debug && Level.DEBUG.isGreaterOrEqual(loggingEvent.level)) {
				window.console.debug(formattedMesage);
			} else if (window.console.info && Level.INFO.equals(loggingEvent.level)) {
				window.console.info(formattedMesage);
			} else if (window.console.warn && Level.WARN.equals(loggingEvent.level)) {
				window.console.warn(formattedMesage);
			} else if (window.console.error && loggingEvent.level.isGreaterOrEqual(Level.ERROR)) {
				window.console.error(formattedMesage);
			} else {
				window.console.log(formattedMesage);
			}
		}
	};

	BrowserConsoleAppender.prototype.group = function(name) {
		if (window.console && window.console.group) {
			window.console.group(name);
		}
	};

	BrowserConsoleAppender.prototype.groupEnd = function() {
		if (window.console && window.console.groupEnd) {
			window.console.groupEnd();
		}
	};

	BrowserConsoleAppender.prototype.toString = function() {
		return "BrowserConsoleAppender";
	};

	log4javascript.BrowserConsoleAppender = BrowserConsoleAppender;
	/* ---------------------------------------------------------------------- */
	// AjaxAppender related

    var xmlHttpFactories = [
        function() { return new XMLHttpRequest(); },
        function() { return new ActiveXObject("Msxml2.XMLHTTP"); },
        function() { return new ActiveXObject("Microsoft.XMLHTTP"); }
    ];

    var getXmlHttp = function(errorHandler) {
        // This is only run the first time; the value of getXmlHttp gets
        // replaced with the factory that succeeds on the first run
        var xmlHttp = null, factory;
        for (var i = 0, len = xmlHttpFactories.length; i < len; i++) {
            factory = xmlHttpFactories[i];
            try {
                xmlHttp = factory();
                getXmlHttp = factory;
                return xmlHttp;
            } catch (e) {
            }
        }
        // If we're here, all factories have failed, so throw an error
        if (errorHandler) {
            errorHandler();
        } else {
            handleError("getXmlHttp: unable to obtain XMLHttpRequest object");
        }
    };

	function isHttpRequestSuccessful(xmlHttp) {
		return (isUndefined(xmlHttp.status) || xmlHttp.status === 0 ||
			(xmlHttp.status >= 200 && xmlHttp.status < 300));
	}

	/* ---------------------------------------------------------------------- */
	// AjaxAppender

	function AjaxAppender(url) {
		var appender = this;
		var isSupported = true;
		if (!url) {
			handleError("AjaxAppender: URL must be specified in constructor");
			isSupported = false;
		}

		var timed = this.defaults.timed;
		var waitForResponse = this.defaults.waitForResponse;
		var batchSize = this.defaults.batchSize;
		var timerInterval = this.defaults.timerInterval;
		var requestSuccessCallback = this.defaults.requestSuccessCallback;
		var failCallback = this.defaults.failCallback;
		var postVarName = this.defaults.postVarName;
		var sendAllOnUnload = this.defaults.sendAllOnUnload;
		var sessionId = null;

		var queuedLoggingEvents = [];
		var queuedRequests = [];
		var sending = false;
		var initialized = false;

		// Configuration methods. The function scope is used to prevent
		// direct alteration to the appender configuration properties.
		function checkCanConfigure(configOptionName) {
			if (initialized) {
				handleError("AjaxAppender: configuration option '" +
					configOptionName +
					"' may not be set after the appender has been initialized");
				return false;
			}
			return true;
		}

		this.getSessionId = function() { return sessionId; };
		this.setSessionId = function(sessionIdParam) {
			sessionId = extractStringFromParam(sessionIdParam, null);
			this.layout.setCustomField("sessionid", sessionId);
		};

		this.setLayout = function(layoutParam) {
			if (checkCanConfigure("layout")) {
				this.layout = layoutParam;
				// Set the session id as a custom field on the layout, if not already present
				if (sessionId !== null) {
					this.setSessionId(sessionId);
				}
			}
		};

		this.isTimed = function() { return timed; };
		this.setTimed = function(timedParam) {
			if (checkCanConfigure("timed")) {
				timed = bool(timedParam);
			}
		};

		this.getTimerInterval = function() { return timerInterval; };
		this.setTimerInterval = function(timerIntervalParam) {
			if (checkCanConfigure("timerInterval")) {
				timerInterval = extractIntFromParam(timerIntervalParam, timerInterval);
			}
		};

		this.isWaitForResponse = function() { return waitForResponse; };
		this.setWaitForResponse = function(waitForResponseParam) {
			if (checkCanConfigure("waitForResponse")) {
				waitForResponse = bool(waitForResponseParam);
			}
		};

		this.getBatchSize = function() { return batchSize; };
		this.setBatchSize = function(batchSizeParam) {
			if (checkCanConfigure("batchSize")) {
				batchSize = extractIntFromParam(batchSizeParam, batchSize);
			}
		};

		this.isSendAllOnUnload = function() { return sendAllOnUnload; };
		this.setSendAllOnUnload = function(sendAllOnUnloadParam) {
			if (checkCanConfigure("sendAllOnUnload")) {
				sendAllOnUnload = extractIntFromParam(sendAllOnUnloadParam, sendAllOnUnload);
			}
		};

		this.setRequestSuccessCallback = function(requestSuccessCallbackParam) {
			requestSuccessCallback = extractFunctionFromParam(requestSuccessCallbackParam, requestSuccessCallback);
		};

		this.setFailCallback = function(failCallbackParam) {
			failCallback = extractFunctionFromParam(failCallbackParam, failCallback);
		};

		this.getPostVarName = function() { return postVarName; };
		this.setPostVarName = function(postVarNameParam) {
			if (checkCanConfigure("postVarName")) {
				postVarName = extractStringFromParam(postVarNameParam, postVarName);
			}
		};

		// Internal functions
		function sendAll() {
			if (isSupported && enabled) {
				sending = true;
				var currentRequestBatch;
				if (waitForResponse) {
					// Send the first request then use this function as the callback once
					// the response comes back
					if (queuedRequests.length > 0) {
						currentRequestBatch = queuedRequests.shift();
						sendRequest(preparePostData(currentRequestBatch), sendAll);
					} else {
						sending = false;
						if (timed) {
							scheduleSending();
						}
					}
				} else {
					// Rattle off all the requests without waiting to see the response
					while ((currentRequestBatch = queuedRequests.shift())) {
						sendRequest(preparePostData(currentRequestBatch));
					}
					sending = false;
					if (timed) {
						scheduleSending();
					}
				}
			}
		}

		this.sendAll = sendAll;

		// Called when the window unloads. At this point we're past caring about
		// waiting for responses or timers or incomplete batches - everything
		// must go, now
		function sendAllRemaining() {
			if (isSupported && enabled) {
				// Create requests for everything left over, batched as normal
				var actualBatchSize = appender.getLayout().allowBatching() ? batchSize : 1;
				var currentLoggingEvent;
				var postData = "";
				var batchedLoggingEvents = [];
				while ((currentLoggingEvent = queuedLoggingEvents.shift())) {
					batchedLoggingEvents.push(currentLoggingEvent);
					if (queuedLoggingEvents.length >= actualBatchSize) {
						// Queue this batch of log entries
						queuedRequests.push(batchedLoggingEvents);
						batchedLoggingEvents = [];
					}
				}
				// If there's a partially completed batch, add it
				if (batchedLoggingEvents.length > 0) {
					queuedRequests.push(batchedLoggingEvents);
				}
				waitForResponse = false;
				timed = false;
				sendAll();
			}
		}

		function preparePostData(batchedLoggingEvents) {
			// Format the logging events
			var formattedMessages = [];
			var currentLoggingEvent;
			var postData = "";
			while ((currentLoggingEvent = batchedLoggingEvents.shift())) {
				var currentFormattedMessage = appender.getLayout().format(currentLoggingEvent);
				if (appender.getLayout().ignoresThrowable()) {
					currentFormattedMessage += loggingEvent.getThrowableStrRep();
				}
				formattedMessages.push(currentFormattedMessage);
			}
			// Create the post data string
			if (batchedLoggingEvents.length == 1) {
				postData = formattedMessages.join("");
			} else {
				postData = appender.getLayout().batchHeader +
					formattedMessages.join(appender.getLayout().batchSeparator) +
					appender.getLayout().batchFooter;
			}
			postData = appender.getLayout().returnsPostData ? postData :
				urlEncode(postVarName) + "=" + urlEncode(postData);
			// Add the layout name to the post data
			if (postData.length > 0) {
				postData += "&";
			}
			return postData + "layout=" + urlEncode(appender.getLayout().toString());
		}

		function scheduleSending() {
			window.setTimeout(sendAll, timerInterval);
		}

		function xmlHttpErrorHandler() {
			var msg = "AjaxAppender: could not create XMLHttpRequest object. AjaxAppender disabled";
			handleError(msg);
			isSupported = false;
			if (failCallback) {
				failCallback(msg);
			}
		}

		function sendRequest(postData, successCallback) {
			try {
				var xmlHttp = getXmlHttp(xmlHttpErrorHandler);
				if (isSupported) {
					if (xmlHttp.overrideMimeType) {
						xmlHttp.overrideMimeType(appender.getLayout().getContentType());
					}
					xmlHttp.onreadystatechange = function() {
						if (xmlHttp.readyState == 4) {
							if (isHttpRequestSuccessful(xmlHttp)) {
								if (requestSuccessCallback) {
									requestSuccessCallback(xmlHttp);
								}
								if (successCallback) {
									successCallback(xmlHttp);
								}
							} else {
								var msg = "AjaxAppender.append: XMLHttpRequest request to URL " +
									url + " returned status code " + xmlHttp.status;
								handleError(msg);
								if (failCallback) {
									failCallback(msg);
								}
							}
							xmlHttp.onreadystatechange = emptyFunction;
							xmlHttp = null;
						}
					};
					xmlHttp.open("POST", url, true);
					try {
						xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
					} catch (headerEx) {
						var msg = "AjaxAppender.append: your browser's XMLHttpRequest implementation" +
							" does not support setRequestHeader, therefore cannot post data. AjaxAppender disabled";
						handleError(msg);
						isSupported = false;
						if (failCallback) {
							failCallback(msg);
						}
						return;
					}
					xmlHttp.send(postData);
				}
			} catch (ex) {
				var errMsg = "AjaxAppender.append: error sending log message to " + url;
				handleError(errMsg, ex);
				isSupported = false;
				if (failCallback) {
					failCallback(errMsg + ". Details: " + getExceptionStringRep(ex));
				}
			}
		}

		this.append = function(loggingEvent) {
			if (isSupported) {
				if (!initialized) {
					init();
				}
				queuedLoggingEvents.push(loggingEvent);
				var actualBatchSize = this.getLayout().allowBatching() ? batchSize : 1;

				if (queuedLoggingEvents.length >= actualBatchSize) {
					var currentLoggingEvent;
					var batchedLoggingEvents = [];
					while ((currentLoggingEvent = queuedLoggingEvents.shift())) {
						batchedLoggingEvents.push(currentLoggingEvent);
					}
					// Queue this batch of log entries
					queuedRequests.push(batchedLoggingEvents);

					// If using a timer, the queue of requests will be processed by the
					// timer function, so nothing needs to be done here.
					if (!timed && (!waitForResponse || (waitForResponse && !sending))) {
                        sendAll();
					}
				}
			}
		};

		function init() {
			initialized = true;
			// Add unload event to send outstanding messages
			if (sendAllOnUnload) {
				addEvent(window, "unload", sendAllRemaining);
			}
			// Start timer
			if (timed) {
				scheduleSending();
			}
		}
	}

	AjaxAppender.prototype = new Appender();

	AjaxAppender.prototype.defaults = {
		waitForResponse: false,
		timed: false,
		timerInterval: 1000,
		batchSize: 1,
		sendAllOnUnload: true,
		requestSuccessCallback: null,
		failCallback: null,
		postVarName: "data"
	};

	AjaxAppender.prototype.layout = new HttpPostDataLayout();

	AjaxAppender.prototype.toString = function() {
		return "AjaxAppender";
	};

	log4javascript.AjaxAppender = AjaxAppender;
	/* ---------------------------------------------------------------------- */
	// PopUpAppender and InPageAppender related

	function setCookie(name, value, days, path) {
	    var expires;
	    path = path ? "; path=" + path : "";
		if (days) {
			var date = new Date();
			date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
			expires = "; expires=" + date.toGMTString();
		} else {
		    expires = "";
	    }
		document.cookie = escape(name) + "=" + escape(value) + expires + path;
	}

	function getCookie(name) {
		var nameEquals = escape(name) + "=";
		var ca = document.cookie.split(";");
		for (var i = 0, len = ca.length; i < len; i++) {
			var c = ca[i];
			while (c.charAt(0) === " ") {
			    c = c.substring(1, c.length);
			}
			if (c.indexOf(nameEquals) === 0) {
			    return unescape(c.substring(nameEquals.length, c.length));
	        }
		}
		return null;
	}

	// Gets the base URL of the location of the log4javascript script.
	// This is far from infallible.
	function getBaseUrl() {
		var scripts = document.getElementsByTagName("script");
		for (var i = 0, len = scripts.length; i < len; ++i) {
			if (scripts[i].src.indexOf("log4javascript") != -1) {
				var lastSlash = scripts[i].src.lastIndexOf("/");
				return (lastSlash == -1) ? "" : scripts[i].src.substr(0, lastSlash + 1);
			}
		}
        return null;
    }

	function isLoaded(win) {
		try {
			return bool(win.loaded);
		} catch (ex) {
			return false;
		}
	}

	/* ---------------------------------------------------------------------- */
	// ConsoleAppender (prototype for PopUpAppender and InPageAppender)

	var ConsoleAppender;

	// Create an anonymous function to protect base console methods
	(function() {
		var getConsoleHtmlLines = function() {
			return [
'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">',
'<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">',
'	<head>',
'		<title>log4javascript</title>',
'		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />',
'		<!-- Make IE8 behave like IE7, having gone to all the trouble of making IE work -->',
'		<meta http-equiv="X-UA-Compatible" content="IE=7" />',
'		<script type="text/javascript">var isIe = false, isIePre7 = false;</script>',
'		<!--[if IE]><script type="text/javascript">isIe = true</script><![endif]-->',
'		<!--[if lt IE 7]><script type="text/javascript">isIePre7 = true</script><![endif]-->',
'		<script type="text/javascript">',
'			//<![CDATA[',
'			var loggingEnabled = true;',
'			var logQueuedEventsTimer = null;',
'			var logEntries = [];',
'			var logEntriesAndSeparators = [];',
'			var logItems = [];',
'			var renderDelay = 100;',
'			var unrenderedLogItemsExist = false;',
'			var rootGroup, currentGroup = null;',
'			var loaded = false;',
'			var currentLogItem = null;',
'			var logMainContainer;',
'',
'			function copyProperties(obj, props) {',
'				for (var i in props) {',
'					obj[i] = props[i];',
'				}',
'			}',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function LogItem() {',
'			}',
'',
'			LogItem.prototype = {',
'				mainContainer: null,',
'				wrappedContainer: null,',
'				unwrappedContainer: null,',
'				group: null,',
'',
'				appendToLog: function() {',
'					for (var i = 0, len = this.elementContainers.length; i < len; i++) {',
'						this.elementContainers[i].appendToLog();',
'					}',
'					this.group.update();',
'				},',
'',
'				doRemove: function(doUpdate, removeFromGroup) {',
'					if (this.rendered) {',
'						for (var i = 0, len = this.elementContainers.length; i < len; i++) {',
'							this.elementContainers[i].remove();',
'						}',
'						this.unwrappedElementContainer = null;',
'						this.wrappedElementContainer = null;',
'						this.mainElementContainer = null;',
'					}',
'					if (this.group && removeFromGroup) {',
'						this.group.removeChild(this, doUpdate);',
'					}',
'					if (this === currentLogItem) {',
'						currentLogItem = null;',
'					}',
'				},',
'',
'				remove: function(doUpdate, removeFromGroup) {',
'					this.doRemove(doUpdate, removeFromGroup);',
'				},',
'',
'				render: function() {},',
'',
'				accept: function(visitor) {',
'					visitor.visit(this);',
'				},',
'',
'				getUnwrappedDomContainer: function() {',
'					return this.group.unwrappedElementContainer.contentDiv;',
'				},',
'',
'				getWrappedDomContainer: function() {',
'					return this.group.wrappedElementContainer.contentDiv;',
'				},',
'',
'				getMainDomContainer: function() {',
'					return this.group.mainElementContainer.contentDiv;',
'				}',
'			};',
'',
'			LogItem.serializedItemKeys = {LOG_ENTRY: 0, GROUP_START: 1, GROUP_END: 2};',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function LogItemContainerElement() {',
'			}',
'',
'			LogItemContainerElement.prototype = {',
'				appendToLog: function() {',
'					var insertBeforeFirst = (newestAtTop && this.containerDomNode.hasChildNodes());',
'					if (insertBeforeFirst) {',
'						this.containerDomNode.insertBefore(this.mainDiv, this.containerDomNode.firstChild);',
'					} else {',
'						this.containerDomNode.appendChild(this.mainDiv);',
'					}',
'				}',
'			};',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function SeparatorElementContainer(containerDomNode) {',
'				this.containerDomNode = containerDomNode;',
'				this.mainDiv = document.createElement("div");',
'				this.mainDiv.className = "separator";',
'				this.mainDiv.innerHTML = "&nbsp;";',
'			}',
'',
'			SeparatorElementContainer.prototype = new LogItemContainerElement();',
'',
'			SeparatorElementContainer.prototype.remove = function() {',
'				this.mainDiv.parentNode.removeChild(this.mainDiv);',
'				this.mainDiv = null;',
'			};',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function Separator() {',
'				this.rendered = false;',
'			}',
'',
'			Separator.prototype = new LogItem();',
'',
'			copyProperties(Separator.prototype, {',
'				render: function() {',
'					var containerDomNode = this.group.contentDiv;',
'					if (isIe) {',
'						this.unwrappedElementContainer = new SeparatorElementContainer(this.getUnwrappedDomContainer());',
'						this.wrappedElementContainer = new SeparatorElementContainer(this.getWrappedDomContainer());',
'						this.elementContainers = [this.unwrappedElementContainer, this.wrappedElementContainer];',
'					} else {',
'						this.mainElementContainer = new SeparatorElementContainer(this.getMainDomContainer());',
'						this.elementContainers = [this.mainElementContainer];',
'					}',
'					this.content = this.formattedMessage;',
'					this.rendered = true;',
'				}',
'			});',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function GroupElementContainer(group, containerDomNode, isRoot, isWrapped) {',
'				this.group = group;',
'				this.containerDomNode = containerDomNode;',
'				this.isRoot = isRoot;',
'				this.isWrapped = isWrapped;',
'				this.expandable = false;',
'',
'				if (this.isRoot) {',
'					if (isIe) {',
'						this.contentDiv = logMainContainer.appendChild(document.createElement("div"));',
'						this.contentDiv.id = this.isWrapped ? "log_wrapped" : "log_unwrapped";',
'					} else {',
'						this.contentDiv = logMainContainer;',
'					}',
'				} else {',
'					var groupElementContainer = this;',
'					',
'					this.mainDiv = document.createElement("div");',
'					this.mainDiv.className = "group";',
'',
'					this.headingDiv = this.mainDiv.appendChild(document.createElement("div"));',
'					this.headingDiv.className = "groupheading";',
'',
'					this.expander = this.headingDiv.appendChild(document.createElement("span"));',
'					this.expander.className = "expander unselectable greyedout";',
'					this.expander.unselectable = true;',
'					var expanderText = this.group.expanded ? "-" : "+";',
'					this.expanderTextNode = this.expander.appendChild(document.createTextNode(expanderText));',
'					',
'					this.headingDiv.appendChild(document.createTextNode(" " + this.group.name));',
'',
'					this.contentDiv = this.mainDiv.appendChild(document.createElement("div"));',
'					var contentCssClass = this.group.expanded ? "expanded" : "collapsed";',
'					this.contentDiv.className = "groupcontent " + contentCssClass;',
'',
'					this.expander.onclick = function() {',
'						if (groupElementContainer.group.expandable) {',
'							groupElementContainer.group.toggleExpanded();',
'						}',
'					};',
'				}',
'			}',
'',
'			GroupElementContainer.prototype = new LogItemContainerElement();',
'',
'			copyProperties(GroupElementContainer.prototype, {',
'				toggleExpanded: function() {',
'					if (!this.isRoot) {',
'						var oldCssClass, newCssClass, expanderText;',
'						if (this.group.expanded) {',
'							newCssClass = "expanded";',
'							oldCssClass = "collapsed";',
'							expanderText = "-";',
'						} else {',
'							newCssClass = "collapsed";',
'							oldCssClass = "expanded";',
'							expanderText = "+";',
'						}',
'						replaceClass(this.contentDiv, newCssClass, oldCssClass);',
'						this.expanderTextNode.nodeValue = expanderText;',
'					}',
'				},',
'',
'				remove: function() {',
'					if (!this.isRoot) {',
'						this.headingDiv = null;',
'						this.expander.onclick = null;',
'						this.expander = null;',
'						this.expanderTextNode = null;',
'						this.contentDiv = null;',
'						this.containerDomNode = null;',
'						this.mainDiv.parentNode.removeChild(this.mainDiv);',
'						this.mainDiv = null;',
'					}',
'				},',
'',
'				reverseChildren: function() {',
'					// Invert the order of the log entries',
'					var node = null;',
'',
'					// Remove all the log container nodes',
'					var childDomNodes = [];',
'					while ((node = this.contentDiv.firstChild)) {',
'						this.contentDiv.removeChild(node);',
'						childDomNodes.push(node);',
'					}',
'',
'					// Put them all back in reverse order',
'					while ((node = childDomNodes.pop())) {',
'						this.contentDiv.appendChild(node);',
'					}',
'				},',
'',
'				update: function() {',
'					if (!this.isRoot) {',
'						if (this.group.expandable) {',
'							removeClass(this.expander, "greyedout");',
'						} else {',
'							addClass(this.expander, "greyedout");',
'						}',
'					}',
'				},',
'',
'				clear: function() {',
'					if (this.isRoot) {',
'						this.contentDiv.innerHTML = "";',
'					}',
'				}',
'			});',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function Group(name, isRoot, initiallyExpanded) {',
'				this.name = name;',
'				this.group = null;',
'				this.isRoot = isRoot;',
'				this.initiallyExpanded = initiallyExpanded;',
'				this.elementContainers = [];',
'				this.children = [];',
'				this.expanded = initiallyExpanded;',
'				this.rendered = false;',
'				this.expandable = false;',
'			}',
'',
'			Group.prototype = new LogItem();',
'',
'			copyProperties(Group.prototype, {',
'				addChild: function(logItem) {',
'					this.children.push(logItem);',
'					logItem.group = this;',
'				},',
'',
'				render: function() {',
'					if (isIe) {',
'						var unwrappedDomContainer, wrappedDomContainer;',
'						if (this.isRoot) {',
'							unwrappedDomContainer = logMainContainer;',
'							wrappedDomContainer = logMainContainer;',
'						} else {',
'							unwrappedDomContainer = this.getUnwrappedDomContainer();',
'							wrappedDomContainer = this.getWrappedDomContainer();',
'						}',
'						this.unwrappedElementContainer = new GroupElementContainer(this, unwrappedDomContainer, this.isRoot, false);',
'						this.wrappedElementContainer = new GroupElementContainer(this, wrappedDomContainer, this.isRoot, true);',
'						this.elementContainers = [this.unwrappedElementContainer, this.wrappedElementContainer];',
'					} else {',
'						var mainDomContainer = this.isRoot ? logMainContainer : this.getMainDomContainer();',
'						this.mainElementContainer = new GroupElementContainer(this, mainDomContainer, this.isRoot, false);',
'						this.elementContainers = [this.mainElementContainer];',
'					}',
'					this.rendered = true;',
'				},',
'',
'				toggleExpanded: function() {',
'					this.expanded = !this.expanded;',
'					for (var i = 0, len = this.elementContainers.length; i < len; i++) {',
'						this.elementContainers[i].toggleExpanded();',
'					}',
'				},',
'',
'				expand: function() {',
'					if (!this.expanded) {',
'						this.toggleExpanded();',
'					}',
'				},',
'',
'				accept: function(visitor) {',
'					visitor.visitGroup(this);',
'				},',
'',
'				reverseChildren: function() {',
'					if (this.rendered) {',
'						for (var i = 0, len = this.elementContainers.length; i < len; i++) {',
'							this.elementContainers[i].reverseChildren();',
'						}',
'					}',
'				},',
'',
'				update: function() {',
'					var previouslyExpandable = this.expandable;',
'					this.expandable = (this.children.length !== 0);',
'					if (this.expandable !== previouslyExpandable) {',
'						for (var i = 0, len = this.elementContainers.length; i < len; i++) {',
'							this.elementContainers[i].update();',
'						}',
'					}',
'				},',
'',
'				flatten: function() {',
'					var visitor = new GroupFlattener();',
'					this.accept(visitor);',
'					return visitor.logEntriesAndSeparators;',
'				},',
'',
'				removeChild: function(child, doUpdate) {',
'					array_remove(this.children, child);',
'					child.group = null;',
'					if (doUpdate) {',
'						this.update();',
'					}',
'				},',
'',
'				remove: function(doUpdate, removeFromGroup) {',
'					for (var i = 0, len = this.children.length; i < len; i++) {',
'						this.children[i].remove(false, false);',
'					}',
'					this.children = [];',
'					this.update();',
'					if (this === currentGroup) {',
'						currentGroup = this.group;',
'					}',
'					this.doRemove(doUpdate, removeFromGroup);',
'				},',
'',
'				serialize: function(items) {',
'					items.push([LogItem.serializedItemKeys.GROUP_START, this.name]);',
'					for (var i = 0, len = this.children.length; i < len; i++) {',
'						this.children[i].serialize(items);',
'					}',
'					if (this !== currentGroup) {',
'						items.push([LogItem.serializedItemKeys.GROUP_END]);',
'					}',
'				},',
'',
'				clear: function() {',
'					for (var i = 0, len = this.elementContainers.length; i < len; i++) {',
'						this.elementContainers[i].clear();',
'					}',
'				}',
'			});',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function LogEntryElementContainer() {',
'			}',
'',
'			LogEntryElementContainer.prototype = new LogItemContainerElement();',
'',
'			copyProperties(LogEntryElementContainer.prototype, {',
'				remove: function() {',
'					this.doRemove();',
'				},',
'',
'				doRemove: function() {',
'					this.mainDiv.parentNode.removeChild(this.mainDiv);',
'					this.mainDiv = null;',
'					this.contentElement = null;',
'					this.containerDomNode = null;',
'				},',
'',
'				setContent: function(content, wrappedContent) {',
'					if (content === this.formattedMessage) {',
'						this.contentElement.innerHTML = "";',
'						this.contentElement.appendChild(document.createTextNode(this.formattedMessage));',
'					} else {',
'						this.contentElement.innerHTML = content;',
'					}',
'				},',
'',
'				setSearchMatch: function(isMatch) {',
'					var oldCssClass = isMatch ? "searchnonmatch" : "searchmatch";',
'					var newCssClass = isMatch ? "searchmatch" : "searchnonmatch";',
'					replaceClass(this.mainDiv, newCssClass, oldCssClass);',
'				},',
'',
'				clearSearch: function() {',
'					removeClass(this.mainDiv, "searchmatch");',
'					removeClass(this.mainDiv, "searchnonmatch");',
'				}',
'			});',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function LogEntryWrappedElementContainer(logEntry, containerDomNode) {',
'				this.logEntry = logEntry;',
'				this.containerDomNode = containerDomNode;',
'				this.mainDiv = document.createElement("div");',
'				this.mainDiv.appendChild(document.createTextNode(this.logEntry.formattedMessage));',
'				this.mainDiv.className = "logentry wrapped " + this.logEntry.level;',
'				this.contentElement = this.mainDiv;',
'			}',
'',
'			LogEntryWrappedElementContainer.prototype = new LogEntryElementContainer();',
'',
'			LogEntryWrappedElementContainer.prototype.setContent = function(content, wrappedContent) {',
'				if (content === this.formattedMessage) {',
'					this.contentElement.innerHTML = "";',
'					this.contentElement.appendChild(document.createTextNode(this.formattedMessage));',
'				} else {',
'					this.contentElement.innerHTML = wrappedContent;',
'				}',
'			};',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function LogEntryUnwrappedElementContainer(logEntry, containerDomNode) {',
'				this.logEntry = logEntry;',
'				this.containerDomNode = containerDomNode;',
'				this.mainDiv = document.createElement("div");',
'				this.mainDiv.className = "logentry unwrapped " + this.logEntry.level;',
'				this.pre = this.mainDiv.appendChild(document.createElement("pre"));',
'				this.pre.appendChild(document.createTextNode(this.logEntry.formattedMessage));',
'				this.pre.className = "unwrapped";',
'				this.contentElement = this.pre;',
'			}',
'',
'			LogEntryUnwrappedElementContainer.prototype = new LogEntryElementContainer();',
'',
'			LogEntryUnwrappedElementContainer.prototype.remove = function() {',
'				this.doRemove();',
'				this.pre = null;',
'			};',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function LogEntryMainElementContainer(logEntry, containerDomNode) {',
'				this.logEntry = logEntry;',
'				this.containerDomNode = containerDomNode;',
'				this.mainDiv = document.createElement("div");',
'				this.mainDiv.className = "logentry nonielogentry " + this.logEntry.level;',
'				this.contentElement = this.mainDiv.appendChild(document.createElement("span"));',
'				this.contentElement.appendChild(document.createTextNode(this.logEntry.formattedMessage));',
'			}',
'',
'			LogEntryMainElementContainer.prototype = new LogEntryElementContainer();',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function LogEntry(level, formattedMessage) {',
'				this.level = level;',
'				this.formattedMessage = formattedMessage;',
'				this.rendered = false;',
'			}',
'',
'			LogEntry.prototype = new LogItem();',
'',
'			copyProperties(LogEntry.prototype, {',
'				render: function() {',
'					var logEntry = this;',
'					var containerDomNode = this.group.contentDiv;',
'',
'					// Support for the CSS attribute white-space in IE for Windows is',
'					// non-existent pre version 6 and slightly odd in 6, so instead',
'					// use two different HTML elements',
'					if (isIe) {',
'						this.formattedMessage = this.formattedMessage.replace(/\\r\\n/g, "\\r"); // Workaround for IE\'s treatment of white space',
'						this.unwrappedElementContainer = new LogEntryUnwrappedElementContainer(this, this.getUnwrappedDomContainer());',
'						this.wrappedElementContainer = new LogEntryWrappedElementContainer(this, this.getWrappedDomContainer());',
'						this.elementContainers = [this.unwrappedElementContainer, this.wrappedElementContainer];',
'					} else {',
'						this.mainElementContainer = new LogEntryMainElementContainer(this, this.getMainDomContainer());',
'						this.elementContainers = [this.mainElementContainer];',
'					}',
'					this.content = this.formattedMessage;',
'					this.rendered = true;',
'				},',
'',
'				setContent: function(content, wrappedContent) {',
'					if (content != this.content) {',
'						if (isIe && (content !== this.formattedMessage)) {',
'							content = content.replace(/\\r\\n/g, "\\r"); // Workaround for IE\'s treatment of white space',
'						}',
'						for (var i = 0, len = this.elementContainers.length; i < len; i++) {',
'							this.elementContainers[i].setContent(content, wrappedContent);',
'						}',
'						this.content = content;',
'					}',
'				},',
'',
'				getSearchMatches: function() {',
'					var matches = [];',
'					var i, len;',
'					if (isIe) {',
'						var unwrappedEls = getElementsByClass(this.unwrappedElementContainer.mainDiv, "searchterm", "span");',
'						var wrappedEls = getElementsByClass(this.wrappedElementContainer.mainDiv, "searchterm", "span");',
'						for (i = 0, len = unwrappedEls.length; i < len; i++) {',
'							matches[i] = new Match(this.level, null, unwrappedEls[i], wrappedEls[i]);',
'						}',
'					} else {',
'						var els = getElementsByClass(this.mainElementContainer.mainDiv, "searchterm", "span");',
'						for (i = 0, len = els.length; i < len; i++) {',
'							matches[i] = new Match(this.level, els[i]);',
'						}',
'					}',
'					return matches;',
'				},',
'',
'				setSearchMatch: function(isMatch) {',
'					for (var i = 0, len = this.elementContainers.length; i < len; i++) {',
'						this.elementContainers[i].setSearchMatch(isMatch);',
'					}',
'				},',
'',
'				clearSearch: function() {',
'					for (var i = 0, len = this.elementContainers.length; i < len; i++) {',
'						this.elementContainers[i].clearSearch();',
'					}',
'				},',
'',
'				accept: function(visitor) {',
'					visitor.visitLogEntry(this);',
'				},',
'',
'				serialize: function(items) {',
'					items.push([LogItem.serializedItemKeys.LOG_ENTRY, this.level, this.formattedMessage]);',
'				}',
'			});',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function LogItemVisitor() {',
'			}',
'',
'			LogItemVisitor.prototype = {',
'				visit: function(logItem) {',
'				},',
'',
'				visitParent: function(logItem) {',
'					if (logItem.group) {',
'						logItem.group.accept(this);',
'					}',
'				},',
'',
'				visitChildren: function(logItem) {',
'					for (var i = 0, len = logItem.children.length; i < len; i++) {',
'						logItem.children[i].accept(this);',
'					}',
'				},',
'',
'				visitLogEntry: function(logEntry) {',
'					this.visit(logEntry);',
'				},',
'',
'				visitSeparator: function(separator) {',
'					this.visit(separator);',
'				},',
'',
'				visitGroup: function(group) {',
'					this.visit(group);',
'				}',
'			};',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function GroupFlattener() {',
'				this.logEntriesAndSeparators = [];',
'			}',
'',
'			GroupFlattener.prototype = new LogItemVisitor();',
'',
'			GroupFlattener.prototype.visitGroup = function(group) {',
'				this.visitChildren(group);',
'			};',
'',
'			GroupFlattener.prototype.visitLogEntry = function(logEntry) {',
'				this.logEntriesAndSeparators.push(logEntry);',
'			};',
'',
'			GroupFlattener.prototype.visitSeparator = function(separator) {',
'				this.logEntriesAndSeparators.push(separator);',
'			};',
'',
'			/*----------------------------------------------------------------*/',
'',
'			window.onload = function() {',
'				// Sort out document.domain',
'				if (location.search) {',
'					var queryBits = unescape(location.search).substr(1).split("&"), nameValueBits;',
'					for (var i = 0, len = queryBits.length; i < len; i++) {',
'						nameValueBits = queryBits[i].split("=");',
'						if (nameValueBits[0] == "log4javascript_domain") {',
'							document.domain = nameValueBits[1];',
'							break;',
'						}',
'					}',
'				}',
'',
'				// Create DOM objects',
'				logMainContainer = $("log");',
'				if (isIePre7) {',
'					addClass(logMainContainer, "oldIe");',
'				}',
'',
'				rootGroup = new Group("root", true);',
'				rootGroup.render();',
'				currentGroup = rootGroup;',
'				',
'				setCommandInputWidth();',
'				setLogContainerHeight();',
'				toggleLoggingEnabled();',
'				toggleSearchEnabled();',
'				toggleSearchFilter();',
'				toggleSearchHighlight();',
'				applyFilters();',
'				checkAllLevels();',
'				toggleWrap();',
'				toggleNewestAtTop();',
'				toggleScrollToLatest();',
'				renderQueuedLogItems();',
'				loaded = true;',
'				$("command").value = "";',
'				$("command").autocomplete = "off";',
'				$("command").onkeydown = function(evt) {',
'					evt = getEvent(evt);',
'					if (evt.keyCode == 10 || evt.keyCode == 13) { // Return/Enter',
'						evalCommandLine();',
'						stopPropagation(evt);',
'					} else if (evt.keyCode == 27) { // Escape',
'						this.value = "";',
'						this.focus();',
'					} else if (evt.keyCode == 38 && commandHistory.length > 0) { // Up',
'						currentCommandIndex = Math.max(0, currentCommandIndex - 1);',
'						this.value = commandHistory[currentCommandIndex];',
'						moveCaretToEnd(this);',
'					} else if (evt.keyCode == 40 && commandHistory.length > 0) { // Down',
'						currentCommandIndex = Math.min(commandHistory.length - 1, currentCommandIndex + 1);',
'						this.value = commandHistory[currentCommandIndex];',
'						moveCaretToEnd(this);',
'					}',
'				};',
'',
'				// Prevent the keypress moving the caret in Firefox',
'				$("command").onkeypress = function(evt) {',
'					evt = getEvent(evt);',
'					if (evt.keyCode == 38 && commandHistory.length > 0 && evt.preventDefault) { // Up',
'						evt.preventDefault();',
'					}',
'				};',
'',
'				// Prevent the keyup event blurring the input in Opera',
'				$("command").onkeyup = function(evt) {',
'					evt = getEvent(evt);',
'					if (evt.keyCode == 27 && evt.preventDefault) { // Up',
'						evt.preventDefault();',
'						this.focus();',
'					}',
'				};',
'',
'				// Add document keyboard shortcuts',
'				document.onkeydown = function keyEventHandler(evt) {',
'					evt = getEvent(evt);',
'					switch (evt.keyCode) {',
'						case 69: // Ctrl + shift + E: re-execute last command',
'							if (evt.shiftKey && (evt.ctrlKey || evt.metaKey)) {',
'								evalLastCommand();',
'								cancelKeyEvent(evt);',
'								return false;',
'							}',
'							break;',
'						case 75: // Ctrl + shift + K: focus search',
'							if (evt.shiftKey && (evt.ctrlKey || evt.metaKey)) {',
'								focusSearch();',
'								cancelKeyEvent(evt);',
'								return false;',
'							}',
'							break;',
'						case 40: // Ctrl + shift + down arrow: focus command line',
'						case 76: // Ctrl + shift + L: focus command line',
'							if (evt.shiftKey && (evt.ctrlKey || evt.metaKey)) {',
'								focusCommandLine();',
'								cancelKeyEvent(evt);',
'								return false;',
'							}',
'							break;',
'					}',
'				};',
'',
'				// Workaround to make sure log div starts at the correct size',
'				setTimeout(setLogContainerHeight, 20);',
'',
'				setShowCommandLine(showCommandLine);',
'				doSearch();',
'			};',
'',
'			window.onunload = function() {',
'				if (mainWindowExists()) {',
'					appender.unload();',
'				}',
'				appender = null;',
'			};',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function toggleLoggingEnabled() {',
'				setLoggingEnabled($("enableLogging").checked);',
'			}',
'',
'			function setLoggingEnabled(enable) {',
'				loggingEnabled = enable;',
'			}',
'',
'			var appender = null;',
'',
'			function setAppender(appenderParam) {',
'				appender = appenderParam;',
'			}',
'',
'			function setShowCloseButton(showCloseButton) {',
'				$("closeButton").style.display = showCloseButton ? "inline" : "none";',
'			}',
'',
'			function setShowHideButton(showHideButton) {',
'				$("hideButton").style.display = showHideButton ? "inline" : "none";',
'			}',
'',
'			var newestAtTop = false;',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function LogItemContentReverser() {',
'			}',
'			',
'			LogItemContentReverser.prototype = new LogItemVisitor();',
'			',
'			LogItemContentReverser.prototype.visitGroup = function(group) {',
'				group.reverseChildren();',
'				this.visitChildren(group);',
'			};',
'',
'			/*----------------------------------------------------------------*/',
'',
'			function setNewestAtTop(isNewestAtTop) {',
'				var oldNewestAtTop = newestAtTop;',
'				var i, iLen, j, jLen;',
'				newestAtTop = Boolean(isNewestAtTop);',
'				if (oldNewestAtTop != newestAtTop) {',
'					var visitor = new LogItemContentReverser();',
'					rootGroup.accept(visitor);',
'',
'					// Reassemble the matches array',
'					if (currentSearch) {',
'						var currentMatch = currentSearch.matches[currentMatchIndex];',
'						var matchIndex = 0;',
'						var matches = [];',
'						var actOnLogEntry = function(logEntry) {',
'							var logEntryMatches = logEntry.getSearchMatches();',
'							for (j = 0, jLen = logEntryMatches.length; j < jLen; j++) {',
'								matches[matchIndex] = logEntryMatches[j];',
'								if (currentMatch && logEntryMatches[j].equals(currentMatch)) {',
'									currentMatchIndex = matchIndex;',
'								}',
'								matchIndex++;',
'							}',
'						};',
'						if (newestAtTop) {',
'							for (i = logEntries.length - 1; i >= 0; i--) {',
'								actOnLogEntry(logEntries[i]);',
'							}',
'						} else {',
'							for (i = 0, iLen = logEntries.length; i < iLen; i++) {',
'								actOnLogEntry(logEntries[i]);',
'							}',
'						}',
'						currentSearch.matches = matches;',
'						if (currentMatch) {',
'							currentMatch.setCurrent();',
'						}',
'					} else if (scrollToLatest) {',
'						doScrollToLatest();',
'					}',
'				}',
'				$("newestAtTop").checked = isNewestAtTop;',
'			}',
'',
'			function toggleNewestAtTop() {',
'				var isNewestAtTop = $("newestAtTop").checked;',
'				setNewestAtTop(isNewestAtTop);',
'			}',
'',
'			var scrollToLatest = true;',
'',
'			function setScrollToLatest(isScrollToLatest) {',
'				scrollToLatest = isScrollToLatest;',
'				if (scrollToLatest) {',
'					doScrollToLatest();',
'				}',
'				$("scrollToLatest").checked = isScrollToLatest;',
'			}',
'',
'			function toggleScrollToLatest() {',
'				var isScrollToLatest = $("scrollToLatest").checked;',
'				setScrollToLatest(isScrollToLatest);',
'			}',
'',
'			function doScrollToLatest() {',
'				var l = logMainContainer;',
'				if (typeof l.scrollTop != "undefined") {',
'					if (newestAtTop) {',
'						l.scrollTop = 0;',
'					} else {',
'						var latestLogEntry = l.lastChild;',
'						if (latestLogEntry) {',
'							l.scrollTop = l.scrollHeight;',
'						}',
'					}',
'				}',
'			}',
'',
'			var closeIfOpenerCloses = true;',
'',
'			function setCloseIfOpenerCloses(isCloseIfOpenerCloses) {',
'				closeIfOpenerCloses = isCloseIfOpenerCloses;',
'			}',
'',
'			var maxMessages = null;',
'',
'			function setMaxMessages(max) {',
'				maxMessages = max;',
'				pruneLogEntries();',
'			}',
'',
'			var showCommandLine = false;',
'',
'			function setShowCommandLine(isShowCommandLine) {',
'				showCommandLine = isShowCommandLine;',
'				if (loaded) {',
'					$("commandLine").style.display = showCommandLine ? "block" : "none";',
'					setCommandInputWidth();',
'					setLogContainerHeight();',
'				}',
'			}',
'',
'			function focusCommandLine() {',
'				if (loaded) {',
'					$("command").focus();',
'				}',
'			}',
'',
'			function focusSearch() {',
'				if (loaded) {',
'					$("searchBox").focus();',
'				}',
'			}',
'',
'			function getLogItems() {',
'				var items = [];',
'				for (var i = 0, len = logItems.length; i < len; i++) {',
'					logItems[i].serialize(items);',
'				}',
'				return items;',
'			}',
'',
'			function setLogItems(items) {',
'				var loggingReallyEnabled = loggingEnabled;',
'				// Temporarily turn logging on',
'				loggingEnabled = true;',
'				for (var i = 0, len = items.length; i < len; i++) {',
'					switch (items[i][0]) {',
'						case LogItem.serializedItemKeys.LOG_ENTRY:',
'							log(items[i][1], items[i][2]);',
'							break;',
'						case LogItem.serializedItemKeys.GROUP_START:',
'							group(items[i][1]);',
'							break;',
'						case LogItem.serializedItemKeys.GROUP_END:',
'							groupEnd();',
'							break;',
'					}',
'				}',
'				loggingEnabled = loggingReallyEnabled;',
'			}',
'',
'			function log(logLevel, formattedMessage) {',
'				if (loggingEnabled) {',
'					var logEntry = new LogEntry(logLevel, formattedMessage);',
'					logEntries.push(logEntry);',
'					logEntriesAndSeparators.push(logEntry);',
'					logItems.push(logEntry);',
'					currentGroup.addChild(logEntry);',
'					if (loaded) {',
'						if (logQueuedEventsTimer !== null) {',
'							clearTimeout(logQueuedEventsTimer);',
'						}',
'						logQueuedEventsTimer = setTimeout(renderQueuedLogItems, renderDelay);',
'						unrenderedLogItemsExist = true;',
'					}',
'				}',
'			}',
'',
'			function renderQueuedLogItems() {',
'				logQueuedEventsTimer = null;',
'				var pruned = pruneLogEntries();',
'',
'				// Render any unrendered log entries and apply the current search to them',
'				var initiallyHasMatches = currentSearch ? currentSearch.hasMatches() : false;',
'				for (var i = 0, len = logItems.length; i < len; i++) {',
'					if (!logItems[i].rendered) {',
'						logItems[i].render();',
'						logItems[i].appendToLog();',
'						if (currentSearch && (logItems[i] instanceof LogEntry)) {',
'							currentSearch.applyTo(logItems[i]);',
'						}',
'					}',
'				}',
'				if (currentSearch) {',
'					if (pruned) {',
'						if (currentSearch.hasVisibleMatches()) {',
'							if (currentMatchIndex === null) {',
'								setCurrentMatchIndex(0);',
'							}',
'							displayMatches();',
'						} else {',
'							displayNoMatches();',
'						}',
'					} else if (!initiallyHasMatches && currentSearch.hasVisibleMatches()) {',
'						setCurrentMatchIndex(0);',
'						displayMatches();',
'					}',
'				}',
'				if (scrollToLatest) {',
'					doScrollToLatest();',
'				}',
'				unrenderedLogItemsExist = false;',
'			}',
'',
'			function pruneLogEntries() {',
'				if ((maxMessages !== null) && (logEntriesAndSeparators.length > maxMessages)) {',
'					var numberToDelete = logEntriesAndSeparators.length - maxMessages;',
'					var prunedLogEntries = logEntriesAndSeparators.slice(0, numberToDelete);',
'					if (currentSearch) {',
'						currentSearch.removeMatches(prunedLogEntries);',
'					}',
'					var group;',
'					for (var i = 0; i < numberToDelete; i++) {',
'						group = logEntriesAndSeparators[i].group;',
'						array_remove(logItems, logEntriesAndSeparators[i]);',
'						array_remove(logEntries, logEntriesAndSeparators[i]);',
'						logEntriesAndSeparators[i].remove(true, true);',
'						if (group.children.length === 0 && group !== currentGroup && group !== rootGroup) {',
'							array_remove(logItems, group);',
'							group.remove(true, true);',
'						}',
'					}',
'					logEntriesAndSeparators = array_removeFromStart(logEntriesAndSeparators, numberToDelete);',
'					return true;',
'				}',
'				return false;',
'			}',
'',
'			function group(name, startExpanded) {',
'				if (loggingEnabled) {',
'					initiallyExpanded = (typeof startExpanded === "undefined") ? true : Boolean(startExpanded);',
'					var newGroup = new Group(name, false, initiallyExpanded);',
'					currentGroup.addChild(newGroup);',
'					currentGroup = newGroup;',
'					logItems.push(newGroup);',
'					if (loaded) {',
'						if (logQueuedEventsTimer !== null) {',
'							clearTimeout(logQueuedEventsTimer);',
'						}',
'						logQueuedEventsTimer = setTimeout(renderQueuedLogItems, renderDelay);',
'						unrenderedLogItemsExist = true;',
'					}',
'				}',
'			}',
'',
'			function groupEnd() {',
'				currentGroup = (currentGroup === rootGroup) ? rootGroup : currentGroup.group;',
'			}',
'',
'			function mainPageReloaded() {',
'				currentGroup = rootGroup;',
'				var separator = new Separator();',
'				logEntriesAndSeparators.push(separator);',
'				logItems.push(separator);',
'				currentGroup.addChild(separator);',
'			}',
'',
'			function closeWindow() {',
'				if (appender && mainWindowExists()) {',
'					appender.close(true);',
'				} else {',
'					window.close();',
'				}',
'			}',
'',
'			function hide() {',
'				if (appender && mainWindowExists()) {',
'					appender.hide();',
'				}',
'			}',
'',
'			var mainWindow = window;',
'			var windowId = "log4javascriptConsoleWindow_" + new Date().getTime() + "_" + ("" + Math.random()).substr(2);',
'',
'			function setMainWindow(win) {',
'				mainWindow = win;',
'				mainWindow[windowId] = window;',
'				// If this is a pop-up, poll the opener to see if it\'s closed',
'				if (opener && closeIfOpenerCloses) {',
'					pollOpener();',
'				}',
'			}',
'',
'			function pollOpener() {',
'				if (closeIfOpenerCloses) {',
'					if (mainWindowExists()) {',
'						setTimeout(pollOpener, 500);',
'					} else {',
'						closeWindow();',
'					}',
'				}',
'			}',
'',
'			function mainWindowExists() {',
'				try {',
'					return (mainWindow && !mainWindow.closed &&',
'						mainWindow[windowId] == window);',
'				} catch (ex) {}',
'				return false;',
'			}',
'',
'			var logLevels = ["TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"];',
'',
'			function getCheckBox(logLevel) {',
'				return $("switch_" + logLevel);',
'			}',
'',
'			function getIeWrappedLogContainer() {',
'				return $("log_wrapped");',
'			}',
'',
'			function getIeUnwrappedLogContainer() {',
'				return $("log_unwrapped");',
'			}',
'',
'			function applyFilters() {',
'				for (var i = 0; i < logLevels.length; i++) {',
'					if (getCheckBox(logLevels[i]).checked) {',
'						addClass(logMainContainer, logLevels[i]);',
'					} else {',
'						removeClass(logMainContainer, logLevels[i]);',
'					}',
'				}',
'				updateSearchFromFilters();',
'			}',
'',
'			function toggleAllLevels() {',
'				var turnOn = $("switch_ALL").checked;',
'				for (var i = 0; i < logLevels.length; i++) {',
'					getCheckBox(logLevels[i]).checked = turnOn;',
'					if (turnOn) {',
'						addClass(logMainContainer, logLevels[i]);',
'					} else {',
'						removeClass(logMainContainer, logLevels[i]);',
'					}',
'				}',
'			}',
'',
'			function checkAllLevels() {',
'				for (var i = 0; i < logLevels.length; i++) {',
'					if (!getCheckBox(logLevels[i]).checked) {',
'						getCheckBox("ALL").checked = false;',
'						return;',
'					}',
'				}',
'				getCheckBox("ALL").checked = true;',
'			}',
'',
'			function clearLog() {',
'				rootGroup.clear();',
'				currentGroup = rootGroup;',
'				logEntries = [];',
'				logItems = [];',
'				logEntriesAndSeparators = [];',
' 				doSearch();',
'			}',
'',
'			function toggleWrap() {',
'				var enable = $("wrap").checked;',
'				if (enable) {',
'					addClass(logMainContainer, "wrap");',
'				} else {',
'					removeClass(logMainContainer, "wrap");',
'				}',
'				refreshCurrentMatch();',
'			}',
'',
'			/* ------------------------------------------------------------------- */',
'',
'			// Search',
'',
'			var searchTimer = null;',
'',
'			function scheduleSearch() {',
'				try {',
'					clearTimeout(searchTimer);',
'				} catch (ex) {',
'					// Do nothing',
'				}',
'				searchTimer = setTimeout(doSearch, 500);',
'			}',
'',
'			function Search(searchTerm, isRegex, searchRegex, isCaseSensitive) {',
'				this.searchTerm = searchTerm;',
'				this.isRegex = isRegex;',
'				this.searchRegex = searchRegex;',
'				this.isCaseSensitive = isCaseSensitive;',
'				this.matches = [];',
'			}',
'',
'			Search.prototype = {',
'				hasMatches: function() {',
'					return this.matches.length > 0;',
'				},',
'',
'				hasVisibleMatches: function() {',
'					if (this.hasMatches()) {',
'						for (var i = 0; i < this.matches.length; i++) {',
'							if (this.matches[i].isVisible()) {',
'								return true;',
'							}',
'						}',
'					}',
'					return false;',
'				},',
'',
'				match: function(logEntry) {',
'					var entryText = String(logEntry.formattedMessage);',
'					var matchesSearch = false;',
'					if (this.isRegex) {',
'						matchesSearch = this.searchRegex.test(entryText);',
'					} else if (this.isCaseSensitive) {',
'						matchesSearch = (entryText.indexOf(this.searchTerm) > -1);',
'					} else {',
'						matchesSearch = (entryText.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1);',
'					}',
'					return matchesSearch;',
'				},',
'',
'				getNextVisibleMatchIndex: function() {',
'					for (var i = currentMatchIndex + 1; i < this.matches.length; i++) {',
'						if (this.matches[i].isVisible()) {',
'							return i;',
'						}',
'					}',
'					// Start again from the first match',
'					for (i = 0; i <= currentMatchIndex; i++) {',
'						if (this.matches[i].isVisible()) {',
'							return i;',
'						}',
'					}',
'					return -1;',
'				},',
'',
'				getPreviousVisibleMatchIndex: function() {',
'					for (var i = currentMatchIndex - 1; i >= 0; i--) {',
'						if (this.matches[i].isVisible()) {',
'							return i;',
'						}',
'					}',
'					// Start again from the last match',
'					for (var i = this.matches.length - 1; i >= currentMatchIndex; i--) {',
'						if (this.matches[i].isVisible()) {',
'							return i;',
'						}',
'					}',
'					return -1;',
'				},',
'',
'				applyTo: function(logEntry) {',
'					var doesMatch = this.match(logEntry);',
'					if (doesMatch) {',
'						logEntry.group.expand();',
'						logEntry.setSearchMatch(true);',
'						var logEntryContent;',
'						var wrappedLogEntryContent;',
'						var searchTermReplacementStartTag = "<span class=\\\"searchterm\\\">";',
'						var searchTermReplacementEndTag = "<" + "/span>";',
'						var preTagName = isIe ? "pre" : "span";',
'						var preStartTag = "<" + preTagName + " class=\\\"pre\\\">";',
'						var preEndTag = "<" + "/" + preTagName + ">";',
'						var startIndex = 0;',
'						var searchIndex, matchedText, textBeforeMatch;',
'						if (this.isRegex) {',
'							var flags = this.isCaseSensitive ? "g" : "gi";',
'							var capturingRegex = new RegExp("(" + this.searchRegex.source + ")", flags);',
'',
'							// Replace the search term with temporary tokens for the start and end tags',
'							var rnd = ("" + Math.random()).substr(2);',
'							var startToken = "%%s" + rnd + "%%";',
'							var endToken = "%%e" + rnd + "%%";',
'							logEntryContent = logEntry.formattedMessage.replace(capturingRegex, startToken + "$1" + endToken);',
'',
'							// Escape the HTML to get rid of angle brackets',
'							logEntryContent = escapeHtml(logEntryContent);',
'',
'							// Substitute the proper HTML back in for the search match',
'							var result;',
'							var searchString = logEntryContent;',
'							logEntryContent = "";',
'							wrappedLogEntryContent = "";',
'							while ((searchIndex = searchString.indexOf(startToken, startIndex)) > -1) {',
'								var endTokenIndex = searchString.indexOf(endToken, searchIndex);',
'								matchedText = searchString.substring(searchIndex + startToken.length, endTokenIndex);',
'								textBeforeMatch = searchString.substring(startIndex, searchIndex);',
'								logEntryContent += preStartTag + textBeforeMatch + preEndTag;',
'								logEntryContent += searchTermReplacementStartTag + preStartTag + matchedText +',
'									preEndTag + searchTermReplacementEndTag;',
'								if (isIe) {',
'									wrappedLogEntryContent += textBeforeMatch + searchTermReplacementStartTag +',
'										matchedText + searchTermReplacementEndTag;',
'								}',
'								startIndex = endTokenIndex + endToken.length;',
'							}',
'							logEntryContent += preStartTag + searchString.substr(startIndex) + preEndTag;',
'							if (isIe) {',
'								wrappedLogEntryContent += searchString.substr(startIndex);',
'							}',
'						} else {',
'							logEntryContent = "";',
'							wrappedLogEntryContent = "";',
'							var searchTermReplacementLength = searchTermReplacementStartTag.length +',
'								this.searchTerm.length + searchTermReplacementEndTag.length;',
'							var searchTermLength = this.searchTerm.length;',
'							var searchTermLowerCase = this.searchTerm.toLowerCase();',
'							var logTextLowerCase = logEntry.formattedMessage.toLowerCase();',
'							while ((searchIndex = logTextLowerCase.indexOf(searchTermLowerCase, startIndex)) > -1) {',
'								matchedText = escapeHtml(logEntry.formattedMessage.substr(searchIndex, this.searchTerm.length));',
'								textBeforeMatch = escapeHtml(logEntry.formattedMessage.substring(startIndex, searchIndex));',
'								var searchTermReplacement = searchTermReplacementStartTag +',
'									preStartTag + matchedText + preEndTag + searchTermReplacementEndTag;',
'								logEntryContent += preStartTag + textBeforeMatch + preEndTag + searchTermReplacement;',
'								if (isIe) {',
'									wrappedLogEntryContent += textBeforeMatch + searchTermReplacementStartTag +',
'										matchedText + searchTermReplacementEndTag;',
'								}',
'								startIndex = searchIndex + searchTermLength;',
'							}',
'							var textAfterLastMatch = escapeHtml(logEntry.formattedMessage.substr(startIndex));',
'							logEntryContent += preStartTag + textAfterLastMatch + preEndTag;',
'							if (isIe) {',
'								wrappedLogEntryContent += textAfterLastMatch;',
'							}',
'						}',
'						logEntry.setContent(logEntryContent, wrappedLogEntryContent);',
'						var logEntryMatches = logEntry.getSearchMatches();',
'						this.matches = this.matches.concat(logEntryMatches);',
'					} else {',
'						logEntry.setSearchMatch(false);',
'						logEntry.setContent(logEntry.formattedMessage, logEntry.formattedMessage);',
'					}',
'					return doesMatch;',
'				},',
'',
'				removeMatches: function(logEntries) {',
'					var matchesToRemoveCount = 0;',
'					var currentMatchRemoved = false;',
'					var matchesToRemove = [];',
'					var i, iLen, j, jLen;',
'',
'					// Establish the list of matches to be removed',
'					for (i = 0, iLen = this.matches.length; i < iLen; i++) {',
'						for (j = 0, jLen = logEntries.length; j < jLen; j++) {',
'							if (this.matches[i].belongsTo(logEntries[j])) {',
'								matchesToRemove.push(this.matches[i]);',
'								if (i === currentMatchIndex) {',
'									currentMatchRemoved = true;',
'								}',
'							}',
'						}',
'					}',
'',
'					// Set the new current match index if the current match has been deleted',
'					// This will be the first match that appears after the first log entry being',
'					// deleted, if one exists; otherwise, it\'s the first match overall',
'					var newMatch = currentMatchRemoved ? null : this.matches[currentMatchIndex];',
'					if (currentMatchRemoved) {',
'						for (i = currentMatchIndex, iLen = this.matches.length; i < iLen; i++) {',
'							if (this.matches[i].isVisible() && !array_contains(matchesToRemove, this.matches[i])) {',
'								newMatch = this.matches[i];',
'								break;',
'							}',
'						}',
'					}',
'',
'					// Remove the matches',
'					for (i = 0, iLen = matchesToRemove.length; i < iLen; i++) {',
'						array_remove(this.matches, matchesToRemove[i]);',
'						matchesToRemove[i].remove();',
'					}',
'',
'					// Set the new match, if one exists',
'					if (this.hasVisibleMatches()) {',
'						if (newMatch === null) {',
'							setCurrentMatchIndex(0);',
'						} else {',
'							// Get the index of the new match',
'							var newMatchIndex = 0;',
'							for (i = 0, iLen = this.matches.length; i < iLen; i++) {',
'								if (newMatch === this.matches[i]) {',
'									newMatchIndex = i;',
'									break;',
'								}',
'							}',
'							setCurrentMatchIndex(newMatchIndex);',
'						}',
'					} else {',
'						currentMatchIndex = null;',
'						displayNoMatches();',
'					}',
'				}',
'			};',
'',
'			function getPageOffsetTop(el, container) {',
'				var currentEl = el;',
'				var y = 0;',
'				while (currentEl && currentEl != container) {',
'					y += currentEl.offsetTop;',
'					currentEl = currentEl.offsetParent;',
'				}',
'				return y;',
'			}',
'',
'			function scrollIntoView(el) {',
'				var logContainer = logMainContainer;',
'				// Check if the whole width of the element is visible and centre if not',
'				if (!$("wrap").checked) {',
'					var logContainerLeft = logContainer.scrollLeft;',
'					var logContainerRight = logContainerLeft  + logContainer.offsetWidth;',
'					var elLeft = el.offsetLeft;',
'					var elRight = elLeft + el.offsetWidth;',
'					if (elLeft < logContainerLeft || elRight > logContainerRight) {',
'						logContainer.scrollLeft = elLeft - (logContainer.offsetWidth - el.offsetWidth) / 2;',
'					}',
'				}',
'				// Check if the whole height of the element is visible and centre if not',
'				var logContainerTop = logContainer.scrollTop;',
'				var logContainerBottom = logContainerTop  + logContainer.offsetHeight;',
'				var elTop = getPageOffsetTop(el) - getToolBarsHeight();',
'				var elBottom = elTop + el.offsetHeight;',
'				if (elTop < logContainerTop || elBottom > logContainerBottom) {',
'					logContainer.scrollTop = elTop - (logContainer.offsetHeight - el.offsetHeight) / 2;',
'				}',
'			}',
'',
'			function Match(logEntryLevel, spanInMainDiv, spanInUnwrappedPre, spanInWrappedDiv) {',
'				this.logEntryLevel = logEntryLevel;',
'				this.spanInMainDiv = spanInMainDiv;',
'				if (isIe) {',
'					this.spanInUnwrappedPre = spanInUnwrappedPre;',
'					this.spanInWrappedDiv = spanInWrappedDiv;',
'				}',
'				this.mainSpan = isIe ? spanInUnwrappedPre : spanInMainDiv;',
'			}',
'',
'			Match.prototype = {',
'				equals: function(match) {',
'					return this.mainSpan === match.mainSpan;',
'				},',
'',
'				setCurrent: function() {',
'					if (isIe) {',
'						addClass(this.spanInUnwrappedPre, "currentmatch");',
'						addClass(this.spanInWrappedDiv, "currentmatch");',
'						// Scroll the visible one into view',
'						var elementToScroll = $("wrap").checked ? this.spanInWrappedDiv : this.spanInUnwrappedPre;',
'						scrollIntoView(elementToScroll);',
'					} else {',
'						addClass(this.spanInMainDiv, "currentmatch");',
'						scrollIntoView(this.spanInMainDiv);',
'					}',
'				},',
'',
'				belongsTo: function(logEntry) {',
'					if (isIe) {',
'						return isDescendant(this.spanInUnwrappedPre, logEntry.unwrappedPre);',
'					} else {',
'						return isDescendant(this.spanInMainDiv, logEntry.mainDiv);',
'					}',
'				},',
'',
'				setNotCurrent: function() {',
'					if (isIe) {',
'						removeClass(this.spanInUnwrappedPre, "currentmatch");',
'						removeClass(this.spanInWrappedDiv, "currentmatch");',
'					} else {',
'						removeClass(this.spanInMainDiv, "currentmatch");',
'					}',
'				},',
'',
'				isOrphan: function() {',
'					return isOrphan(this.mainSpan);',
'				},',
'',
'				isVisible: function() {',
'					return getCheckBox(this.logEntryLevel).checked;',
'				},',
'',
'				remove: function() {',
'					if (isIe) {',
'						this.spanInUnwrappedPre = null;',
'						this.spanInWrappedDiv = null;',
'					} else {',
'						this.spanInMainDiv = null;',
'					}',
'				}',
'			};',
'',
'			var currentSearch = null;',
'			var currentMatchIndex = null;',
'',
'			function doSearch() {',
'				var searchBox = $("searchBox");',
'				var searchTerm = searchBox.value;',
'				var isRegex = $("searchRegex").checked;',
'				var isCaseSensitive = $("searchCaseSensitive").checked;',
'				var i;',
'',
'				if (searchTerm === "") {',
'					$("searchReset").disabled = true;',
'					$("searchNav").style.display = "none";',
'					removeClass(document.body, "searching");',
'					removeClass(searchBox, "hasmatches");',
'					removeClass(searchBox, "nomatches");',
'					for (i = 0; i < logEntries.length; i++) {',
'						logEntries[i].clearSearch();',
'						logEntries[i].setContent(logEntries[i].formattedMessage, logEntries[i].formattedMessage);',
'					}',
'					currentSearch = null;',
'					setLogContainerHeight();',
'				} else {',
'					$("searchReset").disabled = false;',
'					$("searchNav").style.display = "block";',
'					var searchRegex;',
'					var regexValid;',
'					if (isRegex) {',
'						try {',
'							searchRegex = isCaseSensitive ? new RegExp(searchTerm, "g") : new RegExp(searchTerm, "gi");',
'							regexValid = true;',
'							replaceClass(searchBox, "validregex", "invalidregex");',
'							searchBox.title = "Valid regex";',
'						} catch (ex) {',
'							regexValid = false;',
'							replaceClass(searchBox, "invalidregex", "validregex");',
'							searchBox.title = "Invalid regex: " + (ex.message ? ex.message : (ex.description ? ex.description : "unknown error"));',
'							return;',
'						}',
'					} else {',
'						searchBox.title = "";',
'						removeClass(searchBox, "validregex");',
'						removeClass(searchBox, "invalidregex");',
'					}',
'					addClass(document.body, "searching");',
'					currentSearch = new Search(searchTerm, isRegex, searchRegex, isCaseSensitive);',
'					for (i = 0; i < logEntries.length; i++) {',
'						currentSearch.applyTo(logEntries[i]);',
'					}',
'					setLogContainerHeight();',
'',
'					// Highlight the first search match',
'					if (currentSearch.hasVisibleMatches()) {',
'						setCurrentMatchIndex(0);',
'						displayMatches();',
'					} else {',
'						displayNoMatches();',
'					}',
'				}',
'			}',
'',
'			function updateSearchFromFilters() {',
'				if (currentSearch) {',
'					if (currentSearch.hasMatches()) {',
'						if (currentMatchIndex === null) {',
'							currentMatchIndex = 0;',
'						}',
'						var currentMatch = currentSearch.matches[currentMatchIndex];',
'						if (currentMatch.isVisible()) {',
'							displayMatches();',
'							setCurrentMatchIndex(currentMatchIndex);',
'						} else {',
'							currentMatch.setNotCurrent();',
'							// Find the next visible match, if one exists',
'							var nextVisibleMatchIndex = currentSearch.getNextVisibleMatchIndex();',
'							if (nextVisibleMatchIndex > -1) {',
'								setCurrentMatchIndex(nextVisibleMatchIndex);',
'								displayMatches();',
'							} else {',
'								displayNoMatches();',
'							}',
'						}',
'					} else {',
'						displayNoMatches();',
'					}',
'				}',
'			}',
'',
'			function refreshCurrentMatch() {',
'				if (currentSearch && currentSearch.hasVisibleMatches()) {',
'					setCurrentMatchIndex(currentMatchIndex);',
'				}',
'			}',
'',
'			function displayMatches() {',
'				replaceClass($("searchBox"), "hasmatches", "nomatches");',
'				$("searchBox").title = "" + currentSearch.matches.length + " matches found";',
'				$("searchNav").style.display = "block";',
'				setLogContainerHeight();',
'			}',
'',
'			function displayNoMatches() {',
'				replaceClass($("searchBox"), "nomatches", "hasmatches");',
'				$("searchBox").title = "No matches found";',
'				$("searchNav").style.display = "none";',
'				setLogContainerHeight();',
'			}',
'',
'			function toggleSearchEnabled(enable) {',
'				enable = (typeof enable == "undefined") ? !$("searchDisable").checked : enable;',
'				$("searchBox").disabled = !enable;',
'				$("searchReset").disabled = !enable;',
'				$("searchRegex").disabled = !enable;',
'				$("searchNext").disabled = !enable;',
'				$("searchPrevious").disabled = !enable;',
'				$("searchCaseSensitive").disabled = !enable;',
'				$("searchNav").style.display = (enable && ($("searchBox").value !== "") &&',
'						currentSearch && currentSearch.hasVisibleMatches()) ?',
'					"block" : "none";',
'				if (enable) {',
'					removeClass($("search"), "greyedout");',
'					addClass(document.body, "searching");',
'					if ($("searchHighlight").checked) {',
'						addClass(logMainContainer, "searchhighlight");',
'					} else {',
'						removeClass(logMainContainer, "searchhighlight");',
'					}',
'					if ($("searchFilter").checked) {',
'						addClass(logMainContainer, "searchfilter");',
'					} else {',
'						removeClass(logMainContainer, "searchfilter");',
'					}',
'					$("searchDisable").checked = !enable;',
'				} else {',
'					addClass($("search"), "greyedout");',
'					removeClass(document.body, "searching");',
'					removeClass(logMainContainer, "searchhighlight");',
'					removeClass(logMainContainer, "searchfilter");',
'				}',
'				setLogContainerHeight();',
'			}',
'',
'			function toggleSearchFilter() {',
'				var enable = $("searchFilter").checked;',
'				if (enable) {',
'					addClass(logMainContainer, "searchfilter");',
'				} else {',
'					removeClass(logMainContainer, "searchfilter");',
'				}',
'				refreshCurrentMatch();',
'			}',
'',
'			function toggleSearchHighlight() {',
'				var enable = $("searchHighlight").checked;',
'				if (enable) {',
'					addClass(logMainContainer, "searchhighlight");',
'				} else {',
'					removeClass(logMainContainer, "searchhighlight");',
'				}',
'			}',
'',
'			function clearSearch() {',
'				$("searchBox").value = "";',
'				doSearch();',
'			}',
'',
'			function searchNext() {',
'				if (currentSearch !== null && currentMatchIndex !== null) {',
'					currentSearch.matches[currentMatchIndex].setNotCurrent();',
'					var nextMatchIndex = currentSearch.getNextVisibleMatchIndex();',
'					if (nextMatchIndex > currentMatchIndex || confirm("Reached the end of the page. Start from the top?")) {',
'						setCurrentMatchIndex(nextMatchIndex);',
'					}',
'				}',
'			}',
'',
'			function searchPrevious() {',
'				if (currentSearch !== null && currentMatchIndex !== null) {',
'					currentSearch.matches[currentMatchIndex].setNotCurrent();',
'					var previousMatchIndex = currentSearch.getPreviousVisibleMatchIndex();',
'					if (previousMatchIndex < currentMatchIndex || confirm("Reached the start of the page. Continue from the bottom?")) {',
'						setCurrentMatchIndex(previousMatchIndex);',
'					}',
'				}',
'			}',
'',
'			function setCurrentMatchIndex(index) {',
'				currentMatchIndex = index;',
'				currentSearch.matches[currentMatchIndex].setCurrent();',
'			}',
'',
'			/* ------------------------------------------------------------------------- */',
'',
'			// CSS Utilities',
'',
'			function addClass(el, cssClass) {',
'				if (!hasClass(el, cssClass)) {',
'					if (el.className) {',
'						el.className += " " + cssClass;',
'					} else {',
'						el.className = cssClass;',
'					}',
'				}',
'			}',
'',
'			function hasClass(el, cssClass) {',
'				if (el.className) {',
'					var classNames = el.className.split(" ");',
'					return array_contains(classNames, cssClass);',
'				}',
'				return false;',
'			}',
'',
'			function removeClass(el, cssClass) {',
'				if (hasClass(el, cssClass)) {',
'					// Rebuild the className property',
'					var existingClasses = el.className.split(" ");',
'					var newClasses = [];',
'					for (var i = 0, len = existingClasses.length; i < len; i++) {',
'						if (existingClasses[i] != cssClass) {',
'							newClasses[newClasses.length] = existingClasses[i];',
'						}',
'					}',
'					el.className = newClasses.join(" ");',
'				}',
'			}',
'',
'			function replaceClass(el, newCssClass, oldCssClass) {',
'				removeClass(el, oldCssClass);',
'				addClass(el, newCssClass);',
'			}',
'',
'			/* ------------------------------------------------------------------------- */',
'',
'			// Other utility functions',
'',
'			function getElementsByClass(el, cssClass, tagName) {',
'				var elements = el.getElementsByTagName(tagName);',
'				var matches = [];',
'				for (var i = 0, len = elements.length; i < len; i++) {',
'					if (hasClass(elements[i], cssClass)) {',
'						matches.push(elements[i]);',
'					}',
'				}',
'				return matches;',
'			}',
'',
'			// Syntax borrowed from Prototype library',
'			function $(id) {',
'				return document.getElementById(id);',
'			}',
'',
'			function isDescendant(node, ancestorNode) {',
'				while (node != null) {',
'					if (node === ancestorNode) {',
'						return true;',
'					}',
'					node = node.parentNode;',
'				}',
'				return false;',
'			}',
'',
'			function isOrphan(node) {',
'				var currentNode = node;',
'				while (currentNode) {',
'					if (currentNode == document.body) {',
'						return false;',
'					}',
'					currentNode = currentNode.parentNode;',
'				}',
'				return true;',
'			}',
'',
'			function escapeHtml(str) {',
'				return str.replace(/&/g, "&amp;").replace(/[<]/g, "&lt;").replace(/>/g, "&gt;");',
'			}',
'',
'			function getWindowWidth() {',
'				if (window.innerWidth) {',
'					return window.innerWidth;',
'				} else if (document.documentElement && document.documentElement.clientWidth) {',
'					return document.documentElement.clientWidth;',
'				} else if (document.body) {',
'					return document.body.clientWidth;',
'				}',
'				return 0;',
'			}',
'',
'			function getWindowHeight() {',
'				if (window.innerHeight) {',
'					return window.innerHeight;',
'				} else if (document.documentElement && document.documentElement.clientHeight) {',
'					return document.documentElement.clientHeight;',
'				} else if (document.body) {',
'					return document.body.clientHeight;',
'				}',
'				return 0;',
'			}',
'',
'			function getToolBarsHeight() {',
'				return $("switches").offsetHeight;',
'			}',
'',
'			function getChromeHeight() {',
'				var height = getToolBarsHeight();',
'				if (showCommandLine) {',
'					height += $("commandLine").offsetHeight;',
'				}',
'				return height;',
'			}',
'',
'			function setLogContainerHeight() {',
'				if (logMainContainer) {',
'					var windowHeight = getWindowHeight();',
'					$("body").style.height = getWindowHeight() + "px";',
'					logMainContainer.style.height = "" +',
'						Math.max(0, windowHeight - getChromeHeight()) + "px";',
'				}',
'			}',
'',
'			function setCommandInputWidth() {',
'				if (showCommandLine) {',
'					$("command").style.width = "" + Math.max(0, $("commandLineContainer").offsetWidth -',
'						($("evaluateButton").offsetWidth + 13)) + "px";',
'				}',
'			}',
'',
'			window.onresize = function() {',
'				setCommandInputWidth();',
'				setLogContainerHeight();',
'			};',
'',
'			if (!Array.prototype.push) {',
'				Array.prototype.push = function() {',
'			        for (var i = 0, len = arguments.length; i < len; i++){',
'			            this[this.length] = arguments[i];',
'			        }',
'			        return this.length;',
'				};',
'			}',
'',
'			if (!Array.prototype.pop) {',
'				Array.prototype.pop = function() {',
'					if (this.length > 0) {',
'						var val = this[this.length - 1];',
'						this.length = this.length - 1;',
'						return val;',
'					}',
'				};',
'			}',
'',
'			if (!Array.prototype.shift) {',
'				Array.prototype.shift = function() {',
'					if (this.length > 0) {',
'						var firstItem = this[0];',
'						for (var i = 0, len = this.length - 1; i < len; i++) {',
'							this[i] = this[i + 1];',
'						}',
'						this.length = this.length - 1;',
'						return firstItem;',
'					}',
'				};',
'			}',
'',
'			if (!Array.prototype.splice) {',
'				Array.prototype.splice = function(startIndex, deleteCount) {',
'					var itemsAfterDeleted = this.slice(startIndex + deleteCount);',
'					var itemsDeleted = this.slice(startIndex, startIndex + deleteCount);',
'					this.length = startIndex;',
'					// Copy the arguments into a proper Array object',
'					var argumentsArray = [];',
'					for (var i = 0, len = arguments.length; i < len; i++) {',
'						argumentsArray[i] = arguments[i];',
'					}',
'					var itemsToAppend = (argumentsArray.length > 2) ?',
'						itemsAfterDeleted = argumentsArray.slice(2).concat(itemsAfterDeleted) : itemsAfterDeleted;',
'					for (i = 0, len = itemsToAppend.length; i < len; i++) {',
'						this.push(itemsToAppend[i]);',
'					}',
'					return itemsDeleted;',
'				};',
'			}',
'',
'			function array_remove(arr, val) {',
'				var index = -1;',
'				for (var i = 0, len = arr.length; i < len; i++) {',
'					if (arr[i] === val) {',
'						index = i;',
'						break;',
'					}',
'				}',
'				if (index >= 0) {',
'					arr.splice(index, 1);',
'					return index;',
'				} else {',
'					return false;',
'				}',
'			}',
'',
'			function array_removeFromStart(array, numberToRemove) {',
'				if (Array.prototype.splice) {',
'					array.splice(0, numberToRemove);',
'				} else {',
'					for (var i = numberToRemove, len = array.length; i < len; i++) {',
'						array[i - numberToRemove] = array[i];',
'					}',
'					array.length = array.length - numberToRemove;',
'				}',
'				return array;',
'			}',
'',
'			function array_contains(arr, val) {',
'				for (var i = 0, len = arr.length; i < len; i++) {',
'					if (arr[i] == val) {',
'						return true;',
'					}',
'				}',
'				return false;',
'			}',
'',
'			function getErrorMessage(ex) {',
'				if (ex.message) {',
'					return ex.message;',
'				} else if (ex.description) {',
'					return ex.description;',
'				}',
'				return "" + ex;',
'			}',
'',
'			function moveCaretToEnd(input) {',
'				if (input.setSelectionRange) {',
'					input.focus();',
'					var length = input.value.length;',
'					input.setSelectionRange(length, length);',
'				} else if (input.createTextRange) {',
'					var range = input.createTextRange();',
'					range.collapse(false);',
'					range.select();',
'				}',
'				input.focus();',
'			}',
'',
'			function stopPropagation(evt) {',
'				if (evt.stopPropagation) {',
'					evt.stopPropagation();',
'				} else if (typeof evt.cancelBubble != "undefined") {',
'					evt.cancelBubble = true;',
'				}',
'			}',
'',
'			function getEvent(evt) {',
'				return evt ? evt : event;',
'			}',
'',
'			function getTarget(evt) {',
'				return evt.target ? evt.target : evt.srcElement;',
'			}',
'',
'			function getRelatedTarget(evt) {',
'				if (evt.relatedTarget) {',
'					return evt.relatedTarget;',
'				} else if (evt.srcElement) {',
'					switch(evt.type) {',
'						case "mouseover":',
'							return evt.fromElement;',
'						case "mouseout":',
'							return evt.toElement;',
'						default:',
'							return evt.srcElement;',
'					}',
'				}',
'			}',
'',
'			function cancelKeyEvent(evt) {',
'				evt.returnValue = false;',
'				stopPropagation(evt);',
'			}',
'',
'			function evalCommandLine() {',
'				var expr = $("command").value;',
'				evalCommand(expr);',
'				$("command").value = "";',
'			}',
'',
'			function evalLastCommand() {',
'				if (lastCommand != null) {',
'					evalCommand(lastCommand);',
'				}',
'			}',
'',
'			var lastCommand = null;',
'			var commandHistory = [];',
'			var currentCommandIndex = 0;',
'',
'			function evalCommand(expr) {',
'				if (appender) {',
'					appender.evalCommandAndAppend(expr);',
'				} else {',
'					var prefix = ">>> " + expr + "\\r\\n";',
'					try {',
'						log("INFO", prefix + eval(expr));',
'					} catch (ex) {',
'						log("ERROR", prefix + "Error: " + getErrorMessage(ex));',
'					}',
'				}',
'				// Update command history',
'				if (expr != commandHistory[commandHistory.length - 1]) {',
'					commandHistory.push(expr);',
'					// Update the appender',
'					if (appender) {',
'						appender.storeCommandHistory(commandHistory);',
'					}',
'				}',
'				currentCommandIndex = (expr == commandHistory[currentCommandIndex]) ? currentCommandIndex + 1 : commandHistory.length;',
'				lastCommand = expr;',
'			}',
'			//]]>',
'		</script>',
'		<style type="text/css">',
'			body {',
'				background-color: white;',
'				color: black;',
'				padding: 0;',
'				margin: 0;',
'				font-family: tahoma, verdana, arial, helvetica, sans-serif;',
'				overflow: hidden;',
'			}',
'',
'			div#switchesContainer input {',
'				margin-bottom: 0;',
'			}',
'',
'			div.toolbar {',
'				border-top: solid #ffffff 1px;',
'				border-bottom: solid #aca899 1px;',
'				background-color: #f1efe7;',
'				padding: 3px 5px;',
'				font-size: 68.75%;',
'			}',
'',
'			div.toolbar, div#search input {',
'				font-family: tahoma, verdana, arial, helvetica, sans-serif;',
'			}',
'',
'			div.toolbar input.button {',
'				padding: 0 5px;',
'				font-size: 100%;',
'			}',
'',
'			div.toolbar input.hidden {',
'				display: none;',
'			}',
'',
'			div#switches input#clearButton {',
'				margin-left: 20px;',
'			}',
'',
'			div#levels label {',
'				font-weight: bold;',
'			}',
'',
'			div#levels label, div#options label {',
'				margin-right: 5px;',
'			}',
'',
'			div#levels label#wrapLabel {',
'				font-weight: normal;',
'			}',
'',
'			div#search label {',
'				margin-right: 10px;',
'			}',
'',
'			div#search label.searchboxlabel {',
'				margin-right: 0;',
'			}',
'',
'			div#search input {',
'				font-size: 100%;',
'			}',
'',
'			div#search input.validregex {',
'				color: green;',
'			}',
'',
'			div#search input.invalidregex {',
'				color: red;',
'			}',
'',
'			div#search input.nomatches {',
'				color: white;',
'				background-color: #ff6666;',
'			}',
'',
'			div#search input.nomatches {',
'				color: white;',
'				background-color: #ff6666;',
'			}',
'',
'			div#searchNav {',
'				display: none;',
'			}',
'',
'			div#commandLine {',
'				display: none;',
'			}',
'',
'			div#commandLine input#command {',
'				font-size: 100%;',
'				font-family: Courier New, Courier;',
'			}',
'',
'			div#commandLine input#evaluateButton {',
'			}',
'',
'			*.greyedout {',
'				color: gray !important;',
'				border-color: gray !important;',
'			}',
'',
'			*.greyedout *.alwaysenabled { color: black; }',
'',
'			*.unselectable {',
'				-khtml-user-select: none;',
'				-moz-user-select: none;',
'				user-select: none;',
'			}',
'',
'			div#log {',
'				font-family: Courier New, Courier;',
'				font-size: 75%;',
'				width: 100%;',
'				overflow: auto;',
'				clear: both;',
'				position: relative;',
'			}',
'',
'			div.group {',
'				border-color: #cccccc;',
'				border-style: solid;',
'				border-width: 1px 0 1px 1px;',
'				overflow: visible;',
'			}',
'',
'			div.oldIe div.group, div.oldIe div.group *, div.oldIe *.logentry {',
'				height: 1%;',
'			}',
'',
'			div.group div.groupheading span.expander {',
'				border: solid black 1px;',
'				font-family: Courier New, Courier;',
'				font-size: 0.833em;',
'				background-color: #eeeeee;',
'				position: relative;',
'				top: -1px;',
'				color: black;',
'				padding: 0 2px;',
'				cursor: pointer;',
'				cursor: hand;',
'				height: 1%;',
'			}',
'',
'			div.group div.groupcontent {',
'				margin-left: 10px;',
'				padding-bottom: 2px;',
'				overflow: visible;',
'			}',
'',
'			div.group div.expanded {',
'				display: block;',
'			}',
'',
'			div.group div.collapsed {',
'				display: none;',
'			}',
'',
'			*.logentry {',
'				overflow: visible;',
'				display: none;',
'				white-space: pre;',
'			}',
'',
'			span.pre {',
'				white-space: pre;',
'			}',
'			',
'			pre.unwrapped {',
'				display: inline !important;',
'			}',
'',
'			pre.unwrapped pre.pre, div.wrapped pre.pre {',
'				display: inline;',
'			}',
'',
'			div.wrapped pre.pre {',
'				white-space: normal;',
'			}',
'',
'			div.wrapped {',
'				display: none;',
'			}',
'',
'			body.searching *.logentry span.currentmatch {',
'				color: white !important;',
'				background-color: green !important;',
'			}',
'',
'			body.searching div.searchhighlight *.logentry span.searchterm {',
'				color: black;',
'				background-color: yellow;',
'			}',
'',
'			div.wrap *.logentry {',
'				white-space: normal !important;',
'				border-width: 0 0 1px 0;',
'				border-color: #dddddd;',
'				border-style: dotted;',
'			}',
'',
'			div.wrap #log_wrapped, #log_unwrapped {',
'				display: block;',
'			}',
'',
'			div.wrap #log_unwrapped, #log_wrapped {',
'				display: none;',
'			}',
'',
'			div.wrap *.logentry span.pre {',
'				overflow: visible;',
'				white-space: normal;',
'			}',
'',
'			div.wrap *.logentry pre.unwrapped {',
'				display: none;',
'			}',
'',
'			div.wrap *.logentry span.wrapped {',
'				display: inline;',
'			}',
'',
'			div.searchfilter *.searchnonmatch {',
'				display: none !important;',
'			}',
'',
'			div#log *.TRACE, label#label_TRACE {',
'				color: #666666;',
'			}',
'',
'			div#log *.DEBUG, label#label_DEBUG {',
'				color: green;',
'			}',
'',
'			div#log *.INFO, label#label_INFO {',
'				color: #000099;',
'			}',
'',
'			div#log *.WARN, label#label_WARN {',
'				color: #999900;',
'			}',
'',
'			div#log *.ERROR, label#label_ERROR {',
'				color: red;',
'			}',
'',
'			div#log *.FATAL, label#label_FATAL {',
'				color: #660066;',
'			}',
'',
'			div.TRACE#log *.TRACE,',
'			div.DEBUG#log *.DEBUG,',
'			div.INFO#log *.INFO,',
'			div.WARN#log *.WARN,',
'			div.ERROR#log *.ERROR,',
'			div.FATAL#log *.FATAL {',
'				display: block;',
'			}',
'',
'			div#log div.separator {',
'				background-color: #cccccc;',
'				margin: 5px 0;',
'				line-height: 1px;',
'			}',
'		</style>',
'	</head>',
'',
'	<body id="body">',
'		<div id="switchesContainer">',
'			<div id="switches">',
'				<div id="levels" class="toolbar">',
'					Filters:',
'					<input type="checkbox" id="switch_TRACE" onclick="applyFilters(); checkAllLevels()" checked="checked" title="Show/hide trace messages" /><label for="switch_TRACE" id="label_TRACE">trace</label>',
'					<input type="checkbox" id="switch_DEBUG" onclick="applyFilters(); checkAllLevels()" checked="checked" title="Show/hide debug messages" /><label for="switch_DEBUG" id="label_DEBUG">debug</label>',
'					<input type="checkbox" id="switch_INFO" onclick="applyFilters(); checkAllLevels()" checked="checked" title="Show/hide info messages" /><label for="switch_INFO" id="label_INFO">info</label>',
'					<input type="checkbox" id="switch_WARN" onclick="applyFilters(); checkAllLevels()" checked="checked" title="Show/hide warn messages" /><label for="switch_WARN" id="label_WARN">warn</label>',
'					<input type="checkbox" id="switch_ERROR" onclick="applyFilters(); checkAllLevels()" checked="checked" title="Show/hide error messages" /><label for="switch_ERROR" id="label_ERROR">error</label>',
'					<input type="checkbox" id="switch_FATAL" onclick="applyFilters(); checkAllLevels()" checked="checked" title="Show/hide fatal messages" /><label for="switch_FATAL" id="label_FATAL">fatal</label>',
'					<input type="checkbox" id="switch_ALL" onclick="toggleAllLevels(); applyFilters()" checked="checked" title="Show/hide all messages" /><label for="switch_ALL" id="label_ALL">all</label>',
'				</div>',
'				<div id="search" class="toolbar">',
'					<label for="searchBox" class="searchboxlabel">Search:</label> <input type="text" id="searchBox" onclick="toggleSearchEnabled(true)" onkeyup="scheduleSearch()" size="20" />',
'					<input type="button" id="searchReset" disabled="disabled" value="Reset" onclick="clearSearch()" class="button" title="Reset the search" />',
'					<input type="checkbox" id="searchRegex" onclick="doSearch()" title="If checked, search is treated as a regular expression" /><label for="searchRegex">Regex</label>',
'					<input type="checkbox" id="searchCaseSensitive" onclick="doSearch()" title="If checked, search is case sensitive" /><label for="searchCaseSensitive">Match case</label>',
'					<input type="checkbox" id="searchDisable" onclick="toggleSearchEnabled()" title="Enable/disable search" /><label for="searchDisable" class="alwaysenabled">Disable</label>',
'					<div id="searchNav">',
'						<input type="button" id="searchNext" disabled="disabled" value="Next" onclick="searchNext()" class="button" title="Go to the next matching log entry" />',
'						<input type="button" id="searchPrevious" disabled="disabled" value="Previous" onclick="searchPrevious()" class="button" title="Go to the previous matching log entry" />',
'						<input type="checkbox" id="searchFilter" onclick="toggleSearchFilter()" title="If checked, non-matching log entries are filtered out" /><label for="searchFilter">Filter</label>',
'						<input type="checkbox" id="searchHighlight" onclick="toggleSearchHighlight()" title="Highlight matched search terms" /><label for="searchHighlight" class="alwaysenabled">Highlight all</label>',
'					</div>',
'				</div>',
'				<div id="options" class="toolbar">',
'					Options:',
'					<input type="checkbox" id="enableLogging" onclick="toggleLoggingEnabled()" checked="checked" title="Enable/disable logging" /><label for="enableLogging" id="enableLoggingLabel">Log</label>',
'					<input type="checkbox" id="wrap" onclick="toggleWrap()" title="Enable / disable word wrap" /><label for="wrap" id="wrapLabel">Wrap</label>',
'					<input type="checkbox" id="newestAtTop" onclick="toggleNewestAtTop()" title="If checked, causes newest messages to appear at the top" /><label for="newestAtTop" id="newestAtTopLabel">Newest at the top</label>',
'					<input type="checkbox" id="scrollToLatest" onclick="toggleScrollToLatest()" checked="checked" title="If checked, window automatically scrolls to a new message when it is added" /><label for="scrollToLatest" id="scrollToLatestLabel">Scroll to latest</label>',
'					<input type="button" id="clearButton" value="Clear" onclick="clearLog()" class="button" title="Clear all log messages"  />',
'					<input type="button" id="hideButton" value="Hide" onclick="hide()" class="hidden button" title="Hide the console" />',
'					<input type="button" id="closeButton" value="Close" onclick="closeWindow()" class="hidden button" title="Close the window" />',
'				</div>',
'			</div>',
'		</div>',
'		<div id="log" class="TRACE DEBUG INFO WARN ERROR FATAL"></div>',
'		<div id="commandLine" class="toolbar">',
'			<div id="commandLineContainer">',
'				<input type="text" id="command" title="Enter a JavaScript command here and hit return or press \'Evaluate\'" />',
'				<input type="button" id="evaluateButton" value="Evaluate" class="button" title="Evaluate the command" onclick="evalCommandLine()" />',
'			</div>',
'		</div>',
'	</body>',
'</html>',
''
];
		};

		var defaultCommandLineFunctions = [];

		ConsoleAppender = function() {};

		var consoleAppenderIdCounter = 1;
		ConsoleAppender.prototype = new Appender();

		ConsoleAppender.prototype.create = function(inPage, container,
				lazyInit, initiallyMinimized, useDocumentWrite, width, height, focusConsoleWindow) {
			var appender = this;

			// Common properties
			var initialized = false;
			var consoleWindowCreated = false;
			var consoleWindowLoaded = false;
			var consoleClosed = false;

			var queuedLoggingEvents = [];
			var isSupported = true;
			var consoleAppenderId = consoleAppenderIdCounter++;

			// Local variables
			initiallyMinimized = extractBooleanFromParam(initiallyMinimized, this.defaults.initiallyMinimized);
			lazyInit = extractBooleanFromParam(lazyInit, this.defaults.lazyInit);
			useDocumentWrite = extractBooleanFromParam(useDocumentWrite, this.defaults.useDocumentWrite);
			var newestMessageAtTop = this.defaults.newestMessageAtTop;
			var scrollToLatestMessage = this.defaults.scrollToLatestMessage;
			width = width ? width : this.defaults.width;
			height = height ? height : this.defaults.height;
			var maxMessages = this.defaults.maxMessages;
			var showCommandLine = this.defaults.showCommandLine;
			var commandLineObjectExpansionDepth = this.defaults.commandLineObjectExpansionDepth;
			var showHideButton = this.defaults.showHideButton;
            var showCloseButton = this.defaults.showCloseButton;
            var showLogEntryDeleteButtons = this.defaults.showLogEntryDeleteButtons;

			this.setLayout(this.defaults.layout);

			// Functions whose implementations vary between subclasses
			var init, createWindow, safeToAppend, getConsoleWindow, open;

			// Configuration methods. The function scope is used to prevent
			// direct alteration to the appender configuration properties.
			var appenderName = inPage ? "InPageAppender" : "PopUpAppender";
			var checkCanConfigure = function(configOptionName) {
				if (consoleWindowCreated) {
					handleError(appenderName + ": configuration option '" + configOptionName + "' may not be set after the appender has been initialized");
					return false;
				}
				return true;
			};

			var consoleWindowExists = function() {
				return (consoleWindowLoaded && isSupported && !consoleClosed);
			};

			this.isNewestMessageAtTop = function() { return newestMessageAtTop; };
			this.setNewestMessageAtTop = function(newestMessageAtTopParam) {
				newestMessageAtTop = bool(newestMessageAtTopParam);
				if (consoleWindowExists()) {
					getConsoleWindow().setNewestAtTop(newestMessageAtTop);
				}
			};

			this.isScrollToLatestMessage = function() { return scrollToLatestMessage; };
			this.setScrollToLatestMessage = function(scrollToLatestMessageParam) {
				scrollToLatestMessage = bool(scrollToLatestMessageParam);
				if (consoleWindowExists()) {
					getConsoleWindow().setScrollToLatest(scrollToLatestMessage);
				}
			};

			this.getWidth = function() { return width; };
			this.setWidth = function(widthParam) {
				if (checkCanConfigure("width")) {
					width = extractStringFromParam(widthParam, width);
				}
			};

			this.getHeight = function() { return height; };
			this.setHeight = function(heightParam) {
				if (checkCanConfigure("height")) {
					height = extractStringFromParam(heightParam, height);
				}
			};

			this.getMaxMessages = function() { return maxMessages; };
			this.setMaxMessages = function(maxMessagesParam) {
				maxMessages = extractIntFromParam(maxMessagesParam, maxMessages);
				if (consoleWindowExists()) {
					getConsoleWindow().setMaxMessages(maxMessages);
				}
			};

			this.isShowCommandLine = function() { return showCommandLine; };
			this.setShowCommandLine = function(showCommandLineParam) {
				showCommandLine = bool(showCommandLineParam);
				if (consoleWindowExists()) {
					getConsoleWindow().setShowCommandLine(showCommandLine);
				}
			};

			this.isShowHideButton = function() { return showHideButton; };
			this.setShowHideButton = function(showHideButtonParam) {
				showHideButton = bool(showHideButtonParam);
				if (consoleWindowExists()) {
					getConsoleWindow().setShowHideButton(showHideButton);
				}
			};

			this.isShowCloseButton = function() { return showCloseButton; };
			this.setShowCloseButton = function(showCloseButtonParam) {
				showCloseButton = bool(showCloseButtonParam);
				if (consoleWindowExists()) {
					getConsoleWindow().setShowCloseButton(showCloseButton);
				}
			};

			this.getCommandLineObjectExpansionDepth = function() { return commandLineObjectExpansionDepth; };
			this.setCommandLineObjectExpansionDepth = function(commandLineObjectExpansionDepthParam) {
				commandLineObjectExpansionDepth = extractIntFromParam(commandLineObjectExpansionDepthParam, commandLineObjectExpansionDepth);
			};

			var minimized = initiallyMinimized;
			this.isInitiallyMinimized = function() { return initiallyMinimized; };
			this.setInitiallyMinimized = function(initiallyMinimizedParam) {
				if (checkCanConfigure("initiallyMinimized")) {
					initiallyMinimized = bool(initiallyMinimizedParam);
					minimized = initiallyMinimized;
				}
			};

			this.isUseDocumentWrite = function() { return useDocumentWrite; };
			this.setUseDocumentWrite = function(useDocumentWriteParam) {
				if (checkCanConfigure("useDocumentWrite")) {
					useDocumentWrite = bool(useDocumentWriteParam);
				}
			};

			// Common methods
			function QueuedLoggingEvent(loggingEvent, formattedMessage) {
				this.loggingEvent = loggingEvent;
				this.levelName = loggingEvent.level.name;
				this.formattedMessage = formattedMessage;
			}

			QueuedLoggingEvent.prototype.append = function() {
				getConsoleWindow().log(this.levelName, this.formattedMessage);
			};

			function QueuedGroup(name, initiallyExpanded) {
				this.name = name;
				this.initiallyExpanded = initiallyExpanded;
			}

			QueuedGroup.prototype.append = function() {
				getConsoleWindow().group(this.name, this.initiallyExpanded);
			};

			function QueuedGroupEnd() {}

			QueuedGroupEnd.prototype.append = function() {
				getConsoleWindow().groupEnd();
			};

			var checkAndAppend = function() {
				// Next line forces a check of whether the window has been closed
				safeToAppend();
				if (!initialized) {
					init();
				} else if (consoleClosed && reopenWhenClosed) {
					createWindow();
				}
				if (safeToAppend()) {
					appendQueuedLoggingEvents();
				}
			};

			this.append = function(loggingEvent) {
				if (isSupported) {
					// Format the message
					var formattedMessage = appender.getLayout().format(loggingEvent);
					if (this.getLayout().ignoresThrowable()) {
						formattedMessage += loggingEvent.getThrowableStrRep();
					}
					queuedLoggingEvents.push(new QueuedLoggingEvent(loggingEvent, formattedMessage));
					checkAndAppend();
				}
			};

            this.group = function(name, initiallyExpanded) {
				if (isSupported) {
					queuedLoggingEvents.push(new QueuedGroup(name, initiallyExpanded));
					checkAndAppend();
				}
			};

            this.groupEnd = function() {
				if (isSupported) {
					queuedLoggingEvents.push(new QueuedGroupEnd());
					checkAndAppend();
				}
			};

			var appendQueuedLoggingEvents = function() {
				var currentLoggingEvent;
				while (queuedLoggingEvents.length > 0) {
					queuedLoggingEvents.shift().append();
				}
				if (focusConsoleWindow) {
					getConsoleWindow().focus();
				}
			};

			this.setAddedToLogger = function(logger) {
				this.loggers.push(logger);
				if (enabled && !lazyInit) {
					init();
				}
			};

			this.clear = function() {
				if (consoleWindowExists()) {
					getConsoleWindow().clearLog();
				}
				queuedLoggingEvents.length = 0;
			};

			this.focus = function() {
				if (consoleWindowExists()) {
					getConsoleWindow().focus();
				}
			};

			this.focusCommandLine = function() {
				if (consoleWindowExists()) {
					getConsoleWindow().focusCommandLine();
				}
			};

			this.focusSearch = function() {
				if (consoleWindowExists()) {
					getConsoleWindow().focusSearch();
				}
			};

			var commandWindow = window;

			this.getCommandWindow = function() { return commandWindow; };
			this.setCommandWindow = function(commandWindowParam) {
				commandWindow = commandWindowParam;
			};

			this.executeLastCommand = function() {
				if (consoleWindowExists()) {
					getConsoleWindow().evalLastCommand();
				}
			};

			var commandLayout = new PatternLayout("%m");
			this.getCommandLayout = function() { return commandLayout; };
			this.setCommandLayout = function(commandLayoutParam) {
				commandLayout = commandLayoutParam;
			};

			this.evalCommandAndAppend = function(expr) {
				var commandReturnValue = { appendResult: true, isError: false };
				var commandOutput = "";
				// Evaluate the command
				try {
					var result, i;
					// The next three lines constitute a workaround for IE. Bizarrely, iframes seem to have no
					// eval method on the window object initially, but once execScript has been called on
					// it once then the eval method magically appears. See http://www.thismuchiknow.co.uk/?p=25
					if (!commandWindow.eval && commandWindow.execScript) {
						commandWindow.execScript("null");
					}

					var commandLineFunctionsHash = {};
					for (i = 0, len = commandLineFunctions.length; i < len; i++) {
						commandLineFunctionsHash[commandLineFunctions[i][0]] = commandLineFunctions[i][1];
					}

					// Keep an array of variables that are being changed in the command window so that they
					// can be restored to their original values afterwards
					var objectsToRestore = [];
					var addObjectToRestore = function(name) {
						objectsToRestore.push([name, commandWindow[name]]);
					};

					addObjectToRestore("appender");
					commandWindow.appender = appender;

					addObjectToRestore("commandReturnValue");
					commandWindow.commandReturnValue = commandReturnValue;

					addObjectToRestore("commandLineFunctionsHash");
					commandWindow.commandLineFunctionsHash = commandLineFunctionsHash;

					var addFunctionToWindow = function(name) {
						addObjectToRestore(name);
						commandWindow[name] = function() {
							return this.commandLineFunctionsHash[name](appender, arguments, commandReturnValue);
						};
					};

					for (i = 0, len = commandLineFunctions.length; i < len; i++) {
						addFunctionToWindow(commandLineFunctions[i][0]);
					}

					// Another bizarre workaround to get IE to eval in the global scope
					if (commandWindow === window && commandWindow.execScript) {
						addObjectToRestore("evalExpr");
						addObjectToRestore("result");
						window.evalExpr = expr;
						commandWindow.execScript("window.result=eval(window.evalExpr);");
						result = window.result;
 					} else {
 						result = commandWindow.eval(expr);
 					}
					commandOutput = isUndefined(result) ? result : formatObjectExpansion(result, commandLineObjectExpansionDepth);

					// Restore variables in the command window to their original state
					for (i = 0, len = objectsToRestore.length; i < len; i++) {
						commandWindow[objectsToRestore[i][0]] = objectsToRestore[i][1];
					}
				} catch (ex) {
					commandOutput = "Error evaluating command: " + getExceptionStringRep(ex);
					commandReturnValue.isError = true;
				}
				// Append command output
				if (commandReturnValue.appendResult) {
					var message = ">>> " + expr;
					if (!isUndefined(commandOutput)) {
						message += newLine + commandOutput;
					}
					var level = commandReturnValue.isError ? Level.ERROR : Level.INFO;
					var loggingEvent = new LoggingEvent(null, new Date(), level, [message], null);
					var mainLayout = this.getLayout();
					this.setLayout(commandLayout);
					this.append(loggingEvent);
					this.setLayout(mainLayout);
				}
			};

			var commandLineFunctions = defaultCommandLineFunctions.concat([]);

			this.addCommandLineFunction = function(functionName, commandLineFunction) {
				commandLineFunctions.push([functionName, commandLineFunction]);
			};

			var commandHistoryCookieName = "log4javascriptCommandHistory";
			this.storeCommandHistory = function(commandHistory) {
				setCookie(commandHistoryCookieName, commandHistory.join(","));
			};

			var writeHtml = function(doc) {
				var lines = getConsoleHtmlLines();
				doc.open();
				for (var i = 0, len = lines.length; i < len; i++) {
					doc.writeln(lines[i]);
				}
				doc.close();
			};

			// Set up event listeners
			this.setEventTypes(["load", "unload"]);

			var consoleWindowLoadHandler = function() {
				var win = getConsoleWindow();
				win.setAppender(appender);
				win.setNewestAtTop(newestMessageAtTop);
				win.setScrollToLatest(scrollToLatestMessage);
				win.setMaxMessages(maxMessages);
				win.setShowCommandLine(showCommandLine);
				win.setShowHideButton(showHideButton);
				win.setShowCloseButton(showCloseButton);
				win.setMainWindow(window);

				// Restore command history stored in cookie
				var storedValue = getCookie(commandHistoryCookieName);
				if (storedValue) {
					win.commandHistory = storedValue.split(",");
					win.currentCommandIndex = win.commandHistory.length;
				}

				appender.dispatchEvent("load", { "win" : win });
			};

			this.unload = function() {
				logLog.debug("unload " + this + ", caller: " + this.unload.caller);
				if (!consoleClosed) {
					logLog.debug("really doing unload " + this);
					consoleClosed = true;
					consoleWindowLoaded = false;
					consoleWindowCreated = false;
					appender.dispatchEvent("unload", {});
				}
			};

			var pollConsoleWindow = function(windowTest, interval, successCallback, errorMessage) {
				function doPoll() {
					try {
						// Test if the console has been closed while polling
						if (consoleClosed) {
							clearInterval(poll);
						}
						if (windowTest(getConsoleWindow())) {
							clearInterval(poll);
							successCallback();
						}
					} catch (ex) {
						clearInterval(poll);
						isSupported = false;
						handleError(errorMessage, ex);
					}
				}

				// Poll the pop-up since the onload event is not reliable
				var poll = setInterval(doPoll, interval);
			};

			var getConsoleUrl = function() {
				var documentDomainSet = (document.domain != location.hostname);
				return useDocumentWrite ? "" : getBaseUrl() + "console_uncompressed.html" +
											   (documentDomainSet ? "?log4javascript_domain=" + escape(document.domain) : "");
			};

			// Define methods and properties that vary between subclasses
			if (inPage) {
				// InPageAppender

				var containerElement = null;

				// Configuration methods. The function scope is used to prevent
				// direct alteration to the appender configuration properties.
				var cssProperties = [];
				this.addCssProperty = function(name, value) {
					if (checkCanConfigure("cssProperties")) {
						cssProperties.push([name, value]);
					}
				};

				// Define useful variables
				var windowCreationStarted = false;
				var iframeContainerDiv;
				var iframeId = uniqueId + "_InPageAppender_" + consoleAppenderId;

				this.hide = function() {
					if (initialized && consoleWindowCreated) {
						if (consoleWindowExists()) {
							getConsoleWindow().$("command").blur();
						}
						iframeContainerDiv.style.display = "none";
						minimized = true;
					}
				};

				this.show = function() {
					if (initialized) {
						if (consoleWindowCreated) {
							iframeContainerDiv.style.display = "block";
							this.setShowCommandLine(showCommandLine); // Force IE to update
							minimized = false;
						} else if (!windowCreationStarted) {
							createWindow(true);
						}
					}
				};

				this.isVisible = function() {
					return !minimized && !consoleClosed;
				};

				this.close = function(fromButton) {
					if (!consoleClosed && (!fromButton || confirm("This will permanently remove the console from the page. No more messages will be logged. Do you wish to continue?"))) {
						iframeContainerDiv.parentNode.removeChild(iframeContainerDiv);
						this.unload();
					}
				};

				// Create open, init, getConsoleWindow and safeToAppend functions
				open = function() {
					var initErrorMessage = "InPageAppender.open: unable to create console iframe";

					function finalInit() {
						try {
							if (!initiallyMinimized) {
								appender.show();
							}
							consoleWindowLoadHandler();
							consoleWindowLoaded = true;
							appendQueuedLoggingEvents();
						} catch (ex) {
							isSupported = false;
							handleError(initErrorMessage, ex);
						}
					}

					function writeToDocument() {
						try {
							var windowTest = function(win) { return isLoaded(win); };
							if (useDocumentWrite) {
								writeHtml(getConsoleWindow().document);
							}
							if (windowTest(getConsoleWindow())) {
								finalInit();
							} else {
								pollConsoleWindow(windowTest, 100, finalInit, initErrorMessage);
							}
						} catch (ex) {
							isSupported = false;
							handleError(initErrorMessage, ex);
						}
					}

					minimized = false;
					iframeContainerDiv = containerElement.appendChild(document.createElement("div"));

					iframeContainerDiv.style.width = width;
					iframeContainerDiv.style.height = height;
					iframeContainerDiv.style.border = "solid gray 1px";

					for (var i = 0, len = cssProperties.length; i < len; i++) {
						iframeContainerDiv.style[cssProperties[i][0]] = cssProperties[i][1];
					}

					var iframeSrc = useDocumentWrite ? "" : " src='" + getConsoleUrl() + "'";

					// Adding an iframe using the DOM would be preferable, but it doesn't work
					// in IE5 on Windows, or in Konqueror prior to version 3.5 - in Konqueror
					// it creates the iframe fine but I haven't been able to find a way to obtain
					// the iframe's window object
					iframeContainerDiv.innerHTML = "<iframe id='" + iframeId + "' name='" + iframeId +
						"' width='100%' height='100%' frameborder='0'" + iframeSrc +
						" scrolling='no'></iframe>";
					consoleClosed = false;

					// Write the console HTML to the iframe
					var iframeDocumentExistsTest = function(win) {
						try {
							return bool(win) && bool(win.document);
						} catch (ex) {
							return false;
						}
					};
					if (iframeDocumentExistsTest(getConsoleWindow())) {
						writeToDocument();
					} else {
						pollConsoleWindow(iframeDocumentExistsTest, 100, writeToDocument, initErrorMessage);
					}
					consoleWindowCreated = true;
				};

				createWindow = function(show) {
					if (show || !initiallyMinimized) {
						var pageLoadHandler = function() {
							if (!container) {
								// Set up default container element
								containerElement = document.createElement("div");
								containerElement.style.position = "fixed";
								containerElement.style.left = "0";
								containerElement.style.right = "0";
								containerElement.style.bottom = "0";
								document.body.appendChild(containerElement);
								appender.addCssProperty("borderWidth", "1px 0 0 0");
								appender.addCssProperty("zIndex", 1000000); // Can't find anything authoritative that says how big z-index can be
								open();
							} else {
								try {
									var el = document.getElementById(container);
									if (el.nodeType == 1) {
										containerElement = el;
									}
									open();
								} catch (ex) {
									handleError("InPageAppender.init: invalid container element '" + container + "' supplied", ex);
								}
							}
						};

						// Test the type of the container supplied. First, check if it's an element
						if (pageLoaded && container && container.appendChild) {
							containerElement = container;
							open();
						} else if (pageLoaded) {
							pageLoadHandler();
						} else {
							log4javascript.addEventListener("load", pageLoadHandler);
						}
						windowCreationStarted = true;
					}
				};

				init = function() {
					createWindow();
					initialized = true;
				};

				getConsoleWindow = function() {
					var iframe = window.frames[iframeId];
					if (iframe) {
						return iframe;
					}
				};

				safeToAppend = function() {
					if (isSupported && !consoleClosed) {
						if (consoleWindowCreated && !consoleWindowLoaded && getConsoleWindow() && isLoaded(getConsoleWindow())) {
							consoleWindowLoaded = true;
						}
						return consoleWindowLoaded;
					}
					return false;
				};
			} else {
				// PopUpAppender

				// Extract params
				var useOldPopUp = appender.defaults.useOldPopUp;
				var complainAboutPopUpBlocking = appender.defaults.complainAboutPopUpBlocking;
				var reopenWhenClosed = this.defaults.reopenWhenClosed;

				// Configuration methods. The function scope is used to prevent
				// direct alteration to the appender configuration properties.
				this.isUseOldPopUp = function() { return useOldPopUp; };
				this.setUseOldPopUp = function(useOldPopUpParam) {
					if (checkCanConfigure("useOldPopUp")) {
						useOldPopUp = bool(useOldPopUpParam);
					}
				};

				this.isComplainAboutPopUpBlocking = function() { return complainAboutPopUpBlocking; };
				this.setComplainAboutPopUpBlocking = function(complainAboutPopUpBlockingParam) {
					if (checkCanConfigure("complainAboutPopUpBlocking")) {
						complainAboutPopUpBlocking = bool(complainAboutPopUpBlockingParam);
					}
				};

				this.isFocusPopUp = function() { return focusConsoleWindow; };
				this.setFocusPopUp = function(focusPopUpParam) {
					// This property can be safely altered after logging has started
					focusConsoleWindow = bool(focusPopUpParam);
				};

				this.isReopenWhenClosed = function() { return reopenWhenClosed; };
				this.setReopenWhenClosed = function(reopenWhenClosedParam) {
					// This property can be safely altered after logging has started
					reopenWhenClosed = bool(reopenWhenClosedParam);
				};

				this.close = function() {
					logLog.debug("close " + this);
					try {
						popUp.close();
						this.unload();
					} catch (ex) {
						// Do nothing
					}
				};

				this.hide = function() {
					logLog.debug("hide " + this);
					if (consoleWindowExists()) {
						this.close();
					}
				};

				this.show = function() {
					logLog.debug("show " + this);
					if (!consoleWindowCreated) {
						open();
					}
				};

				this.isVisible = function() {
					return safeToAppend();
				};

				// Define useful variables
				var popUp;

				// Create open, init, getConsoleWindow and safeToAppend functions
				open = function() {
					var windowProperties = "width=" + width + ",height=" + height + ",status,resizable";
					var windowName = "PopUp_" + location.host.replace(/[^a-z0-9]/gi, "_") + "_" + consoleAppenderId;
					if (!useOldPopUp || !useDocumentWrite) {
						// Ensure a previous window isn't used by using a unique name
						windowName = windowName + "_" + uniqueId;
					}

					var checkPopUpClosed = function(win) {
						if (consoleClosed) {
							return true;
						} else {
							try {
								return bool(win) && win.closed;
							} catch(ex) {}
						}
						return false;
					};

					var popUpClosedCallback = function() {
						if (!consoleClosed) {
							appender.unload();
						}
					};

					function finalInit() {
						getConsoleWindow().setCloseIfOpenerCloses(!useOldPopUp || !useDocumentWrite);
						consoleWindowLoadHandler();
						consoleWindowLoaded = true;
						appendQueuedLoggingEvents();
						pollConsoleWindow(checkPopUpClosed, 500, popUpClosedCallback,
								"PopUpAppender.checkPopUpClosed: error checking pop-up window");
					}

					try {
						popUp = window.open(getConsoleUrl(), windowName, windowProperties);
						consoleClosed = false;
						consoleWindowCreated = true;
						if (popUp && popUp.document) {
							if (useDocumentWrite && useOldPopUp && isLoaded(popUp)) {
								popUp.mainPageReloaded();
								finalInit();
							} else {
								if (useDocumentWrite) {
									writeHtml(popUp.document);
								}
								// Check if the pop-up window object is available
								var popUpLoadedTest = function(win) { return bool(win) && isLoaded(win); };
								if (isLoaded(popUp)) {
									finalInit();
								} else {
									pollConsoleWindow(popUpLoadedTest, 100, finalInit,
											"PopUpAppender.init: unable to create console window");
								}
							}
						} else {
							isSupported = false;
							logLog.warn("PopUpAppender.init: pop-ups blocked, please unblock to use PopUpAppender");
							if (complainAboutPopUpBlocking) {
								handleError("log4javascript: pop-up windows appear to be blocked. Please unblock them to use pop-up logging.");
							}
						}
					} catch (ex) {
						handleError("PopUpAppender.init: error creating pop-up", ex);
					}
				};

				createWindow = function() {
					if (!initiallyMinimized) {
						open();
					}
				};

				init = function() {
					createWindow();
					initialized = true;
				};

				getConsoleWindow = function() {
					return popUp;
				};

				safeToAppend = function() {
					if (isSupported && !isUndefined(popUp) && !consoleClosed) {
						if (popUp.closed ||
								(consoleWindowLoaded && isUndefined(popUp.closed))) { // Extra check for Opera
							appender.unload();
							logLog.debug("PopUpAppender: pop-up closed");
							return false;
						}
						if (!consoleWindowLoaded && isLoaded(popUp)) {
							consoleWindowLoaded = true;
						}
					}
					return isSupported && consoleWindowLoaded && !consoleClosed;
				};
			}

			// Expose getConsoleWindow so that automated tests can check the DOM
			this.getConsoleWindow = getConsoleWindow;
		};

		ConsoleAppender.addGlobalCommandLineFunction = function(functionName, commandLineFunction) {
			defaultCommandLineFunctions.push([functionName, commandLineFunction]);
		};

		/* ------------------------------------------------------------------ */

		function PopUpAppender(lazyInit, initiallyMinimized, useDocumentWrite,
							   width, height) {
			this.create(false, null, lazyInit, initiallyMinimized,
					useDocumentWrite, width, height, this.defaults.focusPopUp);
		}

		PopUpAppender.prototype = new ConsoleAppender();

		PopUpAppender.prototype.defaults = {
			layout: new PatternLayout("%d{HH:mm:ss} %-5p - %m{1}%n"),
			initiallyMinimized: false,
			focusPopUp: false,
			lazyInit: true,
			useOldPopUp: true,
			complainAboutPopUpBlocking: true,
			newestMessageAtTop: false,
			scrollToLatestMessage: true,
			width: "600",
			height: "400",
			reopenWhenClosed: false,
			maxMessages: null,
			showCommandLine: true,
			commandLineObjectExpansionDepth: 1,
			showHideButton: false,
			showCloseButton: true,
            showLogEntryDeleteButtons: true,
            useDocumentWrite: true
		};

		PopUpAppender.prototype.toString = function() {
			return "PopUpAppender";
		};

		log4javascript.PopUpAppender = PopUpAppender;

		/* ------------------------------------------------------------------ */

		function InPageAppender(container, lazyInit, initiallyMinimized,
								useDocumentWrite, width, height) {
			this.create(true, container, lazyInit, initiallyMinimized,
					useDocumentWrite, width, height, false);
		}

		InPageAppender.prototype = new ConsoleAppender();

		InPageAppender.prototype.defaults = {
			layout: new PatternLayout("%d{HH:mm:ss} %-5p - %m{1}%n"),
			initiallyMinimized: false,
			lazyInit: true,
			newestMessageAtTop: false,
			scrollToLatestMessage: true,
			width: "100%",
			height: "220px",
			maxMessages: null,
			showCommandLine: true,
			commandLineObjectExpansionDepth: 1,
			showHideButton: false,
			showCloseButton: false,
            showLogEntryDeleteButtons: true,
            useDocumentWrite: true
		};

		InPageAppender.prototype.toString = function() {
			return "InPageAppender";
		};

		log4javascript.InPageAppender = InPageAppender;

		// Next line for backwards compatibility
		log4javascript.InlineAppender = InPageAppender;
	})();
	/* ---------------------------------------------------------------------- */
	// Console extension functions

	function padWithSpaces(str, len) {
		if (str.length < len) {
			var spaces = [];
			var numberOfSpaces = Math.max(0, len - str.length);
			for (var i = 0; i < numberOfSpaces; i++) {
				spaces[i] = " ";
			}
			str += spaces.join("");
		}
		return str;
	}

	(function() {
		function dir(obj) {
			var maxLen = 0;
			// Obtain the length of the longest property name
			for (var p in obj) {
				maxLen = Math.max(toStr(p).length, maxLen);
			}
			// Create the nicely formatted property list
			var propList = [];
			for (p in obj) {
				var propNameStr = "  " + padWithSpaces(toStr(p), maxLen + 2);
				var propVal;
				try {
					propVal = splitIntoLines(toStr(obj[p])).join(padWithSpaces(newLine, maxLen + 6));
				} catch (ex) {
					propVal = "[Error obtaining property. Details: " + getExceptionMessage(ex) + "]";
				}
				propList.push(propNameStr + propVal);
			}
			return propList.join(newLine);
		}

		var nodeTypes = {
			ELEMENT_NODE: 1,
			ATTRIBUTE_NODE: 2,
			TEXT_NODE: 3,
			CDATA_SECTION_NODE: 4,
			ENTITY_REFERENCE_NODE: 5,
			ENTITY_NODE: 6,
			PROCESSING_INSTRUCTION_NODE: 7,
			COMMENT_NODE: 8,
			DOCUMENT_NODE: 9,
			DOCUMENT_TYPE_NODE: 10,
			DOCUMENT_FRAGMENT_NODE: 11,
			NOTATION_NODE: 12
		};

		var preFormattedElements = ["script", "pre"];

		// This should be the definitive list, as specified by the XHTML 1.0 Transitional DTD
		var emptyElements = ["br", "img", "hr", "param", "link", "area", "input", "col", "base", "meta"];
		var indentationUnit = "  ";

		// Create and return an XHTML string from the node specified
		function getXhtml(rootNode, includeRootNode, indentation, startNewLine, preformatted) {
			includeRootNode = (typeof includeRootNode == "undefined") ? true : !!includeRootNode;
			if (typeof indentation != "string") {
				indentation = "";
			}
			startNewLine = !!startNewLine;
			preformatted = !!preformatted;
			var xhtml;

			function isWhitespace(node) {
				return ((node.nodeType == nodeTypes.TEXT_NODE) && /^[ \t\r\n]*$/.test(node.nodeValue));
			}

			function fixAttributeValue(attrValue) {
				return attrValue.toString().replace(/\&/g, "&amp;").replace(/</g, "&lt;").replace(/\"/g, "&quot;");
			}

			function getStyleAttributeValue(el) {
				var stylePairs = el.style.cssText.split(";");
				var styleValue = "";
				var isFirst = true;
				for (var j = 0, len = stylePairs.length; j < len; j++) {
					var nameValueBits = stylePairs[j].split(":");
					var props = [];
					if (!/^\s*$/.test(nameValueBits[0])) {
						props.push(trim(nameValueBits[0]).toLowerCase() + ":" + trim(nameValueBits[1]));
					}
					styleValue = props.join(";");
				}
				return styleValue;
			}

			function getNamespace(el) {
				if (el.prefix) {
					return el.prefix;
				} else if (el.outerHTML) {
					var regex = new RegExp("<([^:]+):" + el.tagName + "[^>]*>", "i");
					if (regex.test(el.outerHTML)) {
						return RegExp.$1.toLowerCase();
					}
				}
                return "";
			}

			var lt = "<";
			var gt = ">";

			if (includeRootNode && rootNode.nodeType != nodeTypes.DOCUMENT_FRAGMENT_NODE) {
				switch (rootNode.nodeType) {
					case nodeTypes.ELEMENT_NODE:
						var tagName = rootNode.tagName.toLowerCase();
						xhtml = startNewLine ? newLine + indentation : "";
						xhtml += lt;
						// Allow for namespaces, where present
						var prefix = getNamespace(rootNode);
						var hasPrefix = !!prefix;
						if (hasPrefix) {
							xhtml += prefix + ":";
						}
						xhtml += tagName;
						for (i = 0, len = rootNode.attributes.length; i < len; i++) {
							var currentAttr = rootNode.attributes[i];
							// Check the attribute is valid.
							if (!	currentAttr.specified ||
									currentAttr.nodeValue === null ||
									currentAttr.nodeName.toLowerCase() === "style" ||
									typeof currentAttr.nodeValue !== "string" ||
									currentAttr.nodeName.indexOf("_moz") === 0) {
								continue;
							}
							xhtml += " " + currentAttr.nodeName.toLowerCase() + "=\"";
							xhtml += fixAttributeValue(currentAttr.nodeValue);
							xhtml += "\"";
						}
						// Style needs to be done separately as it is not reported as an
						// attribute in IE
						if (rootNode.style.cssText) {
							var styleValue = getStyleAttributeValue(rootNode);
							if (styleValue !== "") {
								xhtml += " style=\"" + getStyleAttributeValue(rootNode) + "\"";
							}
						}
						if (array_contains(emptyElements, tagName) ||
								(hasPrefix && !rootNode.hasChildNodes())) {
							xhtml += "/" + gt;
						} else {
							xhtml += gt;
							// Add output for childNodes collection (which doesn't include attribute nodes)
							var childStartNewLine = !(rootNode.childNodes.length === 1 &&
								rootNode.childNodes[0].nodeType === nodeTypes.TEXT_NODE);
							var childPreformatted = array_contains(preFormattedElements, tagName);
							for (var i = 0, len = rootNode.childNodes.length; i < len; i++) {
								xhtml += getXhtml(rootNode.childNodes[i], true, indentation + indentationUnit,
									childStartNewLine, childPreformatted);
							}
							// Add the end tag
							var endTag = lt + "/" + tagName + gt;
							xhtml += childStartNewLine ? newLine + indentation + endTag : endTag;
						}
						return xhtml;
					case nodeTypes.TEXT_NODE:
						if (isWhitespace(rootNode)) {
							xhtml = "";
						} else {
							if (preformatted) {
								xhtml = rootNode.nodeValue;
							} else {
								// Trim whitespace from each line of the text node
								var lines = splitIntoLines(trim(rootNode.nodeValue));
								var trimmedLines = [];
								for (var i = 0, len = lines.length; i < len; i++) {
									trimmedLines[i] = trim(lines[i]);
								}
								xhtml = trimmedLines.join(newLine + indentation);
							}
							if (startNewLine) {
								xhtml = newLine + indentation + xhtml;
							}
						}
						return xhtml;
					case nodeTypes.CDATA_SECTION_NODE:
						return "<![CDA" + "TA[" + rootNode.nodeValue + "]" + "]>" + newLine;
					case nodeTypes.DOCUMENT_NODE:
						xhtml = "";
						// Add output for childNodes collection (which doesn't include attribute nodes)
						for (var i = 0, len = rootNode.childNodes.length; i < len; i++) {
							xhtml += getXhtml(rootNode.childNodes[i], true, indentation);
						}
						return xhtml;
					default:
						return "";
				}
			} else {
				xhtml = "";
				// Add output for childNodes collection (which doesn't include attribute nodes)
				for (var i = 0, len = rootNode.childNodes.length; i < len; i++) {
					xhtml += getXhtml(rootNode.childNodes[i], true, indentation + indentationUnit);
				}
				return xhtml;
			}
		}

		var layouts = {};

		function createCommandLineFunctions(appender) {
			ConsoleAppender.addGlobalCommandLineFunction("$", function(appender, args, returnValue) {
				return document.getElementById(args[0]);
			});

			ConsoleAppender.addGlobalCommandLineFunction("dir", function(appender, args, returnValue) {
				var lines = [];
				for (var i = 0, len = args.length; i < len; i++) {
					lines[i] = dir(args[i]);
				}
				return lines.join(newLine + newLine);
			});

			ConsoleAppender.addGlobalCommandLineFunction("dirxml", function(appender, args, returnValue) {
				var lines = [];
				for (var i = 0, len = args.length; i < len; i++) {
					var win = appender.getCommandWindow();
					lines[i] = getXhtml(args[i]);
				}
				return lines.join(newLine + newLine);
			});

			ConsoleAppender.addGlobalCommandLineFunction("cd", function(appender, args, returnValue) {
				var win, message;
				if (args.length === 0 || args[0] === "") {
					win = window;
					message = "Command line set to run in main window";
				} else {
					if (args[0].window == args[0]) {
						win = args[0];
						message = "Command line set to run in frame '" + args[0].name + "'";
					} else {
						win = window.frames[args[0]];
						if (win) {
							message = "Command line set to run in frame '" + args[0] + "'";
						} else {
							returnValue.isError = true;
							message = "Frame '" + args[0] + "' does not exist";
							win = appender.getCommandWindow();
						}
					}
				}
				appender.setCommandWindow(win);
				return message;
			});

			ConsoleAppender.addGlobalCommandLineFunction("clear", function(appender, args, returnValue) {
				returnValue.appendResult = false;
				appender.clear();
			});

			ConsoleAppender.addGlobalCommandLineFunction("keys", function(appender, args, returnValue) {
				var keys = [];
				for (var k in args[0]) {
					keys.push(k);
				}
				return keys;
			});

			ConsoleAppender.addGlobalCommandLineFunction("values", function(appender, args, returnValue) {
				var values = [];
				for (var k in args[0]) {
					try {
						values.push(args[0][k]);
					} catch (ex) {
						logLog.warn("values(): Unable to obtain value for key " + k + ". Details: " + getExceptionMessage(ex));
					}
				}
				return values;
			});

			ConsoleAppender.addGlobalCommandLineFunction("expansionDepth", function(appender, args, returnValue) {
				var expansionDepth = parseInt(args[0], 10);
				if (isNaN(expansionDepth) || expansionDepth < 0) {
					returnValue.isError = true;
					return "" + args[0] + " is not a valid expansion depth";
				} else {
					appender.setCommandLineObjectExpansionDepth(expansionDepth);
					return "Object expansion depth set to " + expansionDepth;
				}
			});
		}

		function init() {
			// Add command line functions
			createCommandLineFunctions();
			initialized = true;
		}

		/* ------------------------------------------------------------------ */

		init();
	})();

	/* ---------------------------------------------------------------------- */
	// Main load

   log4javascript.setDocumentReady = function() {
       pageLoaded = true;
       log4javascript.dispatchEvent("load", {});
   };

    if (window.addEventListener) {
        window.addEventListener("load", log4javascript.setDocumentReady, false);
    } else if (window.attachEvent) {
        window.attachEvent("onload", log4javascript.setDocumentReady);
    } else {
        var oldOnload = window.onload;
        if (typeof window.onload != "function") {
            window.onload = log4javascript.setDocumentReady;
        } else {
            window.onload = function(evt) {
                if (oldOnload) {
                    oldOnload(evt);
                }
                log4javascript.setDocumentReady();
            };
        }
    }

    // Ensure that the log4javascript object is available in the window. This
    // is necessary for log4javascript to be available in IE if loaded using
    // Dojo's module system
    window.log4javascript = log4javascript;

    return log4javascript;
})();

/*
 * this mostly exists because teh Ext.Ajax methods cannot be called synchronously
 * @private
 */
Ext.define("AppShell.net.Request", {
    singleton : true,
    request : function(config) {
        var xhr, url = config.url;
        if (Ext.isString(config)) {
            url = config;
        }
        if (window.XMLHttpRequest) {
            xhr = new window.XMLHttpRequest();
        }
        if (!xhr) {
            xhr = new ActiveXObject("Microsoft.XMLHTTP");
        }

        if (xhr) {

            if (url.indexOf('?') > -1) {
                url += '&';
            } else {
                url += '?';
            }
            if (AppShell.deploymentInfo.useMockData) {
                url += "_dc=" + (new Date().getTime())
            } else {
                url += 'v=' + AppShell.deploymentInfo.version;
            }
            xhr.open("GET", url, !!config.async, config.user, config.password);
            xhr.send(config.data);
            return xhr;
        }
        return;
    }
});

/**
 * Mixin to add logging capability.
 */
Ext.define("AppShell.core.Loggable", {
    requires: ["AppShell.util.log4javascript"],
    config : {
        /**
         *@cfg {String} loggerName
         * If this is not specified, the class name will be used
         */
        loggerName : undefined,
        /**
         *@cfg {String} logLevel
         * The minimum level of message to log.
         * Valid values are:
         *
         *  -   "TRACE"
         *  -   "DEBUG"
         *  -   "INFO"
         *  -   "WARN"
         *  -   "ERROR"
         *  -   "FATAL"
         */
        logLevel : "WARN"
    },
    constructor : function(config) {
        this.initConfig(config);
        /**
         *@property {log4javascript.Logger} logger
         * this is the logging object
         */
        this.logger = log4javascript.getLogger(this.loggerName || Ext.getClassName(this));

        // log4javascript caches logger instances by logger name. So if we already added some appenders, don't add the same ones again
        if (!this.logger.isConfiguredByLoggable) {
            this.logger.setLevel(log4javascript.Level[this.logLevel]);

            var consoleAppender = new log4javascript.BrowserConsoleAppender();
            consoleAppender.setThreshold(this.logger.getLevel());
            var layout = new log4javascript.PatternLayout("[%c] %d{HH:mm:ss} %-5p - %m%n");
            consoleAppender.setLayout(layout);
            this.logger.addAppender(consoleAppender);
            this.logger.isConfiguredByLoggable = true;
        }
    }
});

Ext.define("AppShell.util.AppShellUtils", {});

if (typeof AppShell == 'undefined') {
    AppShell = {
    };
}

if (!Ext.isDefined(AppShell.deploymentInfo)) {
    AppShell.deploymentInfo = {useMockData: true};    
}

AppShell.logger = Ext.create("AppShell.core.Loggable", {
                                loggerName : "AppShell"
                            }).logger;

AppShell.loadCss = function(cssFile) { 
        // you could encode the css path itself to generate id..
        if (!document.getElementById(cssFile)) {
            var url = cssFile;
            if (AppShell.deploymentInfo == undefined || AppShell.deploymentInfo.version == undefined || AppShell.deploymentInfo.version == 'DEV') {
                url += '?_dc=' + new Date().getTime(); 
            } else {
                url += "?v=" + AppShell.deploymentInfo.version;
            }
            var head = document.getElementsByTagName('head')[0];
            var link = document.createElement('link');
            link.id = cssFile;
            link.rel = 'stylesheet';
            link.type = 'text/css';
            link.href = url;
            link.media = 'all';
            head.appendChild(link);
        }
};


/**
 * An object that has some security settings. The required license(s) and
 * privilege(s) can be configured.
 */
Ext.define("AppShell.security.Securable", {
    /**
     * @cfg {String} licenses
     * A license expression using javascript boolean operators. For example:
     * 		(Scorecards || WFM) && Reports
     */

    /**
     * @cfg {String} privileges
     * A privilege expression using Javascript boolean operators. For example:
     *     (VIEW_SCORECARDS || EDIT_SCORECARDS) && REPORTS
     */

    /**
     * @property {Boolean} isSecurable
     * @readonly
     */
    isSecurable : true,
    
    isAuthorized: function(scopes) {
        return AppShell.security.SecurityManager.isAuthorized(this, scopes); 
    }

});

/**
 * HashMap subclass containing objects keyed by their type.
 */
Ext.define("AppShell.util.ObjectBank", {
    extend : "Ext.util.HashMap",

    /**
     * Retrieves an object if it exists, or creates one if it doesn't.
     * If this method creates an object, it will add it to the map.
     * @param {String} type
     * @param {Object} config
     * @param {String} id Optional identifier for the instance. If this is specified, it will be added to the key
     */
    getObject : function(type, config, id) {
        var key = type + ( id ? ":" + id : "");
        var object = this.get(key);
        if(!Ext.isDefined(object)) {
            try {
                object = Ext.create(type, config);
                if(id) {
                    object.id = id;
                }
                this.add(key, object);
            } catch(e) {
                this.add(key, null);
            }
        }
        return object;
    }
});

/**
 * Mixin that adds an id property to an object, which is copied from the config object,
 * the class definition, or auto-generated.
 */
Ext.define("AppShell.core.Identifiable", {
    /**
     * @property {Boolean} isIdentifiable
     * @readonly
     */
    isIdentifiable : true,

    /**
     * @property {String} id
     * @readonly
     */

    /**
     * @cfg {String} id
     */

    /**
     * @cfg idPrefix
     * The prefix to use for the auto-generated ids
     */

    /**
     * @cfg idGenFn
     * Function used for generating an id, if none is specified.
     * If no generator function is defined, the default method will be used.
     */

    constructor : function(config) {
        this.id = (config && config.id) || this.id;
        if(!Ext.isDefined(this.id)) {
            // No id specified. Need to generate the id
            var fn = (config && config.idGenFn) || this.idGenFn;
            if(Ext.isFunction(fn)) {
                this.id = fn.call(this);
            } else {
                this.id = Ext.id(null, (config && config.idPrefix) || this.idPrefix);
            }
        }
    }
});

/* 
 *	Notification / Toastwindow extension for Ext JS 4.x
 *
 *	Copyright (c) 2011 Eirik Lorentsen (http://www.eirik.net/)
 *
 *	Examples and documentation at: http://www.eirik.net/Ext/ux/window/Notification.html
 *
 *	Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php) 
 *	and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.
 *
 *	Version: 2.0
 *	Last changed date: 2012-03-06
 */

Ext.define('AppShell.util.Notification', {
	extend: 'Ext.window.Window',
	alias: 'widget.uxNotification',

	cls: 'ux-notification-window',
	autoHide: true,
	autoHeight: true,
	plain: false,
	draggable: false,
	shadow: false,
	focus: Ext.emptyFn,

	// For alignment and to store array of rendered notifications. Defaults to document if not set.
	manager: null,

	useXAxis: false,

	// Options: br, bl, tr, tl, t, l, b, r
	position: 'br',

	// Pixels between each notification
	spacing: 6,

	// Pixels from the managers borders to start the first notification
	paddingX: 30,
	paddingY: 10,

	slideInAnimation: 'ease',
	slideBackAnimation: 'ease',
	slideInDuration: 1500,
	slideBackDuration: 1000,
	hideDuration: 500,
	autoHideDelay: 7000,
	stickOnClick: true,
	stickWhileHover: true,

	// Private. Do not override!
	isHiding: false,
	readyToHide: false,

	// Caching coordinates to be able to align to final position of siblings being animated
	xPos: 0,
	yPos: 0,

	statics: {
		defaultManager: {
			el: null
		}
	},

	getXposAlignedToManager: function () {
		var me = this;

		var xPos = 0;

		// Avoid error messages if the manager does not have a dom element
		if (me.manager && me.manager.el && me.manager.el.dom) {
			if (!me.useXAxis) {
				// Element should already be aligned verticaly
				return me.el.getLeft();
			} else {
				// Using getAnchorXY instead of getTop/getBottom should give a correct placement when document is used
				// as the manager but is still 0 px high. Before rendering the viewport.
				if (me.position == 'br' || me.position == 'tr' || me.position == 'r') {
					xPos += me.manager.el.getAnchorXY('r')[0];
					xPos -= (me.el.getWidth() + me.paddingX);
				} else {
					xPos += me.manager.el.getAnchorXY('l')[0];
					xPos += me.paddingX;
				}
			}
		}

		return xPos;
	},

	getYposAlignedToManager: function () {
		var me = this;

		var yPos = 0;

		// Avoid error messages if the manager does not have a dom element
		if (me.manager && me.manager.el && me.manager.el.dom) {
			if (me.useXAxis) {
				// Element should already be aligned horizontaly
				return me.el.getTop();
			} else {
				// Using getAnchorXY instead of getTop/getBottom should give a correct placement when document is used
				// as the manager but is still 0 px high. Before rendering the viewport.
				if (me.position == 'br' || me.position == 'bl' || me.position == 'b') {
					yPos += me.manager.el.getAnchorXY('b')[1];
					yPos -= (me.el.getHeight() + me.paddingY);
				} else {
					yPos += me.manager.el.getAnchorXY('t')[1];
					yPos += me.paddingY;
				}
			}
		}

		return yPos;
	},

	getXposAlignedToSibling: function (sibling) {
		var me = this;

		if (me.useXAxis) {
			if (me.position == 'tl' || me.position == 'bl' || me.position == 'l') {
				// Using sibling's width when adding
				return (sibling.xPos + sibling.el.getWidth() + sibling.spacing);
			} else {
				// Using own width when subtracting
				return (sibling.xPos - me.el.getWidth() - me.spacing);
			}
		} else {
			return me.el.getLeft();
		}

	},

	getYposAlignedToSibling: function (sibling) {
		var me = this;

		if (me.useXAxis) {
			return me.el.getTop();
		} else {
			if (me.position == 'tr' || me.position == 'tl' || me.position == 't') {
				// Using sibling's width when adding
				return (sibling.yPos + sibling.el.getHeight() + sibling.spacing);				
			} else {
				// Using own width when subtracting
				return (sibling.yPos - me.el.getHeight() - sibling.spacing);
			}
		}
	},

	getNotifications: function (alignment) {
		var me = this;

		if (!me.manager.notifications[alignment]) {
			me.manager.notifications[alignment] = [];
		}

		return me.manager.notifications[alignment];
	},

	beforeShow: function () {
		var me = this;

		// 1.x backwards compatibility
		if (Ext.isDefined(me.corner)) {
			me.position = me.corner;
		}
		if (Ext.isDefined(me.slideDownAnimation)) {
			me.slideBackAnimation = me.slideDownAnimation;
		}
		if (Ext.isDefined(me.autoDestroyDelay)) {
			me.autoHideDelay = me.autoDestroyDelay;
		}
		if (Ext.isDefined(me.slideInDelay)) {
			me.slideInDuration = me.slideInDelay;
		}
		if (Ext.isDefined(me.slideDownDelay)) {
			me.slideBackDuration = me.slideDownDelay;
		}
		if (Ext.isDefined(me.fadeDelay)) {
			me.hideDuration = me.fadeDelay;
		}

		// 'bc', lc', 'rc', 'tc' compatibility
		me.position = me.position.replace(/c/, '');

		switch (me.position) {
			case 'br':
				me.paddingFactorX = -1;
				me.paddingFactorY = -1;
				me.siblingAlignment = "br-br";
				if (me.useXAxis) {
					me.managerAlignment = "bl-br";
				} else {
					me.managerAlignment = "tr-br";
				}
				break;
			case 'bl':
				me.paddingFactorX = 1;
				me.paddingFactorY = -1;
				me.siblingAlignment = "bl-bl";
				if (me.useXAxis) {
					me.managerAlignment = "br-bl";
				} else {
					me.managerAlignment = "tl-bl";
				}
				break;
			case 'tr':
				me.paddingFactorX = -1;
				me.paddingFactorY = 1;
				me.siblingAlignment = "tr-tr";
				if (me.useXAxis) {
					me.managerAlignment = "tl-tr";
				} else {
					me.managerAlignment = "br-tr";
				}
				break;
			case 'tl':
				me.paddingFactorX = 1;
				me.paddingFactorY = 1;
				me.siblingAlignment = "tl-tl";
				if (me.useXAxis) {
					me.managerAlignment = "tr-tl";
				} else {
					me.managerAlignment = "bl-tl";
				}
				break;
			case 'b':
				me.paddingFactorX = 0;
				me.paddingFactorY = -1;
				me.siblingAlignment = "b-b";
				me.useXAxis = 0;
				me.managerAlignment = "t-b";
				break;
			case 't':
				me.paddingFactorX = 0;
				me.paddingFactorY = 1;
				me.siblingAlignment = "t-t";
				me.useXAxis = 0;
				me.managerAlignment = "b-t";
				break;
			case 'l':
				me.paddingFactorX = 1;
				me.paddingFactorY = 0;
				me.siblingAlignment = "l-l";
				me.useXAxis = 1;
				me.managerAlignment = "r-l";
				break;
			case 'r':
				me.paddingFactorX = -1;
				me.paddingFactorY = 0;
				me.siblingAlignment = "r-r";
				me.useXAxis = 1;
				me.managerAlignment = "l-r";
				break;
			}

		if (typeof me.manager == 'string') {
			me.manager = Ext.getCmp(me.manager);
		}

		// If no manager is provided or found, then the static object is used and the el property pointed to the body document.
		if (!me.manager) {
			me.manager = me.statics().defaultManager;

			if (!me.manager.el) {
				me.manager.el = Ext.getBody();
			}
		}
		
		if (typeof me.manager.notifications == 'undefined') {
			me.manager.notifications = {};
		}

		if (me.stickOnClick) {
			if (me.body && me.body.dom) {
				Ext.fly(me.body.dom).on('click', function () {
					me.cancelAutoHide();
					me.addCls('notification-fixed');
				}, me);
			}
		}

		me.el.hover(
			function () {
				me.mouseIsOver = true;
			},
			function () {
				me.mouseIsOver = false;
			},
			me
		);
		
		if (me.autoHide) {
			me.task = new Ext.util.DelayedTask(me.doAutoHide, me);
			me.task.delay(me.autoHideDelay);
		}

		var notifications = me.getNotifications(me.managerAlignment);

		if (notifications.length) {
			me.el.alignTo(notifications[notifications.length - 1].el, me.siblingAlignment, [0, 0]);
			me.xPos = me.getXposAlignedToSibling(notifications[notifications.length - 1]);
			me.yPos = me.getYposAlignedToSibling(notifications[notifications.length - 1]);
		} else {
			me.el.alignTo(me.manager.el, me.managerAlignment, [(me.paddingX * me.paddingFactorX), (me.paddingY * me.paddingFactorY)]);
			me.xPos = me.getXposAlignedToManager();
			me.yPos = me.getYposAlignedToManager();
		}

		Ext.Array.include(notifications, me);

		me.stopAnimation();
		
		me.setPosition(me.getPosition()[0], 0-me.getHeight());
		
		me.el.animate({
			to: {
				x: me.xPos,
				y: me.yPos,
				opacity: 1
			},
			easing: me.slideInAnimation,
			duration: me.slideInDuration,
			dynamic: true
		});

	},

	slideBack: function () {
		var me = this;

		var notifications = me.getNotifications(me.managerAlignment);
		var index = Ext.Array.indexOf(notifications, me)

		// Not animating the element if it already started to hide itself or if the manager is not present in the dom
		if (!me.isHiding && me.el && me.manager && me.manager.el && me.manager.el.dom && me.manager.el.isVisible()) {

			if (index) {
				me.xPos = me.getXposAlignedToSibling(notifications[index - 1]);
				me.yPos = me.getYposAlignedToSibling(notifications[index - 1]);
			} else {
				me.xPos = me.getXposAlignedToManager();
				me.yPos = me.getYposAlignedToManager();
			}

			me.stopAnimation();

			me.el.animate({
				to: {
					x: me.xPos,
					y: me.yPos
				},
				easing: me.slideBackAnimation,
				duration: me.slideBackDuration,
				dynamic: true
			});
		}
	},

	cancelAutoHide: function() {
		var me = this;

		if (me.autoHide) {
			me.task.cancel();
			me.autoHide = false;
		}
	},

	doAutoHide: function () {
		var me = this;

		/* Delayed hiding when mouse leaves the component.
		   Doing this before me.mouseIsOver is checked below to avoid a race condition while resetting event handlers */
		me.el.hover(
			function () {
			},
			function () {
				me.hide();
			},
			me
		);
		
		if (!(me.stickWhileHover && me.mouseIsOver)) {
			// Hide immediately
			me.hide();
		}
	},


	hide: function () {
		var me = this;

		// Avoids restarting the last animation on an element already underway with its hide animation
		if (!me.isHiding && me.el) {

			me.isHiding = true;

			me.cancelAutoHide();
			me.stopAnimation();

			me.el.animate({
				to: {
				    y: 0-me.getHeight()
				},
				easing: 'easeIn',
				duration: me.hideDuration,
				dynamic: false,
				listeners: {
					afteranimate: function () {
						if (me.manager) {
							var notifications = me.getNotifications(me.managerAlignment);
							var index = Ext.Array.indexOf(notifications, me);
							if (index != -1) {
								Ext.Array.erase(notifications, index, 1);

								// Slide "down" all notifications "above" the hidden one
								for (;index < notifications.length; index++) {
									notifications[index].slideBack();
								}
							}
						}

						me.readyToHide = true;
						me.hide();
					}
				}
			});
		}

		// Calling parents hide function to complete hiding
		if (me.readyToHide) {
			me.isHiding = false;
			me.readyToHide = false;
			me.removeCls('notification-fixed');
			this.callParent(arguments);
		}
	}

});


/*	Changelog:
 *
 *	2011-09-01 - 1.1: Bugfix. Array.indexOf not universally implemented, causing errors in IE<=8. Replaced with Ext.Array.indexOf.
 *	2011-09-12 - 1.2: Added config options: stickOnClick and stickWhileHover.
 *	2011-09-13 - 1.3: Cleaned up component destruction.
 *	2012-03-06 - 2.0: Renamed some properties ending with "Delay" to the more correct: "Duration".
 *                    Moved the hiding animation out of destruction and into hide.
 *	                  Renamed the corresponding "destroy" properties to "hide".
 *                    (Hpsam) Changed addClass to addCls.
 *                    (Hpsam) Avoiding setting 'notification-fixed' when auto hiding.
 *                    (Justmyhobby) Using separate arrays to enable managers to mix alignments.
 *                    (Kreeve_ctisn) Removed default title.
 *	                  (Jmaia) Center of edges can be used for positioning. Renamed corner property to position.
 *                    (Hpsam) Hiding or destroying manager does not cause errors.
 */

/**
 * Used for showing messages to the user
 */
Ext.define("AppShell.util.Notifier", {
    singleton : true,

    /**
     * Used for showing an error message. This is typically some sort of error.
     * By default, this message will remain
     * 
     * @param {String} message
     */
    error : function(message) {
        var n = Ext.create("AppShell.util.Notification", {
            cls : "ux-notification-light alert",
            position : "t",
            closable : false,
            autoHide : false,
            layout : "hbox",
            items : [{
                xtype : "box",
                html : message
            }, {
                xtype : "tool",
                margin : "0 0 0 20",
                type : "close",
                handler : function() {
                    this.up("window").hide();
                }
            }]
        });
        n.show();
        var navContext = AppShell.ContextManager.getContext("wsm");
        if (navContext) {
            n.addManagedListener(navContext, "change", function(){ this.hide(); }, n);
        }
        n.on("hide", function() {
            n.destroy();
        });
    },
    /**
     * Shows a message that is used to acknowledge that a user-initiated action was done.
     * By default, these messages will disappear after a few seconds
     * @param {String} message
     */
    ack : function(message) {
        var tool = Ext.widget({
                xtype : "tool",
                itemId : "close",
                margin : "0 0 0 20",
                type : "close",
                hideMode : "visibility",
                hidden : true,
                handler : function() {
                    this.up("window").hide();
                }
            });
        var n = Ext.create("AppShell.util.Notification", {
            cls : "ux-notification-light",
            closable : false,
            position : "t",
            layout : "hbox",
            items : [{
                xtype : "box",
                html : message
            }, tool]
        });
        var navContext = AppShell.ContextManager.getContext("wsm");
        if (navContext) {
            n.addManagedListener(navContext, "change", function(){ this.hide(); }, n);
        }
        n.show();
        n.el.on("mouseenter", function() {
            tool.show();
        }, n);
        n.el.on("mouseleave", function() {
            tool.hide();
        }, n);
        n.on("hide", function() {
            n.destroy();
        });
    }
});

Ext.define("AppShell.store.Modules", {
    extend : "Ext.data.Store",
    id : "Modules",
    constructor : function(config) {
        if (config) {
            Ext.apply(this, config);
        }
        this.callParent(arguments);
    },
    proxy : {
        type : "ajax",
        url : "AppShell/data/modules.json",
        reader : {
            type : "json",
            root : "modules"
        }
    },
    autoLoad : false,
    fields : [{
        name : "name",
        type : "string"
    }]
});

/**
 * This is a repository for context objects in the system, such as selected organization.
 * 
 * #What is the Context Manager?
 * 
 * The AppShell.ContextManager is a singleton class that can be used to manage 
 * shared objects in the Application Shell system. You can think of the 
 * ContextManager as a hash table of shared state objects with a few added 
 * features.
 * 
 * Since the Context Manager is a global construct, it is important to have 
 * unique identifiers for your contexts. It is recommended that you prefix your 
 * context IDs with your module. For example, if I want a "selectedKPI" context 
 * in my scorecards module, I would make my context ID "scorecards_selectedKPI".
 * 
 * #Video Overview
 * You may watch a video overview of the Context Manager at <a href="\\vm-buildui1\videos\Training Videos\06 - Context Manager.avi">\\\\vm-buildui1\videos\Training Videos\06 - Context Manager.avi</a>.
 * 
 * #Eventing
 * 
 * Besides just being a global repository of shared objects, the Context 
 * Manager also provides events for when a context becomes available or is 
 * unavailable. Widgets also have any easy way to register listeners on any 
 * Observable contexts via the contextHandlers config.
 * 
 * #Stateful Contexts
 * 
 * Contexts that mix in the Ext.state.Stateful mixin can utilize some of the 
 * advanced features of the Context system.
 * 
 * #Bookmark Properties
 * 
 * When a developer adds a context to the ContextManager, they can specify 
 * which properties on the state object should be added to the URL bar. This 
 * allows the end user to bookmark the state and use the back and forward 
 * buttons to change the state. These types of state properties should be used 
 * sparingly, since there is only a limited amount of characters allowable in 
 * the URL.
 * 
 * #Cross-Navigational Properties
 * 
 * Cross-navigation properties are those that may be specified in the URL bar 
 * for the application to consume, but they are not put there automatically. 
 * This means that they cannot be used for bookmark purposes, and they will not 
 * trigger any browser navigation history (no back and forward to change the 
 * state).
 */
Ext.define("AppShell.ContextManager", {
    mixins : {
        observable : "Ext.util.Observable",
        stateful : "Ext.state.Stateful",
        loggable: "AppShell.core.Loggable"
    },
    requires : ["Ext.util.History"],
    singleton : true,

    stateId : "AppShell.ContextManager",
    stateful : true,

    events : [
    /**
     * @event available
     * Fires when a new context item is added, or when a new listener is added and there are existing
     * contexts available.
     * @param {String} identifier of the context
     * @param {Object} context object
     */"available",
    /**
     * @event unavailable
     * Fires before a context item is removed
     * @param {String} identifier of the context
     * @param {Object} context object
     */
    "unavailable"],

    constructor : function(config) {
        this.callParent(arguments);
        this.mixins.observable.constructor.apply(this, arguments);
        this.mixins.stateful.constructor.apply(this, arguments);
        this.mixins.loggable.constructor.apply(this, arguments);

        Ext.apply(this, {
            /**
             * A map of contexts keyed by contextId
             * @private
             */
            contexts : new Ext.util.HashMap(),
            /**
             * An {Object} of states to be stored in the URL, keyed by contextId
             * @private
             */
            contextStateMap : {},
            /**
             * A {String} reprenenting the entire serialized contextStateMap object.
             * @private
             */
            historyToken : null,

            changeHistory : Ext.Function.createBuffered(Ext.util.History.add, 50, Ext.util.History)

        });

        this.contexts.addListener("add", function(contexts, contextId, context, eOpts) {
            this.fireEvent("available", contextId, context);
        }, this);
        this.contexts.addListener("remove", function(contexts, contextId, context, opts) {
            this.fireEvent("unavailable", contextId, context);
        }, this);

        // Add a listener onto the history to deserialize contexts when the back or forward button is pressed
        Ext.util.History.init(function() {
            this.handleHistoryChange();
            Ext.util.History.on("change", this.handleHistoryChange, this);
        }, this);
    },

    /**
     * Overridden to call the handler with the "available" event for each context
     * that exists in the collection.
     *
     * @override
     */
    addListener : function(eventName, fn, scope, options) {
        this.mixins.observable.addListener.apply(this, arguments);
        if(eventName === "available") {
            this.contexts.each(function(contextId, context) {
                fn.call(scope || this, contextId, context);
            }, this);
        }
    },
    /**
     *
     * This method will add a new context into the system.
     *
     * If the context is an instance of {Ext.state.Stateful}, it can be used
     * to provide browser back/forward/bookmark support as well as cross navigation.
     *
     * @param {String} contextId
     * @param {Object / Ext.state.Stateful} context
     * @param {String[]} bookmarkProps (Optional) properties to serialize/deserialize to the URL. This enables bookmarks, back/forward, and cross navigation for those properties.
     * @param {String[]} crossNavProps (Optional) properties to deserialize from the URL. These will be applied to the context via the Ext.state.Stateful.applyState method, but will not show up in the URL automatically
     *
     */
    addContext : function(contextId, context, bookmarkProps, crossNavProps) {
        if(!context) {
            this.logger.error("ContextManager.js: addContext cannot add an empty context with id: " + contextId);
            return;
        }

        // It is possible that the state has already been read via URL.
        // If so, apply the state now.
        if(context.stateful && this.contextStateMap[contextId]) {
            context.applyState(this.contextStateMap[contextId]);
        }

        if((bookmarkProps || crossNavProps) && !context.stateful) {
            this.logger.error("ContextManager.js: Expected the context with id=" + contextId + " to be Ext.state.Stateful");
        } else {
            // Set up listeners for the bookmark props so we can update the URL when the state changes
            if(bookmarkProps && bookmarkProps.length > 0) {
                var contextScope = {
                    id : contextId,
                    context : context,
                    props : bookmarkProps,
                    cm : this
                };
                context.addListener("statesave", this.handleStateChange, contextScope);
                context.addListener("staterestore", this.handleStateChange, contextScope);
                this.handleStateChange.call(contextScope, context, context.getState());
            }
        }

        this.contexts.add(contextId, context);
    },

    /**
     * Updates the browser's URL in response to a state change from a context that was added
     * with some bookmarkProperties specified.
     *
     * @scope Object with id, props, and cm properties
     * @private
     */
    handleStateChange : function(context, state) {
        var id = this.id;
        var props = this.props;
        var cm = this.cm;

        cm.contextStateMap[id] = null;
        if(state != null) {
            cm.contextStateMap[id] = {};
            Ext.copyTo(cm.contextStateMap[id], state, props);
        }
        cm.updateHistoryToken();
    },

    updateHistoryToken : function() {
        var historyToken = Ext.Object.toQueryString(this.contextStateMap, true);

        if(historyToken == this.historyToken)
            return;

        this.historyToken = historyToken;
        this.changeHistory(this.historyToken);
    },

    /**
     * @param contextId {String}
     */
    getContext : function(contextId) {
        return this.contexts.get(contextId);
    },
    removeContext : function(context) {
        this.contexts.remove(context);
    },

    /**
     *
     * @private
     */
    handleHistoryChange : function(serialized) {
        if(!serialized) {
            serialized = Ext.util.History.getToken();
        }

        if(serialized == this.historyToken) {
            return;
        }

        this.historyToken = serialized;

        if(serialized) {
            var newState = Ext.Object.fromQueryString(serialized, true);
            for(var contextId in newState) {
                var contextStateEncoded = newState[contextId] && Ext.Object.toQueryString(newState[contextId], true);
                if(contextStateEncoded != (this.contextStateMap[contextId] && Ext.Object.toQueryString(this.contextStateMap[contextId], true))) {
                    this.contextStateMap[contextId] = newState[contextId];
                    var context = this.getContext(contextId);
                    if(context) {
                        context.applyState(newState[contextId]);
                    }
                }
            }
        }
    },

    getState : function() {
        return {
            urlState : this.contextStateMap
        };
    },

    applyState : function(newState) {
        Ext.apply(this.contextStateMap, newState.urlState);
        this.updateHistoryToken();
    },

    /**
     * Goes through a an object's context handler cfg and registers the appropriate listeners
     * @private
     * @param {Object} pageWidget
     */
    processContextHandlers : function(pageWidget) {
        // Loop throught context handler config
        if(pageWidget.contextHandlers) {
            Ext.Object.each(pageWidget.contextHandlers, function(contextName, contextHandlerEntry) {

                // Define a new variable to hold the context object
                var m_context = null;

                // Define a getter for the new context.
                pageWidget["get" + contextName.substring(0, 1).toUpperCase() + contextName.substring(1) + "Context"] = function() {
                    return m_context;
                };

                /*
                 * Get the event handling config from the controller.
                 *
                 * The syntax is either
                 * 		- an object with keys of context events and values of functions
                 * 		- An object with "available", "unavailable", and "contextEvents" keys. In this case,
                 * 			"available" and "unavailable" will respond to events of the ContextManager, when
                 * 			the context has a lifecycle event. The "contextEvents" property will be a config
                 * 			containing handlers for the context's events.
                 *
                 */
                var registerManagerHandlers = false;
                var eventsObject = contextHandlerEntry;
                if(eventsObject.contextEvents) {
                    registerManagerHandlers = true;
                    eventsObject = eventsObject.contextEvents;
                } else {
                    if(eventsObject.available !== undefined) {
                        this.logger.warn(Ext.getClassName(pageWidget) + ": A 'contextEvents' property is not defined in the contextHandlers config. The 'available' event handler will respond to context events, not the context manager event.");
                    }
                }

                /*
                 * If the widget specified handlers for the "available" or "unavilable" contextmanager events, register them here.
                 */
                if(registerManagerHandlers) {
                    if(contextHandlerEntry.available) {
                        if( typeof (contextHandlerEntry.available) === "function") {
                            this.addManagedListener(AppShell.ContextManager, "available", function(contextId, context) {
                                if(contextId === contextName) {
                                    contextHandlerEntry.available.call(pageWidget, contextId, context);
                                }
                            }, pageWidget);
                        } else {
                            this.logger.error(pageWidget.getClassName() + ": Error registering the available handler for context: " + contextName + ". No function specified.");
                        }
                    }
                    if(contextHandlerEntry.unavailable) {
                        if( typeof (contextHandlerEntry.unavailable) === "function") {
                            this.addManagedListener(AppShell.ContextManager, "unavailable", function(contextId, context) {
                                if(contextId === contextName) {
                                    contextHandlerEntry.unavailable(contextId, context);
                                }
                            }, pageWidget);
                        } else {
                            this.logger.error(pageWidget.getClassName() + ": Error registering the unavailable handler for context: " + contextName + ". No function specified.");
                        }
                    }
                }

                // Add listeners for when the context is made available / unavailable
                pageWidget.addManagedListener(AppShell.ContextManager, "available", function(contextId, context) {
                    // If the context is the one we are interested in, set it as the variable
                    if(contextId === contextName) {
                        m_context = context;
                        // register an event listener on the context
                        for(var eventName in eventsObject) {
                            this.addManagedListener(context, eventName, eventsObject[eventName], this);
                        }
                    }
                }, pageWidget);
                pageWidget.addManagedListener(AppShell.ContextManager, "unavailable", function(contextId, context) {
                    if(contextId === contextName) {
                        m_context = null;
                        for(var eventName in eventsObject) {
                            this.removeManagedListener(context, eventName, eventsObject[eventName], this);
                        }
                    }
                }, pageWidget);
            }, pageWidget);
        }

    }
});

/**
 * This class has methods on it for internationalization. It currently provides
 * a method to get a locale-specific string.
 *
 * It also publishes a itself as a "locale" context object in the Context
 * Management system.
 *
 * @contextId locale
 */
Ext.define("AppShell.i18n.Localizer", {
    extend : "Ext.state.Stateful",
    singleton : true,
    requires : ["AppShell.ContextManager", "AppShell.net.Request"],
    stateId : "locale",
    stateful : true,
    stateEvents : ["localechange"],

    mixins : {
        loggable : "AppShell.core.Loggable"
    },

    constructor : function(config) {
        this.mixins.loggable.constructor.apply(this, arguments);
        this.callParent(arguments);

        AppShell.ContextManager.addContext("locale", this, [], ["currentLocale"]);

        this.setupCircleTextMap();

        this.registerI18nService("com.bluepumpkin.common.l10n", {
            url : AppShell.deploymentInfo.wfoRestPrefix + 'loc/get',
            mockUrl : 'AppShell/data/ResourceBundles.json'
        });
        this.loadRegionalFormatBundle();
    },

    loadRegionalFormatBundle : function() {
        this.loadBundles(["com.bluepumpkin.common.l10n.RegionalFormatBundle"], Ext.bind(this.fixRegionalFormatBundle, this));
    },
    
    fixRegionalFormatBundle: function() {
        var bundle = this.getBundle("com.bluepumpkin.common.l10n.RegionalFormatBundle");
        if (bundle) {
            var keysToRemove = [];
            Ext.Object.each(bundle, function(key, value) {
                // Translate naming convention of Java bundle to the convention we are using in Javascript
                if (this.regionalFormatKeySubstitutions[key]) {
                    keysToRemove.push(key);
                    key = this.regionalFormatKeySubstitutions[key];
                }
                
                // Convert the format from java-style to php-style
                bundle[key] = this.convertRegionalFormatBundleValue(value);
            }, this);

            // remove any old names that we no longer care about
            Ext.each(keysToRemove, function(key) {
                delete bundle[key];
            });
        }
    },

    /*
     * Converts Java style formats to PHP style formats (same as extjs uses).
     */
    convertRegionalFormatBundleValue : function(value) {
        Ext.each(this.regionalFormatBundleSubstitutions, function(replacePair) {
            value = value.replace(new RegExp(replacePair[0], 'g'), replacePair[1]);
        }, this);
        return value;
    },
    regionalFormatBundleSubstitutions : [["yyyy", "Y"], ["yy", "y"], ["MMMMM", "F"], ["MMMM", "F"], ["MMM", "M"], ["MM", "m"], ["EEEEEE", "l"], ["EEEEE", "l"], ["EEEE", "l"], ["EEE", "D"], ["dd", "d"], ["HH", "H"], ["mm", "i"], ["ss", "s"], ["hh", "h"], ["a", "A"], ["S", "u"]],
    regionalFormatKeySubstitutions : {
        "DATE_FORMAT" : "DATE_SHORT",
        "MEDIUM_DATE_FORMAT" : "DATE_MEDIUM",
        "FULL_DATE_FORMAT" : "DATE_LONG",
        "TIME_FORMAT": "TIME_SHORT",
        "TIME_SEC_FORMAT" : "TIME_LONG",
        "DATE_DAYINWEEK_FORMAT": "DATE_SHORT_W_DAY",
        "DATE_DAY_OF_WEEK_ONLY": "DATE_SHORT_DAY",
        "DATE_MONTH_YEAR_FORMAT": "DATE_MEDIUM_MONTH_YEAR",
        "DATE_NOYEAR_DAYINWEEKFULL_FORMAT": "DATE_SHORT_W_DAY_NO_YEAR",
        "DATE_NOYEAR_DAYINWEEK_MONTHABBREV_FORMAT": "DATE_MEDIUM_W_DAY_NO_YEAR",
        "DATE_NOYEAR_FORMAT": "DATE_SHORT_NO_YEAR",
        "DECIMAL_NUMBER_INPUT_SEPARATOR" : "DECIMAL_MARK",
        "MONTH_FORMAT": "DATE_LONG_MONTH"
    },

    /**
     *@private
     */
    setupCircleTextMap : function() {
        var i = 0, circleChars = "⓪①②③④⑤⑥⑦⑧⑨ⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ";
        this.circleTextMap = {};
        for ( i = 0; i < 10; i++) {
            this.circleTextMap[String.fromCharCode(48 + i)] = circleChars.charAt(i);
        }
        for ( i = 0; i < 26; i++) {
            this.circleTextMap[String.fromCharCode(65 + i)] = circleChars.charAt(10 + i);
        }
        for ( i = 0; i < 26; i++) {
            this.circleTextMap[String.fromCharCode(97 + i)] = circleChars.charAt(36 + i);
        }
    },

    /**
     *@private
     */
    pseudoLocalize : function(str) {
        var i = 0, newStrArr = [], chr, inBraces = 0;
        for ( i = 0; i < str.length; i++) {
            chr = str.charAt(i);
            newStrArr[i] = (this.circleTextMap[chr] && !inBraces ) ? this.circleTextMap[chr] : chr;

            if (chr === '{') {
                inBraces++;
            }
            if (chr === '}') {
                inBraces--;
                if (inBraces < 0) {
                    inBraces = 0;
                }
            }
        }
        return newStrArr.join('');
    },

    currentLocale : {
        languageCode : "en",
        countryCode : "us",
        variant : ""
    },

    getState : function() {
        return {
            currentLocale : this.currentLocale
        };
    },

    applyState : function(state) {
        this.callParent(arguments);
        this.fireLocaleChangeEvent();
    },

    /**
     * @event localechange
     * @param {String} languageCode
     * @param {String} countryCode
     * @param {String} variant
     */
    events : ["localechange"],

    /**
     *
     * @param {String} languageCode
     * @param {String} countryCode
     * @param {String} variant
     */
    setLocale : function(languageCode, countryCode, variant) {
        this.currentLocale = {
            languageCode : languageCode || this.currentLocale.languageCode,
            countryCode : countryCode || this.currentLocale.countryCode,
            variant : variant || this.currentLocale.variant
        };
        var bundlesToLoad = Ext.Array.clone(this.bundleNames);
        this.bundles = {};
        this.bundleNames = [];
        this.loadBundles(bundlesToLoad, Ext.bind(function() {
            this.fixRegionalFormatBundle();
            this.fireEvent('beforelocalechangeevent', this);
            this.fireLocaleChangeEvent();
        }, this));
    },

    fireLocaleChangeEvent : function() {
        this.fireEvent("localechange", this.currentLocale.languageCode, this.currentLocale.countryCode, this.currentLocale.variant);
    },

    /**
     * @return {Object} with properties: languageCode, countryCode, variant
     */
    getLocale : function() {
        return Ext.clone(this.currentLocale);
    },

    bundles : {},
    bundleNames : [],
    i18nServices : {},

    getBundle : function(bundleName) {
        var bundle = this.bundles[bundleName];
        if (!bundle) {
            this.loadBundles([bundleName]);
            bundle = this.bundles[bundleName]
            if (!bundle) {
                bundle = this.getBundleClass(bundleName);
            }
        }
        return bundle;
    },

    loadBundles : function(bundleNames, callback) {
        var bundlesByServiceId = {};
        Ext.each(bundleNames, function(bundleName) {
            var serviceId = bundleName.substring(0, bundleName.lastIndexOf('.'));
            if (!bundlesByServiceId[serviceId]) {
                bundlesByServiceId[serviceId] = [];
            }
            bundlesByServiceId[serviceId].push(bundleName);
        }, this);

        Ext.Object.each(bundlesByServiceId, function(serviceId, bundles) {
            var i18nService = this.i18nServices[serviceId];
            if (!i18nService) {
                // No i18nService
                this.logger.error("Cannot load bundles: " + bundles.join(",") + ". No i18n service defined for bundle prefix: " + serviceId + ". Either it hasn't been specified in your module config, or you are trying to localize values before the module has been initialized.");
                return;
            }
            var url = this.getI18nServiceUrl(i18nService, bundles)
            if (Ext.isFunction(callback)) {
                Ext.Ajax.request({
                    scope : this,
                    url : url,
                    callback : function(options, success, response) {
                        this.handleAjaxResponse(response);
                        callback.apply(this, arguments);
                    }
                });
            } else {
                // Make a synchronous request
                var response = AppShell.net.Request.request(url);
                this.handleAjaxResponse(response);
            }
        }, this);

    },

    handleAjaxResponse : function(response) {
        if (response.status === 200) {
            Ext.Object.each(Ext.JSON.decode(response.responseText).Localization.resourceBundles, function(name, resources) {
                this.bundles[name] = resources;
                if (!Ext.Array.contains(this.bundleNames, name)) {
                    this.bundleNames.push(name);
                }
            }, this);
        }
    },

    getI18nServiceUrl : function(i18nService, bundleNames) {
        if (!Ext.isArray(bundleNames)) {
            bundleNames = [bundleNames];
        }
        var url = (AppShell.deploymentInfo.useMockData ? (i18nService.mockUrl || i18nService.url) : i18nService.url) || i18nService;
        if (url.indexOf('?') > 0) {
            url += '&';
        } else {
            url += '?';
        }
        url += 'bundles=' + bundleNames.join(',');
        if (this.currentLocale) {
            Ext.each(['languageCode', 'countryCode', 'variant'], function(property) {
                if (this.currentLocale[property]) {
                    url += '&' + property + '=' + this.currentLocale[property];
                }
            }, this);
        }
        return url;
    },

    /**
     *@private
     * @deprecated
     */
    getBundleClass : function(bundleName) {
        var suffix, suffixShorter, suffixShortest, bundle;
        if (this.currentLocale) {
            if (this.currentLocale.languageCode) {
                suffix = "_" + this.currentLocale.languageCode;
                suffixShortest = suffix;
            }
            if (this.currentLocale.countryCode) {
                suffix += "_" + this.currentLocale.countryCode;
                suffixShorter = suffix;
            }
            if (this.currentLocale.variant) {
                suffix += this.currentLocale.variant;
            }
            if (suffix) {
                try {
                    bundle = Ext.create(bundleName + suffix);
                } catch(e) {
                }
            }
            if (!bundle && suffixShorter) {
                try {
                    bundle = Ext.create(bundleName + suffixShorter);
                } catch(e) {
                }
            }
            if (!bundle && suffixShortest) {
                try {
                    bundle = Ext.create(bundleName + suffixShortest);
                } catch(e) {
                }
            }
        }
        if (!bundle) {
            try {
                bundle = Ext.create(bundleName);
            } catch(e) {
            }
        }
        return bundle && bundle.strings;
    },

    /**
     *
     * @param {Object} bundleName
     * @param {Object} key
     * @param {Mixed} param...
     */
    getString : function(bundleName, key) {

        var str, bundle = this.getBundle(bundleName);
        if (bundle) {
            str = bundle[key];
        }
        if (!str) {
            this.logger.warn("Didn't localize value for bundle: " + bundleName + ", key: " + key);
            str = key;
        }

        if (AppShell.deploymentInfo.useMockData && this.currentLocale && this.currentLocale.languageCode !== "en") {
            str = this.pseudoLocalize(str);
        }

        if (arguments.length > 2 && arguments[2].length > 0) {
            var params = [str];
            params = params.concat(Ext.Array.slice(arguments, 2));
            str = Ext.String.format.apply(Ext.String, params);
        }
        return str;
    },

    registerI18nService : function(namespace, i18nService) {
        this.i18nServices[namespace] = {
            url : i18nService.url || i18nService,
            mockUrl : i18nService.mockUrl || i18nService.url || i18nService
        }

        if (i18nService.preloadBundles) {
            this.loadBundles(i18nService.preloadBundles);
        }
    }
});


/**
 * Contains commonly used Date formats.
 *
 * The properties of this class may also be used as date "style" directives
 * in the Localizable mixin.
 */
Ext.define("AppShell.i18n.DateFormats", {
    requires : ['AppShell.i18n.Localizer'],
    singleton : true,
    props : {
        /**
         *@property 
         */
        DATE_LONG : "l, F d, Y",
        /**
         *@property 
         */
        DATE_LONG_MONTH : "F",
        /**
         *@property 
         */
        DATE_MEDIUM : "M d, Y",
        /**
         *@property 
         */
        DATE_MEDIUM_MONTH_YEAR : "M Y",
        /**
         *@property 
         */
        DATE_MEDIUM_W_DAY_NO_YEAR : "D, M d",
        /**
         *@property 
         */
        DATE_SHORT : "m/d/Y",
        /**
         *@property 
         */
        DATE_SHORT_DAY : "D",
        /**
         *@property 
         */
        DATE_SHORT_NO_YEAR : "m/d",
        /**
         *@property 
         */
        DATE_SHORT_W_DAY : "D m/d/Y",
        /**
         *@property 
         */
        DATE_SHORT_W_DAY_NO_YEAR : "D m/d",
        /**
         *@property 
         */
        DECIMAL_MARK : ".",
        /**
         *@property 
         */
        DURATION_SEPARATOR : ":",
        /**
         *@property 
         */
        TIME_LONG : "h:i:s A",
        /**
         *@property 
         */
        TIME_SHORT : "h:i A"
    },
    constructor : function(config) {
        Ext.apply(this, this.props);
        AppShell.i18n.Localizer.on("beforelocalechangeevent", this.setPropsFromBundle, this);
        this.setPropsFromBundle();
    },
    setPropsFromBundle : function() {
        Ext.Object.each(this.props, function(propName, val) {
            var val = AppShell.i18n.Localizer.getString('com.bluepumpkin.common.l10n.RegionalFormatBundle', propName);
            this[propName] = val;
        }, this);
    }
})

Ext.define("AppShell.security.SecurityContext", {
    requires : ["AppShell.ContextManager"],
    constructor : function(config) {
        this.initConfig(config);
        AppShell.ContextManager.addContext("security", this);
    },

    config : {
        xsrfToken : null,
        privileges : null,
        licenses : null
    }
});

/**
 * A Singleton responsible for evaluating the security information. It has a
 * method to evaluate a license expression and one to evaluate a privilege
 * expression.
 */
Ext.define("AppShell.security.SecurityManager", {
    singleton : true,
    requires : ["AppShell.security.SecurityContext"],

    /**
     *
     * @param {String} licenseExpression
     */
    hasLicenses : function(licensesExprStr) {
        if (!licensesExprStr)
            return true;
        var secCtx = AppShell.ContextManager.getContext("security");
        if (!secCtx) {
            return false;
        }

        /*
         * Note that below, originally, the licenses object was a local variable,
         * but the Google Closure compiler optimized it away, since
         * it cannot tell that it was being used in the eval statement.
         *
         * To fix this, it was attached to this object as a property and then deleted afterwards
         */

        licensesExprStr = licensesExprStr.replace(/(^|[^A-Za-z_])([A-Za-z_.]+)/g, "$1AppShell.security.SecurityManager.licenses['$2']");
        AppShell.security.SecurityManager.licenses = {};
        Ext.each(secCtx.licenses, function(license) {
            AppShell.security.SecurityManager.licenses[license] = true;
        });
        var retVal = !!eval(licensesExprStr);
        delete AppShell.security.SecurityManager.licenses;
        return retVal;
    },

    /**
     * @param {String} privilegeExpression
     */
    hasPrivileges : function(privilegesExprStr, scope) {
        if (!privilegesExprStr) {
            return true;
        }
        var secCtx = AppShell.ContextManager.getContext("security");
        if (!secCtx) {
            return false;
        }

        if (!scope) {
            /*
             * Note that below, originally, the privs object was a function-local variable,
             * but the Google Closure compiler optimized it away, since
             * it cannot tell that it was being used in the eval statement.
             *
             * To fix this, it was attached to this object as a property and then deleted afterwards
             */
            AppShell.security.SecurityManager.privs = {};
            Ext.Object.each(secCtx.privileges, function(priv, scopes) {
                AppShell.security.SecurityManager.privs[priv] = true;
            }, this);
            privilegesExprStr = privilegesExprStr.replace(/(^|[^A-Za-z_])([A-Za-z_.]+)/g, "$1AppShell.security.SecurityManager.privs['$2']");
            var retVal = !!eval(privilegesExprStr);
            delete AppShell.security.SecurityManager.privs;
            return retVal;
        }
        return false;

    },

    isAuthorized : function(securable, scopes) {
        return AppShell.security.SecurityManager.hasLicenses(securable.licenses) && AppShell.security.SecurityManager.hasPrivileges(securable.privileges, scopes);
    }
});

/**
 * Typically a mixin in a view class.
 *
 * This class will add some i18n capabilities to whatever it is mixed into.
 * It works by reading the values from specified source properties, transforming them,
 * and setting the new values in specified target properties.
 *
 * For example, if we want to have a localizable date, the source property may be a
 * Javascript Date object. The target property will be a String type. An example of
 * the configuration for this scenario is the following
 *
 *          bundleName: "MyModule.MyBundle"     //configure bundle services for this namespace in your module definition 
 *          i18nCfg: {
 *              // Simple date formatting
 *              startDateDisplay: {src: "startDate"},
 *              startDateCustomFormat: {src: "startDate", format: "Y-m-d" },
 *              // You can also format dates and times with styles
 *              startDateShort: {src: "startDate", style: "DATE_SHORT" },
 *              startDateMedium: {src: "startDate", style: "DATE_MEDIUM" },
 *              startDateLong: {src: "startDate", style: "DATE_LONG" },
 *              startTimeDisplay: {src: "startDate", style: "TIME_SHORT" },
 *              startTimeWSecs: {src: "startDate", style: "TIME_LONG" },

 *              // This uses simple string replacement from a bundle without parameters
 *              title: "page title bundle key",
 *              // If you have parameters, you need to specify which properties will provide the values
 *              helloDisplay: {key: "helloUser", params: ["currentUserName"]}
 *          }
 *
 * ### String Parameters
 * Any parameter properties (specified through the params config property), will
 * have a setter generated if one doesn't exist. If one already exists, an
 * interceptor will be added. The behavior of these additional functions is to
 * update the properties that are dependent
 * 
 * ### Example
 * 
 * For an example, let's take a label which we want to say "Found x out of y records".
 * The value of the string in the bundle would be: "Found {0} out of {1} records"
 * 
 * Here is one way to do the label:
            
            Ext.define(“MyModule.FoundRecordsLabel ”, {
                            extend: “Ext.form.Label”,
                            config: {
                                            maxRecords: 0,
                                            numRecords: 0
            },
                            bundleName: “MyModule.MyBundle”,
                            i18nCfg: {
                                            text: {key:“Found_X_Records_Bundle_Key”, params:[‘numRecords’,’maxRecords’]} 
                            },
                            constructor: function(config){ 
                                            this.initConfig(config);
                                            this.callParent(arguments);
                            }
            });
            
 * When you want to change the value of the label, you need to call setMaxRecords or setNumRecords on your label instance.
 * 
 */
Ext.define("AppShell.i18n.Localizable", {
    requires : ["AppShell.i18n.Localizer", "AppShell.ContextManager"],

    mixins : {
        observable : "Ext.util.Observable"
    },

    /**
     *@property
     */
    isLocalizable : true,

    config : {

        /**
         * @cfg {String} bundleName name of the default resource bundle used by this class
         */
        bundleName : undefined,

        /**
         *@cfg {Object} i18nCfg config object of properties that are localizable.
         * keys are property names. values are either {String} bundleKeys or a config object with
         * \{bundle: bundleName, key: key, type: (String/Date/Number), params: (Array(Object)), format: type-specfic format\, src: {String} sourceProp}
         *
         */
        i18nCfg : {}
    },

    constructor : function(config) {
        /**
         *@event propertychange
         * Fired when a property changes due to a locale change
         * @param {AppShell.i18n.Localizable} this
         * @param {String} propertyName
         * @param {String} newVal
         */
        /**
         *@event localechange
         * Fires after all properties have been updated
         * @param this
         * @param languageCode
         * @param countryCode
         * @param variant
         */
        this.addEvents("propertychange", "localechange");
        Ext.apply(this, config);
        this.callParent(arguments);

        this.generateSettersForProps();
        this.generateSettersForParamProps();

        this.mixins.observable.constructor.apply(this, arguments);

        this.fireLocaleChange = Ext.pass(this.fireEvent, ["localechange", this], this);

        var localeContext = AppShell.ContextManager.getContext("locale");
        if (localeContext) {
            this.addManagedListener(localeContext, "localechange", this.onLocaleChange, this);
            var currentLocale = localeContext.getLocale();
            if (currentLocale) {
                this.onLocaleChange(currentLocale.languageCode, currentLocale.countryCode, currentLocale.variant);
            }
        }
    },

    generateSetterUpdateProps : function(propMap) {
        // Generate setter (if needed) and interceptor to update the i18n props
        Ext.Object.each(propMap, function(propName, dependentPropArr) {
            var setterName = "set" + propName.substring(0, 1).toUpperCase() + propName.substring(1);
            if (!Ext.isDefined(this[setterName])) {
                this[setterName] = function(newVal) {
                    this[propName] = newVal;
                }
            }

            Ext.Function.interceptAfter(this, setterName, function(newVal) {
                Ext.each(dependentPropArr, this.updateProperty, this);
            }, this);
        }, this);
    },

    generateSettersForProps : function() {
        // Construct a map of prop names to array of i18n props that are dependent on it
        var srcProps = {};
        Ext.Object.each(this.i18nCfg, function(propName, cfg, i18nCfg) {
            if (Ext.isObject(cfg) && cfg.src) {
                if (!srcProps[cfg.src]) {
                    srcProps[cfg.src] = [];
                }
                srcProps[cfg.src].push(propName);
            }
        }, this);

        this.generateSetterUpdateProps(srcProps);
    },

    /**
     * Generates setters for properties that are parameters of the i18n properties.
     * The setters will automatically trigger updates to the relevant i18n properties.
     * @private
     */
    generateSettersForParamProps : function() {
        // Construct a map of param prop names to array of i18n props that are dependent on it
        var paramProps = {};
        Ext.Object.each(this.i18nCfg, function(propName, cfg, i18nCfg) {
            if (Ext.isObject(cfg) && cfg.params) {
                Ext.each(cfg.params, function(paramProp, index, params) {
                    if (!paramProps[paramProp]) {
                        paramProps[paramProp] = [];
                    }
                    paramProps[paramProp].push(propName);
                }, this);
            }
        }, this);

        this.generateSetterUpdateProps(paramProps);
    },

    /**
     * Updates a property from the i18n cfg
     * @private
     */
    updateProperty : function(propName) {
        var i18nCfg = this.i18nCfg[propName];
        // i18nCfg is either a String bundleKey or a config object with keys bundleName and bundkeKey
        var params = [];
        Ext.each(i18nCfg.params, function(propName, index, propNames) {
            if (Ext.isFunction(propName)) {
                params.push(propName.call(this));
            } else if (Ext.isFunction(this[propName])) {
                params.push(this[propName]());
            } else {
                var getterFn = this["get" + propName.substring(0, 1).toUpperCase() + propName.substring(1)];
                if (Ext.isFunction(getterFn)) {
                    params.push(getterFn.call(this));
                } else {
                    params.push(this[propName]);
                }
            }
        }, this);

        var value;

        // String
        if ("string" === i18nCfg.type || i18nCfg.key || Ext.isString(i18nCfg)) {
            value = AppShell.i18n.Localizer.getString(this.bundleName || i18nCfg.bundleName, i18nCfg.key || i18nCfg, params);
        } else
        // Date
        if ("date" === i18nCfg.type || Ext.isDate(this[i18nCfg.src])) {
            var format = i18nCfg.format;
            var style = i18nCfg.style;
            if (format && style) {
                if (this.logger) {
                    this.logger.warn("You should not specify both a format and style when formatting dates");
                }
            }
            if (style) {
                format = AppShell.i18n.Localizer.getString("com.bluepumpkin.common.l10n.RegionalFormatBundle", style) || format;
            }
            value = Ext.util.Format.date(this[i18nCfg.src], format);
        } else
        // Number
        if ("number" === i18nCfg.type || Ext.isNumber(this[i18nCfg.src])) {
            value = Ext.util.Format.number(this[i18nCfg.src], i18nCfg.format || "0,0");
        }

        var methodName = "set" + propName.substring(0, 1).toUpperCase() + propName.substring(1);
        if (Ext.isFunction(this[methodName])) {
            this[methodName].call(this, value);
        } else {
            this[propName] = value;
        }
    },

    /**
     * Called when the locale changes. The default implementation will go though the localizable properties,
     * retrive the new values from the Localizer, and call the setters of those properties with the new values.
     *
     * @param {Object} languageCode
     * @param {Object} countryCode
     * @param {Object} variant
     * @private
     */
    onLocaleChange : function(languageCode, countryCode, variant) {
        Ext.Object.each(this.i18nCfg, this.updateProperty, this);
        this.fireLocaleChange.apply(this, arguments);
    }
}, function() {
    // Add Localizable mixin to all Components
    Ext.define("AppShell.i18n.Component", {
        override : "Ext.Component",
        constructor : function() {
            this.callParent(arguments);
            var localizableMixin = Ext.create("AppShell.i18n.Localizable");
            if (!Ext.isDefined(this.mixins)) {
                this.mixins = {};
            }
            this.mixins.localizable = localizableMixin;
            Ext.applyIf(this, localizableMixin);
            this.mixins.localizable.constructor.call(this, arguments);
        }
    });
});

/**
 * #What is a Module?
 * 
 * Modules can be thought of as sub-applications.  They represent a functional 
 * area of related code that should all be loaded together. They are loaded up 
 * at the beginning of the application's lifecycle. 
 * 
 * Besides designating a set of code that should be loaded all at the same 
 * time, the Module will allow developers to attach metadata to that set of 
 * code, such as the security information that is required for the user to see 
 * the screen (licenses and privileges via the AppShell.security.Securable 
 * mixin), and also which screens are provided as a part of the module. 
 * 
 * Determining how much code to include in a single module is somewhat 
 * arbitrary. A good place to start is by including code that requires the same 
 * licenses in the same module. If that proves to be too much code, you can 
 * decide to split it. One natural place to split is separating any widgets 
 * that are meant to be shared with other modules into their own module. 
 * 
 * #Creating a New Module
 * ##The Folder
 * Creating a new module is as simple as creating a new top level folder to be 
 * deployed as a sibling of the AppShell's index.html.
 * 
 * The name of this folder will be the first part of the namespace used in all 
 * of your classes in the module, including the module definition itself. For 
 * example, if you were to have a store representing people inside of the 
 * Scorecards module, the class name would be Scorecards.store.People, and it 
 * would be placed in the appropriate folder.
 * 
 * Typically, the structure inside of your module folder will mirror that of a 
 * traditional MVC application in ExtJS. For example, an example module for 
 * scorecards might look like the following:
 * 
 * 
 * <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANkAAACVCAIAAABaRsg2AAAAAXNSR0IArs4c6QAAEHBJREFUeF7tXV1oHNcVviqOFeevKYUSh2iRslqbhg2klECRFGMvsrGkULvZkkbFWMZhlbppIj3EYgNOWhqDhPwQycFx2SVppAZMAptYxZKCItZgew19LCgP9mqjIKWkUNyIFoz+UvXc+dvZnbszs/O3d3bOMA/y7rlnzvnO53tnZr8500Ae309wQwQ4QOB7HMSAISACFAHkIvKAFwSQi7xUAuNwhYvXT91V9uogjp/dLlwV9rP9pKG6sa5YH5opTI5FeYjElfS4ctqgf+1y/aPzlcJ95levMr/KdH/93Dt55atPXonEZx4zlXO0Pz8VOhd+I0W2SbR/bG96MLNtaqCLRsDFY7eP9A0u1DwSF5PkxLUxF5mcA46yP3/x7tMvnoTc1lbX6La6Cn/864ub6myfee8+dvIwKZ5abu9M3wQu8rIhF72rhMNr9DrZIvc+Bfu9j/zs4eb9jzx1tHn/C0+/fF7ZqUGlLXNttqV3Ihku/b51bF5cta/OxIW1EqZPaR2XPyF0JZ1JT0ore9FAWejLnfSnJZ/b6UPC4dge8slmORhNGN7VKChHcpiLZAOmxH/q7Mu3/10Z2rnucGK6M12kHQEGpHvmEw3hA7B30yX70MxUb34oRj85cikyOiGfzDVFCn9sCJ9JkYMzUx3TRwSDIXKaMlvrhKQS1GFDeHg2dozlQTpEH+noEsONnxhYGlaFERR+eJmnKS7K1xPSXKIT35qwPCv79Ojvy/bv//D7maPfijvLz+Jgp0iyLJ0Fo7Gelty5kULRMtocIbnLGeGDhdS5bNOeveKXK9NXBDNq0DQwlaUxj7a3hh9nOKHcEi+SXpeoVuZh6dJZ4RA3Rz6cFd3fWl6MvZ5PtnpZm6AdyxQXxflA2XUwWv/vepGI59/uefUUc28/3qsH9EKqL73Sdfig1WLkXgoL8yLsiTmGE1jER4lgkxhfMneQhVQkfKCPvKmas80NRCvTCJjiomlvZG1jHSZG2KdTf+7p71XPkcrfq6uruclL8cs/KHcb75eXy9bnO5sWC1+Shez0Uruwzsrbwld50n40Lvwz2n86Js+RpQalQzRO9oZal5YXqAeYdzXJwSFaes8Ih2hLHlNNnDBNHm9Pr0QiZWe05uFBSz0EHOaiOC9Opy71HP8FWVvT7qtrhE1ECDLz1R5xbS2k4eQsMrJICCzZw/kEPYOUJ6S5bmEFp5/Q80LhBlDJRg2IPES4NNE4yXwwTnpzhez2WCjPmBfnuodyXcIhJsgNaY2Wb3zmEssl5wzILucQML6nU+lYzHs6bz91K9T8o57j6tmk6GCVPFyRiM6lhJ58ioABFy1k9X7nNzqjTs7vtuAThwQBAee5GATUMEc3EHD4fNGNENFnQBBALgak0D5IE7nogyIFJETkYkAK7YM0kYs+KFJAQkQuBqTQPkiTLy5aF4R7BLUi80a9t/OIu3V/0VNBuC1YqlLLKsYHUe9tC3XWYBe56J0g3BYqyEVb8Dk42Is1GkQGhhHbEoRT72bl32NJ6fEuQYwIRAQJo6B3pCqKSvpwRUDOyqNcRl7qxDBzNJAR8IKLptC2JQivQv49EL4mSL5zrYkT/eTzbpB2k5Vx0IFLSke1PpwpIC/LBnTmZTJyMFCc8PPgjqki1NbIXS6KWi/IUPmjUra2BOHVyL/Hxz+nMcCzNST0RFQbjlofzhSQlw7Rysjp97KT2tbWb0d3l4uiuBowUf6ohI8zgvDaoG8kI69NVP47qrtcNI+HLUG4Bfm3YWSGAnLRg2BWIiM39IwGFRDwgovi1Ki/2RKEW5F/K+HMXc4q1y7qGA0F5KKxVkZulCp+XwEBF+/pVMIcBeHIRiYCbnHRAtwoCLcAWj0N4YiL9QQr5mIBAS/OFy2EhUMCiAByMYBF5zRl5CKnhQlgWMjFABad05SRi5wWJoBhIRcDWHROU+aLi7XTdevotFHC7RF3OeIiNPrueO1vyg7/9AgDPAwfCPByr/u6nUbfDkCpo+6uSvjtQCiBdcHLvGhP1y0so3Gpjzc0tG1LQu9uKp0sdpJldPkutv5W9eVW9wPn5L0eQSEnL1y01+gbqtU0cIr0QatZoXXiBIHe3Yp4GzrOM7t8Fz8s9uWmllqddlDYUNs8eeGiLV03hXBlfFB4GQcVbMuyakW8zezyDR9q+3Kzddq1rVFQjs4LF3nSdaNOuzbs54WLtnTdhtAxRdrMvtyo0zYE0zUDXrhoT9dtCA9TpM3qy406bUMsXTPg5Z4ONvp2rcS+ccwLFwEw1HX7hjXuBMoRF91JEL36BgFezhd9AxgG6hoCyEXXoEXHVSKAXKwSMDR3DQHkomvQouMqEUAuVgkYmruGAHLRNWjRcZUI8HVPB3TdSvzPXLyvylzQ3N8IcMRFEHI/905egfOTVyLxmccsoYvqV0uw1XoQL1x0VNeNXKw1rSwdnxcuzr/4n46X39VJ4caF33a+91AFA9ojeaCFfjk7NExGoQW3sGWHaedjUHRP9UJvbuHbWHcG+hZTspIs6YotvxR+IxVNyAagFtO+HN0SrjioegS4uXax0687fmJgaVhsfdudmSttwc1UdANO6r7cKOSunjgujOCFi7Z03beWF2OvFx9tUcPEVHRTA3VfbqEXKDwfM9reGn7cBZDRpSkEeOGiLV33QioSPtBH3gQ+wYNXpvIuMUIhd/WYuTCCFy7a13XfHDnenl6JRMIlKBm23UYhtwussuaSFy7a0nXHpdcH5RLL50YK0ENb1YLbsO02Nty2xhznR/FyHY26budr6zePvHARcENdt9/I43C8HHHR4czQnd8Q4OV80W+4YbzOI4BcdB5T9GgNAeSiNdxwlPMIIBedxxQ9WkMAuWgNNxzlPALIRecxRY/WEOCLi47166adPyfHohZ+m7YGI45yAAG37i9e/+h8peiY70kFY+d03Q7ggi68R8BFLjI5Bxxlf17jft3eI49HLEfAizUapFyGwNvo1w2ibpVUDHQS8/1tVLktr9HFTt20/3Z/WjEutUkfMgwSDVxFwAsumkrAuq57cfBiruvwQfEo/YfbZy9Cs2RlK++/nfpMNo7viyyRnmepxqzt2Q5S+NJUnGjkGgLuclF8mQAEr/xRKRFbum7oyx3bB3MePMhytOXS2YzqINr+2yACb2lugwnycGj64g3SGWsjrc93kukrIDbDrZYIuMtF8RkUyE/5o1KutnTdZO5sOnQ6GW5LHovMZ2kH+ZKtVLa9kJ0mHc9HDx5tufFxBv4ORaOxHnLj44ValgGPDQi4y0XzENvUdd+8AjPciTOdopZWtTFk24sfz5OeMZG18Hfo6ECIMBhsPna0dAYBL7goTo36my1dN7ims11719K1VPmkyJBtU+K2SIsy/B2JhXCBNqqPF9+7eE+nUvjMezqo6/ai2nwfwy0uWsgadd0WQKunIRxxsZ5gxVwsIODF+aKFsHBIABFALgaw6JymjFzktDABDIuL88V3XnuhcefOxsbGXbt2VarB1tbW2sbWyT+kAlikgKTMBRcvDv36oQcf3HX//Qf279PB/dNP/3ryrfcDUpgApsnFGr25tdnYeM/du8UGycxK7GzcGcAKBSdlLrh4d33z6398s7W1+Z3uBgYVCyO31NkuUGEYB/VTCdKY0aDyXAMLF1xMXrg8OJ7Z3Ng02DYqcBHqOkpeCseoAuPI8hNxDqhoGALt03d8cKFMxmE4rJ4NuOCiCPCmCTKyS7E31Lq0LOlsFlKDtAsybv5DgCMubmxsbOruYMAGGPSLLb0TydLOi4TqvUXdpNQgtCjwLpF2z6QnpZW9VAEuHKvcCcjCRZ/bkg6crsVaD/lksxyqJgzpC2URr2TgPzLZjJgjLsICvb6xobODQYVsoUd3YrozrepLS7vJ98wn5CbeQr/4qd78kLiOX4qMTshPCeo07tY6IakEVWQ2hIdnY8dYHqRD9JEOqX99SS9x1oRtaGCzwv4ZzhEXBRqu6+4V5kUK9+Jgp0iyLJ0FQR7bkivRMlpo3K11AseRLpLkVyXQQ6tafy9JqvKbIx/OiiTQ6SVu0sA/ZLIZKU9c3NSbFIGosIQbZLuQ6kuvKM++VA+NUePu4kVSYnzJnHvDXuKGBuaOUwdWHHERThb150UwYCMe75eXS3hypWkRnqICae1SOzx1ULS30Lhb60S5SKJTpiYWOERL7xnhKh6edpDWaMFK1Uucfa+H3Wy8DvhVTQoccRFu6eifL4IBO7XMV3vEl2IU0vCil8jIorBkD+cT9AxSPom00Lhb4yTzwTjpzRWy22OhPGNenOseynWN0kgmyA1pjS7vJa7JwNCgmnL62paL3wBFBAd//pM7d+6EQiF9QO98++2fPvvC16ALwcMEue8yvmZLVUiOuPi77id3P7p79+5H29radKj27oUL56/83fdchOnw1HJ7JzzKjXdDpWJyxMXfHPoxTIo77tkZffJJHap9+kkmPX/Lx1yU3k+4Mn6kD393UdeRIy7+8qeP/O+7zQceeHDHjh06VIMfrf9y3eRFrI8ZG8DQOeJiANHHlNUIcHQdjYUJOAJczIuo6w44C8X0ueAi6rqRi4AAF2s06rqRi7xwMUi6brjFLavOLL7tWuGt8nOikYaczXQTo7wVn3MxLwZM1w13FhXp2lt8PBFRYV72VnzOBRdFJAKn66ZyjdATUVyfJQQ44mLAdN0ghdzXlf1Q+OlFvVyWrrxJ6TXt+WSrVDFZfK6SjqvYzJCml3KdObziKE/F5xxxMTC67qYBUVUEz4slPtedFZsGwteojHwo15o4ITaBVtTpRel40UV5c3KNc+Zww1Hw3+YECKBUInlX5nKOuBgYXbdyvrh8uqA86sCs7sr4uEBWeKBHXM1Bna6VjitDtc3Jy7wyhxuOAieG6nQnyMkTF4Om66Za3aY9e50oY9GHkTSdfTSjUZ6IzzniYjB03epzOxCHr9ymkqMvbyukhJNIHXJWlo7TQYzm5KW+mMMZo2ojPueIi4HRdcvni1Md05JsTHhFjSAI3z5MJEE4m5Es6XjRktGcvNQNc7jhKOWJs6u5hKY7v3PTOhe/AYrpBEzX7VwNXfTkqficIy4GS9ftIoEU18Ak9bOzcFL4huY9D7pxeCs+54iLQdF1e8FC28eohficIy6irts2g/ztgCMu+htIjN42AhxdR9vOBR34GwEu5kXUdfubRA5FzwUXUdftUDX97YaLNRp13f4mkUPRc8FF1HVbqmY1um5vFdqW0uHjeRfUdVsrXhWjvFVoVxGYypSLeVGMB3Xd1kpYN6M44iLqugVWuaTr9lShbe2/B0dcRF23poSO67o9Umj7nouo69aU0GldNxzAE4W2/7mIum5rNSwZxYVC21oePK3RgejXrSoTbfrttq67Ngpt33MRdd3u67o9Umhb4yIXvwGKoaOu21oJzY3yVKFtLqRyK464iLpuayU0NcpbhbapkDRGHHERdd3WSmgwqhYKbWuJcMRF1HVbK2HdjOKIi3WDKSZiDQGO7ulYSwBH1Q0CyMW6KaXvE0Eu+r6EdZMAcrFuSun7RFzh4vVTd5XdPEL96av0NeTSVvrjFdweSx8S9FTFZtdCe0zhE/pVydaWnNwuTMov8jUfAlrWEoH/A1PM6+usYO6dAAAAAElFTkSuQmCC">
 *
 * 
 * 
 * #The Module Class
 * The module class will be an ExtJS class that extends from 
 * AppShell.core.Module. You can look at the API documentation for that class 
 * for more information about the specific configuration that is allowed. The 
 * most important is configuring the required security privileges and 
 * configuring the workspaces that are exposed in this module.
 * 
 * Workspaces can be defined inline or by referencing the workspace classes 
 * that you define. In both cases, you will use the wsCfgs config option for 
 * the Module.
 * 
 * We currently do not have a formal concept of inter-module dependencies. 
 * However, it may be a good practice to put a "requires" config in your module 
 * that specifies the module classes of any modules you depend on. Currently, 
 * the plan is to package modules as single JS files that will be loaded. By 
 * putting this requires statement in your module, you can ensure that the 
 * required module is loaded before your module is instantiated.
 * 
 * An example of a simple module class definition is as follows. It shows an 
 * inline workspace configuration, and then one defined in a separate .js file.

        Ext.define("Scorecards.Scorecards", {
            extend : "AppShell.core.Module",
        
            requires : ["Scorecards.view.scview", "Organizations.controller.OrgTreeController", "Scorecards.controller.SingleKPITrend", "Scorecards.ScorecardsBundle", "Scorecards.TestWorkspace"],
        
            licenses : "Scorecards",
        
            wsCfgs : [{
                id : "sc_SingleKPITrend",
                navPath : ["Performance Management", "Scorecards", "SingleKPITrend"],
                widgetCfg : {
                    main : "Scorecards.controller.SingleKPITrend"
                }
            }, "Scorecards.TestWorkspace"]
        });
 * 
 * #Deploying your Module
 * Currently the process to build and deploy your module is still not 
 * complete, so in order to deploy, you will first need to copy the 
 * AppShell files to a folder on your web server. You can then copy your 
 * module's folder into the deployment directory as a sibling of the AppShell's 
 * index.html.
 * 
 * At this time, you will need to manually modify the modules store to load up 
 * your module by default. This file is located at: \AppShell\store\Modules.js. 
 * Eventually, this will be hooked up to the server to only load modules for 
 * which the user has licenses.
 * 
 * #Video Introduction to Modules
 * 
 * For more information, you may watch a video screencast that gives an 
 * introduction to modules. It is located here:
 * 
 * <a href="\\vm-buildui1\videos\Training Videos\02 - Intro To AppShell - Modules.avi">\\\\vm-buildui1\videos\Training Videos\02 - Intro To AppShell - Modules.avi</a>
 */
Ext.define("AppShell.core.Module", {
    mixins : {
        securable : "AppShell.security.Securable",
        loggable : "AppShell.core.Loggable"
    },

    constructor : function(config) {
        this.initConfig(config);
        this.mixins.loggable.constructor.apply(this, arguments);
        this.mixins.securable.constructor.apply(this, arguments);
        this.callParent(arguments);
    },

    /**
     * @cfg {Object[]} wsCfgs
     * An array of (workspace config objects or String workspace type)
     *
     * For example:
     *      wsCfgs: [
     *          {
     *              id: "FnS",
     *              navPath: ["WFM", "Forcasting & Scheduling"],
     *              widgetCfg: {
     *                  main: "WFM.wdigets.fnsWidget"
     *              }
     *          }
     *      ]
     */
    config : {
        wsCfgs : undefined,
        /**
         *@cfg {String} i18nService
         * Specifies the default web service url to use for loading localized resources from the server.
         * This service will be used for all bundles that match the module's namespace.
         * 
         * For example, in the Foundation.Foundation module, any bundle identifier starting with 'Foundation.'
         * will use the service configured in this module.
         * 
         * ##i18nService Config Options
         * 
         *      - url: the url to load values from in production
         *      - mockUrl: (optional) the url to load values from in development. Usually a .json file that contains all of your bundles
         *      - preloadBundles: (optional) An array of string bundle names to preload on startup
         *      - namespace: (optional) The namespace to bind to this service. By default, it will use the Module's name
         * 
         * ##Examples:
         * 
         *      i18nService: "../wfo/rest-api/bundle"
         * 
         * or
         * 
         *      i18nService: {
         *          url: "../wfo/rest-api/bundle",
         *          mockUrl: "MyModule/data/ResourceBundles.json",
         *          preloadBundles: ['com.company.i18n.MyBundle', 'com.company.i18n.SomeOtherBundle'],
         *          namespace: "com.company.i18n"
         *      }
         * 
         */
        i18nService: undefined
    },
    
    /**
     * Executes any initialization logic that the module will need.
     * @template 
     */
    init: Ext.emptyFn
    
});


/**
 * This is the superclass for all widget objects
 *
 * #What is a Widget?
 *
 * A widget represents a specific part of the UI. It can be a Organization
 * Selector, a Date Range filter, a portlet, or the main view on a page. It
 * consists of all of the MVC files required to show the widget on the screen.
 * In addition, there is an instance of the AppShell.core.Widget class that
 * contains metadata about the widget. This widget instance may be defined in
 * a class file that the developer creates, or it may be an inline definition
 * inside of a AppShell.core.Workspace class, as part of its wsCfg config
 * property.
 *
 * #Lifecycle Methods
 * The AppShell.core.Widget class provides 4 different lifecycle template
 * methods that you can use to execute some logic at different times.
 *
 * 1. onCreate allows you to execute some logic when the widget is
 * instantiated. This is currently called from the constructor of
 * AppShell.core.Widget, so it is mostly useful for inline widget
 * definitions or when you instantiate an AppShell.core.Widget
 * instance directly (not a subclass). If you are subclassing the
 * widget, you can better control when your initialization logic
 * executes by implementing a constructor function.
 * 2. onDestroy is called when the widget is to be destroyed. This is
 * typically called from the containing workspace after a different
 * workspace has been shown.
 * 3. onShow is called when the user navigates to a workspace containing
 * the widget. It is called after the view has been placed on the screen.
 * 4. onHide is called when the user navigates to a workspace other than
 * the container workspace.
 *
 * You may think that onCreate does the same thing as onShow, for example, but
 * that is not the case. The WorkspaceManager will determine how many
 * workspaces to have in memory at any given time. It may keep the last 5
 * workspaces around to speed up workspace switching, or it may only keep one.
 * This means that a workspace change will not necessarily cause the workspace
 * to be destroyed, but it will be hidden.
 *
 * #Titles
 * When widgets are rendered in a workspace, they will be rendered in a wrapper that contains
 * a title bar. Widget titles in this wrappercan be set and updated by using the title config and the 
 * setTitle method.
 * 
 * Likewise widget titles (when used in worksapces) can contain other components for displaying information
 * These components are configured using the titleComponents config and setTitleComponents method.
 * Please note that at some point in the future, widgets may be stackable into a tab panel. If this is the case,
 * the titleComponents may not appear.
 * 
 * ## Title Example
          {
              bundleName: "MyModule.MyBundle",
               i18nCfg: {
                   title: "MyTitleKey"
               },
               titleComponents: [
                    {
                        xtype: 'box',
                        html: 'Some Additional Component'
                    }
               ]
          }
 * 
 * #Context Handlers
 *
 * Your widget may need information that is provided by another widget. To
 * facilitate this, the framework has the concept of Contexts, which will
 * encapsulate a portion of state about the view, independent of the view
 * implementation. Each context will be  identified by a unique string.
 *
 * For example, the current selected organization could be represented by a
 * Ext.selection.Model, with a unique id of "selectedOrg".
 *
 * Context objects can be of any type, but they are generally Ext.util.Observable.
 *
 * The AppShell.ContextManager class is the place where you can get an existing
 * context object or register to be notified when one is made available.
 *
 * Instead of manually registering listeners to the ContextManager and the
 * context you are interested in, your widget controller can declaratively
 * register an event handler, as shown below.
 *
 * <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVkAAABwCAIAAAA7RJTGAAAAAXNSR0IArs4c6QAAEThJREFUeF7tXT1s20gWpq7M1ikSL3JbSCkMd0HuALnYWl4gMA5YVzbSSQhwgNQkReLS2yQNBRyysDrDna9xAkRq9woLuE3SeV1EKnLBJgE29abVvfkhOaSG1JDSSBrpI1zY9JuZN988Ps48zjevNBqNPFxAAAisPQJ/WXsEAAAQAAIMAfgC2AEQAALwBbABIAAEAgQwL4AtAAEggHlBYRsYtrdLjR4v3muUxCX/LlznFAWlDgvUYArlUXRJEFjmeYHywBVBa6w4PTHb7aGsasrKI4Vqx/QpZuBXi6g4mzLD9lGn3iUtjmuzqRC1rCUCy+wL1nJACnR6cNWvblYKFEQRIKAgYNcXhPPnaAbN3seJSTVJNdrBbfHm5lKVVt/r7Ajh4IU+Xpy3EcyO2R8kmlpcN/aKkmo9SZVY0bB1plrmpekmW01ElYZNKZLRrCVYe2DWj6d1fgjQ1NLS1a17Hp+6RhebSlf9Ab8R/c4EpWSsDJOIV0D/Dm/Q70FVQSnllmwgVpy3o14J7bhK4p5WJUW5pGqJv/V6svKKymFLSTUEXooKEwZIbc3SWKLaNUDA3rygd96p+g9jK9jhq7N+/bBZ5s9juXlY718NxLNZ74q1bmUza909fHcZThRKO53wsa4dD/xLmkDseN0LWXuKMw0exdgKP5wYxN72YyppOpTSSpqe1M+g9xRlCHvM5j7jEwAeh5gUAeCqn+9OlJvfuwUtOYuAPV9gARK2MJazCu6mYw9+tVosfNdr7FwqU5VZqJ2pZ6KBcvOCdWX3vNCnCOYwBptHi/yGMQvAUMcyIGDPF9Arvt96Jr67yav8w161cyRD+Sz6nR3yKt/e8i7fBYF/qqO2W09WyWvuNSpneycXJzQ5UJbcY8W1eLN3uLx6zzKjAKxDZ69ENON+pmSanhkDTg81rTM65xFesThIlqmY9XMZjA06LDUC9nwBvfDEzF35+k73ulutCr9Dj+9gwoy+9tD3pLR4xoPFgBpPpGeGXuwntDYoN0+YfOgOxorrRoIvVUQjR5t+MqIQ82Sieqb61WEYexChvyjMySf7Oj31ZqBEDiutLblSWmqLgXKrikAJPEXnh5a84dHmJL/qfC/RAdsI2JsX2NYc9QcIsMVLEIQFKkCgKALwBUWRW55ybG3EF2PYjbA8g+KgJlgjODhoUBkIWEAA8wILoKJKIOAgAvAFDg4aVAYCFhBwzBcMX26XDmhZ3GsclLZfKlsPzKDp/VwqHbCfxluzAtNLfW5vM4VncE3Z9wwNQHmewfC4X4VjvqC8scUxr2zeKoJ97cFodDrwC5Xl7Q3bT6bwI8wvFHdGU/Y9FS9QnouY0gqWccwXsBG4Jfm5WxuC2ODK1Ws8am21yBmNRk/9S3+7/Tm/5jb6Dspz/nFYzRKrwL/65Ff3PY//VF8IFuRopNysv4mTJR97sTspkt3nsk5vnzEJBy+qoongp+p/Sm9IqTMq/jxibVLlQlX6pf4i1D+gLL6pq21FnTIfrVw0xxjLw7wNSK4UAt4K9IY9TrGnnTN++QMs2b/7wXPL/h74MV+gl2SOQHl0A5QSZdMaojoDlZhTYJqED7+oinkWXj9r6LHkRgUdoeKBwuQUgv/mG6lcvkDPms7XIKRdR8DBNcLY/KyyUe34pdLPSoTuM2c3y8W5wm4en9vpJXvnxIjcNTgyTFv87Xnnlv/wjulEsv4PSbSmcMaxcakJtYPybAo/5CQCq+ALyvcu2CL8b+fsG4HwCJ+u+rf8Ad2UPxfNGylDbi6prcC4ODms/kd5WgPVNPjYr26knUtW2yWK5yMeZaTAwj+zj2SYxpRBeZ4GvVUruwq+QI7JnWOKyVX7nPZ7Z7f+ofXM5MOhXpK+U/RbCoE4GPby7W+9y4/Kt0xt8Zub1Q9nr1hocNj+l2Q3l+/uVftHMl74uX3Ur+7dTYl90n9/Dx1ZuhfLNkVQnlftUbXfH9cXOWL9H0baosCBGr2TS+6YJBWRwhpJGVYIqlXW05GwJnYYru3DQGP9jRKPiCKCUfxCF+zgQYQoSFloNZ8rXoDYofuPwfQ9AB/BvrvN28LbRsn3uqfyfDPaH3W0Mbi4Z+0DKijPeQdoReVXaI2wmiNEUUzP7k4KUJ5X03Jy9wrzgtyQ2S9AuxsrrQ+yneqPNicFvBE6XIkdzERrkUlnrdrvO1pYGALwBQuDHg0DgaVCAGuEpRoOKAMEFoYAfMHCoEfDQGCpEIAv8KbkAtviQXNS4+y41cTyng11eqL5TolnRv29xn9KJf7T+DJRjeICvStqYrv9tXgNPPt2cB43S503Tlo3Ts+tL642YKKnCS0dvsCbkgu8YB60iSHMV2ZKPNOUHbZf73Su+YPvR6PvR8fXZ9Gnr+1tK26FHdPfCVNk6TWdNj03z8ERnf+fDYcZLR2+gKNogws8pbXeaF6czo6eMKUyeYtbwHNwRS/qb25b22YRdbG2Se7monktb6elPCXi6oRJAQvWYVCM5eCgrer3ZeqhzBJmtHT4AtqwfDz6iada+Ul59pRzR6IDlMwPI0mRDBcU/HQmsTxhnw8Zt4oxqeShBvp1h6ZONvNvs0pYcfWgp0RD0lJoF1NcUhEL1yMpdQZlYzVou6nFM81WjfdKJysY/m87nMnzWT0HlN1sNNif8aUEnwKIm6XX9Pjw5cZrtj+8I4TZTc+LxGJrBF6/+JH3Uxtir2CNJwiWBLFU2mOY6FJ+cyFtcZbmx5OpvAycx2SR6bcurmQNC+VBS1pzjFvN9j6ru57F74wcLbnVbIOz3K2sI1zrJaOxC7jVKXVqadQZxHBjozDYKz3wf/W8X5SfXxnHe/C+6v1S9f9kLXV/o//yQybYTc/7jf3KSnHJ0Z9+Vd6Mq8Xv1/9I6qrWzDajmzckU/aOJQcP0oirecYFfT6ZSTwix2em/A7E1NTdGZCbZeLGvEDvLhfJg9ZpNHx91q8eSrbljeYhZUf5JOTq3QecW02EqGCSmkK4Hpf0vPBt/0jNEKmTHNfKnBie8Uoy4FaXm3dp0s6dxvUuBQtGdycl0/6OECnf/obe8yyHzPDLWZ+S3bObBa7hqz/63vVDsWSoXSctLt/JsKKoM2qIBGg27o1nCQ1ydrOEoplpbQxTfofdYHnJs/Pk5MjEDV+gN49F8qALGGzBIr0GcaKfymPXMtNU62jUxnztgtqtXTELKb8ptadxJm74gkyLWwgPWqfROOV582aa5mmE6zF59mIP5xKZmaO1NGpzYngGxoXjBVGdX9tHmZ8Yy9f36O3Zeq8/jfrya/Zx2vy1/+WIf2Ictt93vGt7P6SHFbNf1CyTdz31iBzzlN9h3/XTkCTchpm44Qu0dsrOOxZBshI7sFRs068dszNLg/tPRABXSEbxP74jQCtJscmB//uOrFb52l/b9b1/V5TYoa5O+qxAiogDTh6d7T3NONcgtaFkV/laQ9R5tJGZY5okv21VgkOcReAzpZvzepuX/8oiZ63XFPa72vsuc1JzrXmxWfe+7CixQ67ltebhda//vhLFDr806PfKewop8pp5PLK2OfCviT8rra/1buYKha0CvE7y5IuOTDdOCcEHwpZ06bnNU35HHrzjVfd+mNW3FeMgDwTXGAElMCnOaCxyHOua4GcQDZ0NEizyyAhlky9SyeCICswL5vUeW5127NOoncaqdkyPXmcn++vh9D3sNYhbGgQlJ1RnRksHT3H6UVmHGuZNo3YcU8YCP9sbXNg7qjLnCTQmtHT4AsetDuoDgRkhgDXCjIBENUDAcQTgCxwfQKgPBGaEAHzBjIBcUDXG1Fe9flMWDytVibX2OMsLw3hedG/WQUbxiOXa1ONJAYBZRyfhCxZkYDNqdkrq65TFRSfILHe8bnhUYgpnmaKPAR0rynBlflOHlzlVLA/aCl+rUP7bPG2ZyOrxpM0IW63KTI+kgC8wGQ7IpCMwbN9vbUWeQAhqOMuDq/A01yhhlPnNcQVmkbc6WSvb5UV+bXK6LXsWceP2lrd1O5HmS8cBZ98uO0cmlGVTZSdvVIBEIQT4lhNxBftB+OaQ+C3GIPOD29F+EEVSezO+w2SM7qZpKKMPZsWV/lAXQq1MtrGMpahm6WS7ybzVqTeDzNmxLoTJacXd2eStjsiaalucjhnkuQk3Wan5bIIMPUzSD/oVbcfSZs1OzQOusj8nWJ6G5/jm+f7+/vNkqmEjC16FPMtGHZ2vEHtwEjvCVL5q9LuySU0po+GY6ouLXiVMQi1t9KjGmLOpegaPf6xKk/q5jmT6PHtVjAxufnNs+GzkrWb+RZPVes507xy+QEN6nsIXYI1gOoHKI9c771T9hzGO7PDVWT889orvPGd0WjFrEEttRmuRF/3KtrArq8H04mN6MYpLsAGeztrKozfJ5mhI1rxldNYQkRq/JcHhu9+rEavK/GaeXljIW72UdG/CZJx1dOfB6enpg0LZuuEL8ljZvGTLzQv2Itw9L9GVNz7EDrTiR3jIayab38TxekydEhFsTnLtp+NUK7/j9YmXRSQuxobaftkzvqmnEdrIW82idB8CFz1hrO3RvWvHQfq8eZmbbAe+wAbgbP9361mMI8sIbGGkhx2ENX7ixZgmFOWnGTtnveUozh/beONBzQYEYX1DpDBR7PTO5fJdNumXHx43+LFKCaBGp3z9cjq6uFczvqln4VnJW33noX+rsxN95ki3DXt077FvilkGyuaA8XnZ258PDg6evGRJvvNe8AV5ETORp/f6wL+URFX5Zqd7XfoKxF+tE/aqC0KrkAxi9PriOuorMabVxpWv0ApBXvRCz5zV6Cm+YAVKKXMV5njOXk1wBtTS4GOfZYWkRygIiee6qQHdnMStJ1xrx5HcVrfO5i+x4ye1rS8D3Zsv6OLnIdzcuOV5Hz7KQ69MjDWSmW9MDa25iUA8FhoLGKaf2bcsXV0s4dpi69rA7acXj/cfv2CHYea9MC/I5zohTYfynneUiWm5eUJToLxBjYXhuFjC9SxbZ2evx5MwfH755ODg0X///vSne4n9CUZwg6doBNPaC0nOq8CBQpOJgCQFIs53lzZL82IJ13Zat4A4fMHaP+YAAAhwBLBGgCEAASAAXwAbAAJAIEAA8wL5YS33lh7YEBBYLQQQLxDjmfP4uNUyAvQGCCBeENoA2zNjuPsUdgMEVhIBrBFWcljRKSCQGwH4ggiyiRvrc6OLAkDAHQTgC+RYEQ/oxLtfKs36EDl3TAGarjkC8AXSACh4eN87GY1mwvBdc6NC951EAL4gGjazQzmcHGYoDQQmIgBfMBEiCACBtUAAvmAthhmdBAITEYAvEBCxEwo3KxPhggAQWFkE4AvEHuQkFXxlBxwdAwIpCGAPMkwDCAABhgDmBbADIAAE4AtgA0AACAQIODYvkCcEO3O6HgwNCDiDgIvxAvCLnTEvKOoQAo7NCziy4Bc7ZGBQ1RkEXPQFzoALRYGAQwi46gvAL3bIyKCqEwg46QvAL3bCtqCkWwg46QvAL3bLyKCtEwg46QsIWfCLnTAvKOkQAq76AocghqpAwAkE4AucGCYoCQSsI+CiLwC/2LpZoIE1RMAxXwB+8RraKLo8HwRc3IM8H2TQChBYLwQcmxes1+Cgt0BgjgjAF8wRbDQFBJYYAYu+APziJR53qAYEkgjYjheAXwybAwJuIGBxXsABAL/YDTuAlkDAti8AwkAACLiBwDx8AfjFbtgCtFxvBKz7AvCL19vA0HtnELDuC8AvdsYWoOh6I2DdFxC84Bevt42h924gMA9f4AYS0BIIrDcC8AXrPf7oPRAIELDtC8Avhq0BATcQsOgLwC92wwSgJRDgCNjegwyYgQAQcAMBi/MCNwCAlkAACHAE4AtgCEAACMAXwAaAABCY13cEIA0EgIAbCPwfPY4wsjAH83wAAAAASUVORK5CYII=">
 *
 * You can see that the first level of property in the config object is the
 * name of the Context you wish to observe. In the second level are events that
 * the particular context will publish.
 *
 * Since the context space is global, if you wish to publish your own contexts,
 * make sure to prefix the name with something that is unique to your model.
 * For example, if you were in a Scorecards module, you may have a context called
 * "sc_selectedKpi".
 *
 * #Controllers
 * You can load controllers in your widget by specifying them in the
 * controllers config of the widget. This gives you an opportunity to utilize
 * the component query mechansim for identifying different views in the page.
 * You must be careful when using the component query syntax inside of your
 * controllers, though. Remember that controllers are around forever and you do
 * not know what will be loaded into memory at any given time. There could even
 * be multiple instances of your widget in memory, so try to scope your queries
 * to be very focused, and consider that before using the ref system.
 *
 * #Integration with the Workspace Manager via the getView Method
 * The workspace manager is a portion of the AppShell which will ultimately be
 * responsible for loading workspaces and placing widgets on the screen. When
 * the WorkspaceMangaer must place a widget, it will call the getView method on
 * the Widget to determine which view it should place on the screen.
 *
 * If the developer does not override this method, it will have the following
 * behavior. First it will check to see fi the widget has a view property. If
 * so, it is returned. If the view property is undefined, the Widget class will
 * attempt to instantiate a view based on the viewCfg config property.
 *
 * Additionally, when a widget is placed on a workspace, the workspace property
 * will be set to that workspace.
 *
 * #Video Tutorial
 *
 * For more information, see the video tutorial on widgets:
 * <a href="\\vm-buildui1\videos\Training Videos\04 - Intro to AppShell - Widgets.avi">\\\\vm-buildui1\videos\Training Videos\04 - Intro to AppShell - Widgets.avi</a>
 */
Ext.define("AppShell.core.Widget", {
    mixins : {
        identifiable : "AppShell.core.Identifiable",
        securable : "AppShell.security.Securable",
        observable : "Ext.util.Observable",
        loggable : "AppShell.core.Loggable",
        localizable : "AppShell.i18n.Localizable"
    },
    requires : ["AppShell.util.AppShellUtils", "AppShell.ContextManager"],

    statics : {
        controllers : Ext.create("AppShell.util.ObjectBank", {
            listeners : {
                add : function(map, id, controller) {
                    if (controller) {
                        controller.init();
                        controller.onLaunch(AppShell.app);
                    }
                }
            }
        })
    },

// If we define the event here, all instances of the widget will share the same Ext.util.Event instance,
// which means that the listener lists will be combined. Not good. Instead use addEvents in the constructor
// to create different Event instances to keep the listener lists separate.
//    events : ["titlechange"],

    config : {
        /**
         *
         * @cfg {String} id
         * Identifier of this widget instance. If not configured, one will be created.
         * This can be used for tracking state if the widget happens to be stateful
         */
        id : undefined,

        /**
         * @cfg {Object} contextHandlers
         * A config object containing other config objects, keyed by {String} context id.
         * The value config objects have keys of event names and values of {Function} handlers.
         *
         * For example,
         *
         *      contextHandlers: {
         *          "selectedOrg" : {
         *              "orgChange" : function(event, newOrgId) {
         *                  this.logger.info("Organization changed to " + newOrgId);
         *              }
         *          }
         *      }
         *
         * This configuration will also generate an accessor for the selectedOrg context. The
         * method will be called *getSelectedOrgContext*.
         */
        contextHandlers : {},

        /**
         *
         * @cfg {String}
         * The displayed name of this widget. 
         */
        title : undefined,

        /**
         *@cfg
         * @private
         * @deprecated 
         */
        titleCfg : undefined,
        /**
         *
         * @cfg {Array}
         * list of items on the title
         * this config array specifies the additional items you want to add in the title.
         *
         * For example,
         *
         *          titleComponents: [{
         *              xtype: 'lable',
         *              text: 'label text'
         *          }, {
         *              xtype: 'button',
         *              text: 'action button',
         *              handler: function() {
         *                  //handle button click
         *              }
         *          },
         *          '-', //separator
         *          {
         *              xtype: 'button',
         *              text: 'another button
         *          }]
         */
        titleComponents: undefined,

        /**
         *
         * @cfg {Boolean}
         * Hide the title of this widget
         */
        hideTitle : false,

        /**
         * @cfg {Object} viewCfg
         * A config object that represents the view of this widget
         */
        viewCfg : {
            xtype : "panel",
            title : this.title || Ext.getClassName(this),
            html : "Content goes here. Implement by specifying a viewCfg in your Widget controller."
        },

        /**
         * @cfg {Array(String)} controllers
         * Controllers to be loaded automatically when this class is instatiated.
         *
         * In general, you may want to use controllers sparingly. While the component
         * query syntax can make it easy to wireup logic to your views, it is also easy
         * to wire up your logic to other people's views. Make sure your component queries
         * use something unique to your page.
         *
         * Note that the controllers loaded via this config will be in memory, listening to
         * the event bus forever after they are instantiated.
         */
        controllers : [],

        /**
         * @deprecated
         * @cfg {Array(String)} requiresCss
         * An array of CSS files to load for the widget.
         * The path of the files must be relative to the index.html file.
         * Please note that this is NOT the preferred way of loading CSS. Instead a concatenated css should be loaded in your module
         */
        requiresCss : [],
        
        /**
         * @cfg Object
         * This config will contain metadata to specify how a widget is layed out in the workspace.
         * The properties that are supported are defined by the type of the view that is used for
         * the particular area.
         *  
         * Here are the properties that are currently supported for teh default AppShell.view.RowView:
         * 
         *      - minHeight
         * 
         * This config is not usually specified by the widget author. Instead, it is usually specified by the workspace author as a way to 
         * influence the layout 
         */
        layoutHints: undefined
        
    },

    idPrefix : "appwidget_",

    /**
     *@property
     */
    isWidget : true,

    constructor : function(config) {
        this.mixins.observable.constructor.apply(this, arguments);
        this.addEvents(["titlechange"]);
        this.initConfig(config);
        this.mixins.identifiable.constructor.apply(this, arguments);
        this.mixins.loggable.constructor.apply(this, arguments);
        this.callParent(arguments);
        this.mixins.securable.constructor.apply(this, arguments);
        this.mixins.localizable.constructor.apply(this, arguments);
        AppShell.ContextManager.processContextHandlers(this);

        // Process controllers
        this.controllerInstances = [];
        var controllersArr = Ext.toArray(this.controllers);
        Ext.each(controllersArr, function(controllerStr) {
            if (controllerStr.indexOf(".") === -1) {
                var widgetClassName = Ext.getClassName(this);
                var indexOfDot = widgetClassName.indexOf(".");
                if (indexOfDot !== -1) {
                    controllerStr = widgetClassName.substring(0, indexOfDot) + ".controller." + controllerStr;
                }
            }
            var cfg = {
                application : AppShell.app,
                id : controllerStr,
                widget : this
            };
            this.controllerInstances.push(AppShell.core.Widget.controllers.getObject(controllerStr, cfg));
        }, this);

        // Load CSS
        if (Ext.isArray(this.requiresCss) && this.requiresCss.length > 0) {
            this.logger.warn("Requiring a separate css file for your widget is not the recommended approach. Please requireCss a concatenated css in your module.");
        }
        Ext.each(this.requiresCss, function(cssFile) {
            AppShell.loadCss(cssFile);
        }, this);

        this.onCreate();
    },

    getControllerInstances : function() {
        return this.controllerInstances;
    },

    updateTitle : function(title) {
        //console.log('title changed', title, this.getView().title);
        this.fireEvent('titlechange', this, title);
    },
    
    applyTitleCfg: function(cfg) {
        this.setTitleComponents(cfg);
    },
    
    updateTitleComponents: function(titleComponents) {
        this.fireEvent('titlecomponentschange', this, titleComponents);
    },

    /**
     * Returns the current view used by this widget.
     * The default implementation will instantiate a view based on the viewCfg and use that.
     */
    getView : function() {
        if (this.isComponent && !this.view) {
            this.view = this
        }
        if (!this.view) {
            var newView = null;
            var id = this.id;
            var stateId = this.id + '/view';
            if (this.viewCfg) {
                // If it is a fully qualified view Type
                if ( typeof (this.viewCfg) === "string" && this.viewCfg.indexOf(".") > -1) {
                    newView = Ext.create(this.viewCfg, {
                        id : id,
                        stateId : stateId
                    });
                } else {
                    // It is an xtype string or a config object
                    try {
                        if (Ext.isObject(this.viewCfg)) {
                            var cfg = {
                                id : id,
                                stateId : stateId
                            };
                            Ext.apply(cfg, this.viewCfg);
                            newView = Ext.widget(cfg);
                        } else {
                            newView = Ext.widget(this.viewCfg, {
                                id : id,
                                stateId : stateId
                            });
                        }
                    } catch (e) {
                        this.logger.error(e);
                    }
                }
                if (newView) {
                    newView.widget = this;
                    this.setView(newView);
                }
            } else {
                this.logger.error("A view configuration is required for: " + Ext.getClassName(this));
            }
        }
        return this.view;
    },

    /**
     * @param {Ext.Component} view
     * @protected
     */
    setView : function(view) {
        this.view = view;
        if (this.view && !this.view.widget)
            this.view.widget = this;
    },

    /**
     * Called when the user navigates to a page with a widget instance on it.
     * This is called after the view has been placed on the screen.
     * @template
     */
    onShow : Ext.emptyFn,

    /**
     * Called when the user navigates away from the page with the widget instance on it
     * @template
     */
    onHide : Ext.emptyFn,

    /**
     * Calls onDestroy, then disposes any resources created by this object.
     *@private
     */
    destroy : function() {
        this.onDestroy();
        if (Ext.isFunction(this.clearListeners)) {
            this.clearListeners();
        }
        if (!this.isComponent) {
            var view = this.getView();
            if (view) {
                Ext.destroy(view);
                this.setView(null);
            }
            this.getView = function() {
                console.warn("Cannot getView of a destroyed widget. Widget ID: " + this.id);
            };
        } else {
            this.callParent(arguments);
        }
    },

    /**
     * Called when the widget is to be destroyed. This is typically called from
     * the containing workspace after a different workspace has been shown.
     * @template
     */
    onDestroy : Ext.emptyFn,

    /**
     * Called when the widget is instantiated.
     *
     * This is currently called from the constructor, so it is mostly useful
     * for inline widget definitions or when you instantiate an
     * AppShell.core.Widget instance directly (not a subclass). If you are
     * subclassing the widget class, you can better control when your
     * initialization logic executes by implementing a constructor function.
     * @template
     */
    onCreate : Ext.emptyFn,

    /**
     * @property {AppShell.core.Workspace} workspace
     * The workspace containing this widget
     */

    /**
     * Called when a widget instance is added to the page
     * @template
     */
    onAdd : Ext.emptyFn,

    /**
     * Called when a widget instance is removed from the page
     * @template
     */
    onRemove : Ext.emptyFn

}, function() {
    /* Commented out because there are side effects, even though this is just a basic interceptor. For example, Tab panels do not work.
     // Allow Containers to receive widgets
     Ext.define("AppShell.core.Widget.Container.Add.Override", {
     override : "Ext.container.AbstractContainer",
     add : function(obj) {
     var args = Ext.Array.slice(arguments), argCtr, arrayCtr;
     for ( argCtr = 0; argCtr < args.length; argCtr++) {
     if (Ext.isArray(args[argCtr])) {
     args[argCtr] = Ext.Array.slice(args[argCtr]);
     for ( arrayCtr = 0; arrayCtr < args[argCtr].length; arrayCtr++) {
     if (args[argCtr][arrayCtr].isWidget) {
     var layoutHints = args[argCtr][arrayCtr].layoutHints;
     var view = args[argCtr][arrayCtr].getView();
     if (layoutHints) {
     Ext.apply(view, layoutHints);
     }
     args[argCtr][arrayCtr] = view;
     }
     }
     } else {
     if (args[argCtr].isWidget) {
     var layoutHints = args[argCtr].layoutHints;
     var view = args[argCtr].getView();
     if (layoutHints) {
     Ext.apply(view, layoutHints);
     }
     args[argCtr] = view;
     }
     }
     }
     this.callParent(args);
     },
     remove : function(comp, autoDestroy) {
     if (comp.isWidget) {
     comp = comp.getView();
     }
     this.callParent([comp, autoDestroy]);
     }
     });
     */
});

/**
 * Representation of an action. Instances of this class will typically be used for Additional Actions
 * in the UI. These are the actions that show up in the right hand side of the screen in a pull out
 * drawer.
 */
Ext.define("AppShell.core.Action", {
    extend : 'Ext.Action', 
    mixins : {
        identifiable : "AppShell.core.Identifiable",
        securable : "AppShell.security.Securable",
        observable : "Ext.util.Observable",
        localizable : "AppShell.i18n.Localizable"
    },
    
    /**
     * @cfg {Function} listener
     * The function that will be invoked by each component tied to this Action
     * when the component's primary event is triggered.
     */

    /**
     *@event beforeaction
     * Fired before the action is invoked
     * @param {AppShell.core.Action} this
     */

    /**
     *@event afteraction
     * Fired after the action is invoked
     * @param {AppShell.core.Action} this
     */

    // for Identifiable
    idPrefix : "action_",

    constructor : function(config) {
        Ext.apply(this, config);
        this.callParent(arguments);
        this.mixins.identifiable.constructor.apply(this, arguments);
        this.mixins.securable.constructor.apply(this, arguments);
        this.mixins.observable.constructor.apply(this, arguments);
        this.mixins.localizable.constructor.apply(this, arguments);
        this.addEvents("beforeaction", "afteraction");
        var newHandler = config.handler || this.handler;
        newHandler = Ext.Function.createInterceptor(Ext.bind(newHandler, this.scope), function() {
            return this.fireEvent("beforeaction", this);
        }, this);
        newHandler = Ext.Function.createSequence(Ext.bind(newHandler, this.scope), function() {
            this.fireEvent("afteraction", this);
        }, this);
        this.setHandler(newHandler);
    }
});

Ext.define("AppShell.view.WidgetWrapper", {
    extend : 'Ext.panel.Panel',
    alias : 'widget.widgetwrapper',
    panelType : "widget-title-wrapper",
    cls : 'v-widget-title-wrapper',
    margins : '4 4 4 4',
    flex : 1,
    layout : 'fit',
    
    config: {
        /**
         *@required 
         */
        widget: undefined,
        /**
         *@private 
         */
        header: false
    },
    
    constructor: function(config) {
        if (!config.dockedItems) {
            config.dockedItems = [];
        }
        
        
        var widget = config.widget;
        config.items = [widget.getView && widget.getView() || widget];
        var layoutHints = widget.layoutHints || {};

        var hideTitle = widget.hideTitle || (!widget.title && !widget.subtitle && !widget.titleCfg && (!widget.layoutHints || (widget.layoutHints && !widget.layoutHints.closable) ) && !widget.menuItems && !widget.buttons);
        if (!hideTitle) {
        
            var toolbarCfg = {
                xtype : 'toolbar',
                itemId : 'widget-title-bar',
                baseCls : 'x-plain-toolbar',
                layout: {
                    pack: "bottom"
                },
                items : this.getToolbarItems(widget),
                visible: config.widget.hideTitle !== true
            };
            Ext.Array.insert(config.dockedItems, 0, [toolbarCfg]);
        }
        
        this.mon(widget, 'titlechange', this.updateTitleItems, this);
        this.mon(widget, 'titlecomponentschange', this.updateTitleItems, this);
        
        
        this.callParent(arguments);
        this.initConfig(config);
    },
    
    updateTitleItems: function(widget) {
        var toolbar = this.down('#widget-title-bar');
        toolbar.removeAll(true);
        toolbar.add(this.getToolbarItems(widget));
    },
    
    getToolbarItems: function(widget) {
        var title = widget.getTitle && widget.getTitle() || widget.title;
        var subtitle = widget.getSubTitle && widget.getSubTitle() || widget.subtitle;
        var toolbarItems =  [
                    {
                        xtype: 'box',
                        itemId: 'widget-title',
                        cls: 'widget-title-text',
                        html: title,
                        hidden: !title
                    },
                    {
                        xtype: 'box',
                        itemId: 'widget-subtitle',
                        cls: 'widget-subtitle-text',
                        html: ' / ' + subtitle,
                        hidden: !subtitle
                    },
                    '->',
                    {
                        xtype: 'container',
                        itemId: 'widget-title-buttons',
                        hidden: !widget.buttons
                    },
                    {
                        xtype: 'button',
                        iconCls: 'v-icon-cfg',
                        itemId: 'widget-title-settings',
                        hidden: !widget.menuItems,
                        menu: {
                            items: widget.menuItems
                        }
                    },
                    {
                    xtype : 'button',
                        iconCls : 'v-icon-close',
                        handler : function(btn) {
                            this.widget.workspace.removeWidget(this.widget);
                        },
                        scope: this,
                        hidden: !widget.layoutHints || widget.layoutHints.closable !== true
                    }];
                    
            if (widget.titleComponents) {
                Ext.Array.insert(toolbarItems, 2, '-');
                Ext.Array.insert(toolbarItems, 3, widget.titleComponents);
            }
            return toolbarItems;
    }
});

/**
 * This view is a container that lays out items in rows.
 * Each row may have multiple widgets in it.
 * 
 * #layoutHints Config of a Widget
 * A widget may have a layoutHints config to influence how the widget is layed out on the workspace.
 * This is typically provided by the workspace author.
 * 
 * Currently supported layoutHints properties:
 * 
 *      - minHeight
 *          The minimum amount of height to give to the widget, not counting the title bar or border
 *      - maxInstances
 *          The maximum number of instances allowed on this workspace if the widget is closable
 *      - closable
 *          Indicates whether or not the widget can be removed from the workspace. If it can be removed, it can also be added via the right sliding drawer.
 * 
 */
Ext.define("AppShell.view.RowView", {
    extend : "Ext.container.Container",
    alias : "widget.rowview",
    requires : ["AppShell.view.WidgetWrapper"],
    autoScroll : false,
    layout : {
        type : "vbox",
        align : "stretch"
    },

    statics: {
        /**
         *@private 
         */
       wrapperHeight: 48 
    },

    mixins : {
        loggable : "AppShell.core.Loggable"
    },

    config : {
        autoScroll: true,
        /**
         * @cfg {Number / Array}
         * Specifies the number of widgets to place in each row. If a single number is specified,
         * it will use that number for all rows. If an array of numbers is specified, they will be applied
         * to the rows in order.
         *
         * For example, if [1,2,3] is specified, one widget will be placed in the first row, two in the second,
         * and three in the third. If more widgets are added, additional rows will have three widgets per row.
         */
        widgetsPerRow : [1, 3],
        /**
         * @cfg {Number / Array}
         *  Specifys the flex values to apply to each row. If a number is specified, it is applied to all rows. If
         * an array is specified, the flexes will be applied to rows in order. When the end of the array is reached,
         * the last entry will be used for all additional rows.
         */
        rowFlex : [3, 1],
        /**
         *@cfg {Number/Array}
         */
        rowHeight : undefined
    },

    autoDestroy : false,

    constructor : function(config) {
        this.initConfig(config);
        this.callParent(arguments);
        this.mixins.loggable.constructor.apply(this, arguments);

        this.numRows = 0;
        this.currentRow = 1;
        this.layoutHints = {};
        this.widgetsInCurrentRow = 0;

        if (!Ext.isArray(this.widgetsPerRow)) {
            this.widgetsPerRow = [this.widgetsPerRow];
        }

        this.widgetsByViewId = Ext.create("Ext.util.HashMap");
    },

    /**
     * Adds a widget to the layout. If no contradictory hints are specified, calling this method sequentially
     * will add widgets in the row until the row limit (if specified in the widgetsPerRow config) is reached.
     * After that, a new row will be inserted.
     *
     *
     * @param {AppShell.core.Widget / AppShell.core.Widget[]} widget
     */
    add : function(widgets) {
        if (!widgets) {
            return;
        }

        // If we have an array, recursively add the widgets
        if (Ext.isArray(widgets)) {
            if (widgets.length === 0) {
                return;
            }
            Ext.each(widgets, function(widget) {
                this.add(widget);
            }, this);
            return;
        }

        // Check Security
        if (Ext.isDefined(widgets.licenses) && !AppShell.security.SecurityManager.hasLicenses(widgets.licenses)) {
            this.logger.error("User tried to display a workspace (" + (widgets.workspace && widgets.workspace.id) + ") with a widget (" + widgets.id + ") that they do not have permissions for. Required licenses: " + widgets.licenses);
            widgets = Ext.widget("panel", {
                bundleName : "com.verint.web.core.appshell.l10n.AppShellBundle",
                licenses : widgets.licenses,
                i18nCfg : {
                    html : {
                        key : "You do not have the required licenses for this widget.",
                        params : ["licenses"]
                    }
                },
                setHtml : function(html) {
                    this.update(html)
                }
            });
        }
        if (Ext.isDefined(widgets.privileges) && !AppShell.security.SecurityManager.hasPrivileges(widgets.privileges)) {
            this.logger.error("User tried to display a workspace (" + (widgets.workspace && widgets.workspace.id) + ") with a widget (" + widgets.id + ") that they do not have permissions for. Required privileges: " + widgets.privileges);
            widgets = Ext.widget("panel", {
                bundleName : "com.verint.web.core.appshell.l10n.AppShellBundle",
                privileges : widgets.privileges,
                i18nCfg : {
                    html : {
                        key : "You do not have the required privileges for this widget.",
                        params : ["privileges"]
                    }
                },
                setHtml : function(html) {
                    this.update(html)
                }
            });
        }

        var layoutHints = Ext.clone(widgets.layoutHints);
        if (!Ext.isObject(layoutHints)) {
            layoutHints = {};
        }

        var view = widgets.getView ? widgets.getView() : widgets;
        var wrapper = Ext.widget('widgetwrapper', Ext.copyTo({
            flex : 1,
            widget : widgets
        }, layoutHints, "maxHeight,minWidth,maxWidth,height,width"));

        this.widgetsByViewId.add(view.id, widgets);
        /*
         if (this.widgetsInCurrentRow > 1) {
         wrapper.padding = "0 0 0 10";
         }
         */

        /*
         // If no sizing was specified, apply a flex
         var specifiedAnySizing = false;
         Ext.each(["width", "height", "flex", 'minHeight', 'maxHeight', 'minWidth', 'maxWidth'], function(property) {
         if (Ext.isDefined(widgets[property])) {
         wrapper[property] = widgets[property];
         specifiedAnySizing = true;
         }
         }, this);
         if (!specifiedAnySizing) {
         wrapper.flex = 1;
         }
         */
        view.border = 0;

        this.mon(widgets, 'titlechange', this.onWidgetTitleChange, this);

        // Add the view to the row and store the hints for persistence
        var rowContainer;
        if (!Ext.isDefined(layoutHints.row)) {
            rowContainer = this.getRowContainerWithCapacity();
        } else {
            while (this.numRows < layoutHints.row) {
                rowContainer = this.createRowContainer();
            }
        }
        rowContainer.add(wrapper);

        this.layoutHints[widgets.getId()] = layoutHints;

        // pixel buffer for widget title, panel-body padding and border.   Might want to make this more sohpisticated later (calculate the height of the title bar, etc);     
        var wrapperPixels = AppShell.view.RowView.wrapperHeight;
        if (rowContainer.hasTopPadding) {
            wrapperPixels += 10;
        } 

        var minHeight = layoutHints.minHeight + wrapperPixels || view.minHeight + wrapperPixels || wrapperPixels;
        var rowMin = rowContainer.minHeight; 
        if (!Ext.isNumber(rowMin) || minHeight < rowMin) {
            rowContainer.minHeight = minHeight;
            // Do a settimeout so that the rowContainer has an underlying element (needed for getHeight).
            // Setting the height will cause the layout engine to recalculate the heights
            setTimeout(function() {
                if (rowContainer.el) {
                    rowContainer.setHeight(rowContainer.getHeight());
                }
            }, 0);
        }
    },

    onWidgetTitleChange : function(widget, newTitle) {
        var wrapper = widget.getView().up('panel[panelType="widget-title-wrapper"]');
        if (wrapper) {
            var titleObj = wrapper.down('#widget-title');
            titleObj.update(newTitle);
        }
    },

    getMaxNumWidgetsForRow : function(rowNum) {
        var maxWidgetsInRow;
        if (rowNum >= this.widgetsPerRow.length) {
            maxWidgetsInRow = this.widgetsPerRow[this.widgetsPerRow.length - 1];
        } else {
            maxWidgetsInRow = this.widgetsPerRow[rowNum];
        }
        return maxWidgetsInRow;
    },

    removeEmptyRowContainers : function() {
        var containersToRemove = [];
        Ext.each(this.items.items, function(rowContainer) {
            if (rowContainer.items.items.length === 0) {
                containersToRemove.push(rowContainer);
            }
        }, this);
        Ext.each(containersToRemove, function(rowContainer) {
            Ext.container.Container.prototype.remove.call(this, rowContainer);
        }, this);
    },

    createRowContainer : function() {
        var flex = this.rowFlex;
        var currentNumRows = this.items.items.length;
        if (Ext.isArray(flex)) {
            if (currentNumRows >= flex.length) {
                flex = flex[flex.length - 1]
            } else {
                flex = flex[currentNumRows];
            }
        }

        var height = this.rowHeight;
        if (Ext.isArray(height)) {
            if (currentNumRows >= height.length) {
                height = height[height.length - 1]
            } else {
                height = height[currentNumRows];
            }
        }

        if (Ext.isNumber(height)) {
            height += AppShell.view.RowView.wrapperHeight + (currentNumRows ? 10: 0);
        }

        this.numRows++;

        var containerCfg = {
            itemId : "row" + this.numRows,
            layout : {
                type : "hbox",
                align : "stretch"
            }
        };

        if (this.numRows > 1) {
            containerCfg.hasTopPadding = true;
            containerCfg.padding = "10 0 0 0"
        }

        if (Ext.isNumber(flex) && !Ext.isNumber(height)) {
            containerCfg.flex = flex;
        } else if (Ext.isNumber(height)) {
            containerCfg.height = height;
        }

        var rowContainer = Ext.widget("container", containerCfg);
        Ext.container.Container.prototype.add.call(this, rowContainer);
        return rowContainer;
    },

    getRowContainerWithCapacity : function() {
        var containerWithCapacity, rowCtr = 0, rowContainers = this.items.items;
        if (rowContainers) {
            Ext.each(rowContainers, function(container) {
                var maxNumWidgets = this.getMaxNumWidgetsForRow(rowCtr);
                if (container.items.items.length < maxNumWidgets) {
                    containerWithCapacity = container;
                    return false;
                }
                rowCtr++;
            }, this);
        }

        if (!containerWithCapacity) {
            containerWithCapacity = this.createRowContainer();
        }

        return containerWithCapacity;
    },

    remove : function(widgets) {
        if (Ext.isArray(widgets)) {
            Ext.each(widgets, function(widget) {
                this.removeWidgets(widget);
            }, this);
        }

        var view = widgets.getView();
        if (view) {
            var panel = view.up('widgetwrapper');
            if (panel) {
                panel.close();
                this.removeEmptyRowContainers();
            }
        }
    },

    destroy : function() {
        Ext.each(this.items, function(item) {
            if (item && Ext.isDefined(item.id)) {
                var widget = this.widgetsByViewId.get(item.id);
                if (widget.destroy) {
                    widget.destroy();
                }
            }
        }, this);
        this.callParent(arguments);
    }
});


/**
 * #What is the Workspace Manager?
 *
 * The workspace manager is a class responsible for doing a lot of the
 * framework work with the application. In general, application developers will
 * not need to deal with the Workspace Manager directly. The Application Shell
 * relies on the Workspace Manager to show workspaces on the screen and to place
 * widgets.
 *
 * #Workspace Manager as a Context (id=wsm)
 *
 * The Workspace Manager registers itself as a context with the id "wsm". The
 * context has two events.
 *
 *      1. A change event is fired when the current workspace changes, for
 *          example, after the user navigates to a new page.
 *      2. A create event is fired when a new workspace is loaded into the
 *          system.
 *
 * The workspace manager also has a showWorkspace method that can be used to
 * programmatically navigate to a new workspace.
 *
 */
Ext.define("AppShell.WorkspaceManager", {
    mixins : {
        stateful : "Ext.state.Stateful",
        loggable : "AppShell.core.Loggable"
    },
    singleton : true,
    requires : ["AppShell.ContextManager"],
    stateId : "wsm",
    stateful : true,
    stateEvents : ["change"],

    constructor : function() {
        this.mixins.loggable.constructor.apply(this, arguments);
        this.workspaces = Ext.create("Ext.util.HashMap");
        this.workspaceCfgs = Ext.create("Ext.util.HashMap");
        this.currentWorkspace = null;
        this.state = undefined;

        /**
         *
         * @event create
         * Called after a workspace is created.
         * @param {AppShell.core.Workspace} workspace
         * @param {Object} wsCfg workspace configuration
         */
        /**
         *
         * @event change
         * Called when the current workspace changes
         * @param {AppShell.core.Workspace}
         */
        this.addEvents({
            "create" : true,
            "change" : true
        });

        this.callParent(arguments);
        this.mixins.stateful.constructor.apply(this, arguments);
        // Clear any workspace that was persisted. We need to go to the default screen, eventually, and not all workspaces are stateful, so going back when the app starts up isn't always feasible.
        if (this.state) {
            delete this.state.ws;
        }
        
        AppShell.ContextManager.addContext("wsm", this, ["ws"]);
        
        if (window.addEventListener) {
            window.addEventListener("unload", Ext.bind(this.clearCurrentWorkspace, this), false);
        } else {
            // IE8
            if (window.attachEvent) {
                window.attachEvent("onunload", Ext.bind(this.clearCurrentWorkspace, this), false);
            }
        }
    },

    /**
     *@protected
     */
    getState : function() {
        if (this.currentWorkspace) {
            return {
                ws : this.currentWorkspace.id
            };
        } else if (this.state) {
            return {
                ws : this.state.ws
            }
        }
        return null;
    },

    /**
     *@protected
     */
    applyState : function(state) {
        if (state && state.ws) {
            this.state = state;
        }
        if (state.ws) {
            setTimeout(Ext.bind(this.showWorkspace, this, [state.ws]), 0);
        }
    },

    /**
     *
     */
    getCurrentWorkspace : function() {
        return this.currentWorkspace;
    },

    /**
     * @private
     */
    getNavPath : function(wsCfg, module) {
        var ws = wsCfg;
        if (Ext.isString(ws)) {
            try {
                ws = eval(ws);
            } catch (e) {
                this.logger.error("Could not find the specified workspace: " + ws + ". Make sure it is 'required'.");
                return null;
            }
        }
        var navPath = ws.navPath || (ws.prototype && ws.prototype.navPath);
        return navPath;
    },

    /**
     * @private
     * @param {Object} wsCfg
     * @param {AppShell.core.Module} module
     */
    showWorkspaceCfg : function(wsCfg, module) {
        var ws = this.workspaces.get(this.getWorkspaceIDFromCfg(wsCfg));
        if (!ws) {
            ws = this.createWorkspace(wsCfg, module);
        }
        this.showWorkspace(ws);
    },

    /**
     * Shows a workspace in the UI
     * @param {String / AppShell.core.Workspace} workspace id or Workspace instance
     */
    showWorkspace : function(workspace) {
        // Check to see if an id was passed in. If so, get the real workspace
        if (Ext.isString(workspace)) {
            var ws = this.workspaces.get(workspace);
            if (ws) {
                workspace = ws;
            } else {
                var wsCfg = this.workspaceCfgs.get(workspace);
                if (wsCfg) {
                    this.showWorkspaceCfg(wsCfg, wsCfg.module);
                }
                return;
            }
        }

        // If showing the current workspace, just return
        if (workspace === this.currentWorkspace)
            return;

        // Fire beforechange event
        /**
         * Fired before the workspace switches. If an event handler returns false,
         * the workspace switch will be canceled.
         * @event beforechange
         * @param {AppShell.core.Workspace} newWorkspace
         * @param {AppShell.core.Workspace} oldWorkspace
         */
        var beforeChangeRetVal = this.fireEvent("beforechange", workspace, this.currentWorkspace);
        if (beforeChangeRetVal === false) {
            return;
        }

        this.clearCurrentWorkspace();

        this.currentWorkspace = workspace;

        var wsmViewTypes = ["selector", "main"];
        var hasViewType = {};
        Ext.each(workspace.getSupportedViewTypes(), function(viewType) {
            if (Ext.Array.contains(wsmViewTypes, viewType)) {
                var view = workspace.getView(viewType);
                if (view) {
                    hasViewType[viewType] = true;
                    this.setView(viewType, view);
                }
            }
        }, this);

        Ext.each(wsmViewTypes, function(viewType) {
            var contentContainer = Ext.getCmp(viewType + "Content");
            if (contentContainer) {
                if (!hasViewType[viewType]) {
                    contentContainer.hide();
                } else {
                    contentContainer.show();
                }
            }
        }, this);

        this.currentWorkspace.show();

        this.fireEvent("change", workspace);
    },
    
    clearCurrentWorkspace: function() {
        this.clearViews();

        if (this.currentWorkspace) {
            this.currentWorkspace.hide();
            this.workspaces.removeAtKey(this.currentWorkspace.id);
            this.currentWorkspace.destroy();
        }
    },

    /**
     *
     * @private
     */
    createWorkspace : function(wsCfg, module) {
        var ws;
        if (wsCfg.isWorkspace) {
            ws = wsCfg;
        } else {
            if ( typeof (wsCfg) === "string") {
                ws = Ext.create(wsCfg, {
                    module : module
                });
            } else {
                if (Ext.isObject(wsCfg)) {
                    wsCfg.module = module;
                }
                ws = Ext.create("AppShell.core.Workspace", wsCfg);
            }
        }

        this.workspaces.add(ws.id, ws);

        var bundleName = ws.bundleName || (module && module.bundleName);
        if (bundleName) {
            ws.bundleName = bundleName;
        }

        this.fireEvent("create", ws, wsCfg);
        return ws;
    },

    /**
     * Looks for a container with the id of viewType + "Content". Replaces that container's content with the specified view
     * @private
     */
    setView : function(viewType, view) {
        this.clearView(viewType);
        var contentContainer = Ext.getCmp(viewType + "Content");
        if (!contentContainer) {
            this.logger.error("ViewManager: could not find container for view type: " + viewType + ". Trying to set view: " + view.$className + ".");
            return false;
        }
        contentContainer.add(view);
    },

    /**
     *
     * @private
     * @param {String} viewType
     */
    clearView : function(viewType) {
        var contentContainer = Ext.getCmp(viewType + "Content");
        if (!contentContainer) {
            this.logger.error("ViewManager: could not find container for view type: " + viewType);
            return false;
        }
        contentContainer.removeAll(false);
    },

    /**
     *
     * @private
     */
    clearViews : function() {
        Ext.each(["main", "selector"], Ext.bind(this.clearView, this));
    },

    registerWorkspaces : function(modules) {
        modules.each(function(module) {
            if (module.wsCfgs) {
                Ext.each(module.wsCfgs, function(wsCfg) {
                    wsCfg.module = module;

                    var id = this.getWorkspaceIDFromCfg(wsCfg);
                    if (this.state && this.state.ws && this.state.ws === id) {
                        this.showWorkspaceCfg(wsCfg, module);
                    }
                    this.workspaceCfgs.add(id, wsCfg);
                }, this);
            }
        }, this);
    },

    getWorkspaceIDFromCfg : function(wsCfg) {
        if (Ext.isString(wsCfg)) {
            Ext.Loader.syncRequire(wsCfg);
            var module = wsCfg.module;
            wsCfg = eval(wsCfg);
            wsCfg.module = module;
        }

        var id = wsCfg.id;
        if (!id) {
            id = AppShell.core.Workspace.prototype.idGenFn.apply(wsCfg.prototype || wsCfg);
        }
        return id;
    },

    // instantiates a widget as part of this workspace
    createWidget : function(widgetCfg, type, id, workspace) {
        // This cfg object will contain some values set by the framework, such as workspace and id.
        // It will also contain a bundleName if one is not specified in the widget
        var cfg = {
            workspace : workspace
        };
        // If an id is specified, use it. Otherwise generate one that is predictable.
        if (Ext.isDefined(id)) {
            cfg.id = id;
        } else if (workspace) {
            var ordinal = Math.random();
            if (workspace.numWidgetsAdded && Ext.isDefined(workspace.numWidgetsAdded[type])) {
                ordinal = workspace.numWidgetsAdded[type]
            }
            cfg.id = workspace.stateId + "/widgets/" + type + '/' + ordinal;
        }
        
        // Widgets are specified in a few different ways. We will store
        // the initialization function and whether or not it is a constructor.
        var fn = null;

        // If they specified a plain function, execute it to get the real config
        if (Ext.isFunction(widgetCfg)) {
            widgetCfg = widgetCfg.call(workspace || this, cfg);
        }

        if (!widgetCfg)
            return null;

        if (widgetCfg.isWidget) {
            // This is the easiest case. The workspace author is specifying a widget instance.
            // This probably isn't preferred, but we will allow it.

            // All we have to do is set some properties on the existing instance, if they don't
            // already exist.
            Ext.applyIf(widgetCfg, cfg);
            return widgetCfg;
        } else {
            var constructorAndConfig = this.getWidgetConstructorAndConfig(workspace, widgetCfg);
            fn = constructorAndConfig.fn;
            Ext.applyIf(cfg, constructorAndConfig.cfg);
        }

        var widget = new fn(cfg);

        return widget;
    },

    getWidgetConstructorAndConfig : function(workspace, widgetCfg) {
        var fn, cfg = {};
        if (widgetCfg.isComponent || Ext.isDefined(widgetCfg.xtype)) {
            // We allow them to specify a Ext Component instance or config
            cfg.viewCfg = widgetCfg;
            Ext.syncRequire("AppShell.core.Widget");
            fn = eval("AppShell.core.Widget");
        } else if (Ext.isString(widgetCfg)) {
            // In this case, they specified the type as a string.
            Ext.syncRequire(widgetCfg);
            fn = eval(widgetCfg);
        } else {
            // It is a widget config object

            // Get the class from the config object, or default to AppShell.core.Widget
            var clazz = widgetCfg.xclass || widgetCfg.type || "AppShell.core.Widget";
            Ext.syncRequire(clazz);
            fn = eval(clazz);

            // Apply specified configuration to widget
            Ext.apply(cfg, widgetCfg);
        }

        // Start with the default bundle name to be the same bundle as the workspace.
        // We will later check to see if a bundle name was specified in the widget class
        // or config itself. If so, that will take precedence.
        var bundleName = null;
        if (workspace) {
            bundleName = workspace.bundleName;
        }

        // If we don't have a bundle name on the prototoype, set it con the config
        if (! Ext.isDefined(fn.prototype.bundleName)) {
            if (bundleName && !Ext.isDefined(cfg.bundleName)) {
                cfg.bundleName = bundleName;
            }
        }

        return {
            fn : fn,
            cfg : cfg
        };
    },

    /**
     * Creates and displays a modal window
     * @param {String / Object} widgetCfg Either the name of a widget class or a widget config to be shown inside the window
     * @param {String} title A title for the window
     * @param {int} h the height of the window
     * @param {int} w the width of the window
     */
    showModalWidget : function(widgetCfg, title, h, w) {
        var widget = widgetCfg;
        if (!widget.isComponent) {
            widget = this.createWidget(widgetCfg);
        }

        if (widget) {
            this.modalWindow = Ext.create("AppShell.view.ModalWindow", {
                component : widget.getView ? widget.getView() : widget,
                title : title || (Ext.isFunction(widget.getTitle) && widget.getTitle()),
                cls: 'v-model-widget',
                height : h,
                width : w,
                listeners : {
                    destroy : function() {
                        if (widget.destroy)
                            widget.destroy();
                    },
                    show : function() {
                        if (widget.onShow)
                            widget.onShow();
                    },
                    close : function() {
                        if (widget.onHide)
                            widget.onHide();
                    }
                }
            });

            this.modalWindow.show();
        }

        return this.modalWindow;
    },

    /*
     * Hides an opened modal window
     */
    hideModalWindow : function() {
        if (this.modalWindow) {
            this.modalWindow.destroy();
            this.modalWindow = undefined;
        }
    }
});

/**
 *
 * #What is a Workspace?
 * A workspace is equivalent to a screen in the application. It essentially is
 * a collection of widgets along with some metadata like which licenses and
 * privileges are required, and where in the navigation it should be placed.
 *
 * #Lifecycle
 * The methods involved in the lifecycle of the workspace are the following.
 *     1. constructor
 *     2. onCreate
 *     3. getView for each area (selector, main, etc)
 *     4. onShow
 *     5. onHide
 *     6. onDestroy
 *
 * ##The Constructor
 * By default, the constructor contains a lot of initialization code that processes the configuration of the workspace, converting configs to usable instances.
 *
 * ##onCreate
 * This template method can be used for initialization logic. It is called from the constructor after other configuration items, like widgets and actions, have been processed.
 *
 * ##getView
 * This method is called by the workspace manager once for each supported view type in order to show the workspace on the screen.
 *
 * ##onShow
 * This template method is called after the workspace has placed the selectorView and the mainView on the screen.
 *
 * ##onHide
 * This template method is called when the user navigates away from a workspace.
 *
 * ##onDestroy
 * This template method is called when the application shell wishes to reclaim memory.
 *
 *#Optional Widgets
 *Optional widgets are widgets that may or may not be on the workspace at any given time. They may be added or removed by the user. They are indicated by having  a layoutHints object with a closable property set to true. In this case, you must also specifiy a cfgId to help identify the widget configuration. This cfgId identifier should be unique on the workspace. It is used to match up the list of current widgets on the workspace (stored) with the widget config in your workspace.
 *
 *For example, this workspace configuration contains one optional widget.
 *
 *{
 *   wsCfg: {
 *        main: {
 *            type: "My.WidgetClass",
 *            layoutHints: {
 *                closable: true,
 *                maxInstances: 1,
 *                cfgId: 'MyWidgetOnce'
 *            }
 *        }
 *    }
 *}
 *
 *By default, the widget will appear on the screen unless the visible layoutHints property is set to false. Also,
 * note that the maxInstances layout hint specifies how many instances of the cfgId are allowed.
 *
 *      {
 *          wsCfg: {
 *              main: [{
 *                  type: "My.WidgetClass",
 *                  layoutHints: {
 *                      closable: true,
 *                      maxInstances: 1,
 *                      cfgId: 'MyWidgetOnce',
 *                      visible: false
 *                  }
 *              }]
 *          }
 *      }
 *
 *##Optional Widget Titles
 *An optional widget needs to have a title, or a Localizable configuration that supplies a title. For example:
 *
 *      {
 *          wsCfg: {
 *              main: {
 *                  bundleName: 'MyNamespace.MyBundle',
 *                  i18nCfg: {
 *                      title: 'myTitleKey'
 *                  },
 *                  viewCfg: {
 *                      xtype: 'component',
 *                      html: 'example content'
 *                  },
 *                  layoutHints: {
 *                      closable: true,
 *                      cfgId: 'MyWidgetOnce',
 *                      visible: false
 *                  }
 *              }
 *          }
 *      }
 *
 * 
 * 
 * #Views
 * By default, each area (main, selector, etc) that has widgets, will get a view. The default view is a row view.
 *
 * If you wish to specify your own view class, you can do so via a viewCfg config property. Your view must be a Ext.container.Container.
 * For example:
 *
 *        viewCfg : {
 *                 main : {
 *                     xtype : "container",
 *                 layout : {
 *                         type : "vbox",
 *                     align : "stretch"
 *                 }
 *             }
 *         }
 *
 * In this case, the view will be instantiated and any widgets that were instantiated via the widgetCfg property will be added to the view.
 *
 * #Additional Actions
 * In the Application Shell, workspaces may specify additional actions that the
 * user may execute by opening the drawer on the right hand side of the page.
 * These are specified in the actionCfg config option. The value is an array of
 * config options used when instantiating a AppShell.core.Action class.
 * 
 * Example:
 *  
 *      actionCfgs: [
 *          {
 *              bundleName: "MyModule.MyBundle",
 *              i18nCfg: {
 *                  text: "Say Hello"
 *              }
 *              handler: function() {
 *                  alert('Hello!');
 *              }
 *          }
 *      ]
 *
 * #Navigation
 * A workspace represents a page in the system, that the user can access via a
 * navigation menu. Our navigation menu is a hierarchical tree. The position of
 * the workspace within this tree can be configured by the navPath config option,
 * which is an array of tab identifiers.
 *
 * #Widget Controllers
 * The workspace will facilitate the use of Controllers in the widgets it contains.
 * When the workspace is shown, the controller's onWorkspaceShow method is
 * called. When the workspace is hidden, onWorkspaceHide. In each case,
 * the parameter passed into the method is a config object defined as follows.
 *
 *      {
 *          eventBus: ...,
 *          viewScope: ...,
 *          workspaceState: ...,
 *          workspaceId: ...
 *      }
 *
 */
Ext.define("AppShell.core.Workspace", {
    mixins : {
        loggable : "AppShell.core.Loggable",
        identifiable : "AppShell.core.Identifiable",
        observable : "Ext.util.Observable",
        securable : "AppShell.security.Securable",
        stateful : "Ext.state.Stateful"
    },
    requires : ["Ext.util.Observable", "AppShell.security.Securable", "Ext.state.Stateful", "AppShell.core.Widget", "AppShell.core.Action", "AppShell.view.RowView"],
    uses : ["AppShell.WorkspaceManager"],

    idGenFn : function() {
        if (!Ext.isDefined(this.id)) {
            if (this.navPath && this.navPath.length && this.navPath.join) {
                this.id = "ws_" + this.navPath.join("/");
            } else {
                this.id = Ext.id(null, "ws_");
            }
        }
        return this.id;
    },

    /**
     *@property
     */
    isWorkspace : true,

    constructor : function(config) {
        Ext.apply(this, config);
        Ext.apply(this, {
            stateEvents : ["widgetadd", "widgetremove"],
            events : ["widgetadd", "widgetremove"]
        });

        /**
         *@property {Ext.util.Observable} eventBus
         * This is an event bus that will allow widgets to respond to events.
         * This is an object that will be passed into the controller's onWorkspaceShow and onWorkspaceHide methods.
         *
         * #ContextManager and the Workspace eventBus
         * By default, all observable contexts from the AppShell.ContextManager will have their events relayed
         * onto the workspace eventBus for the current (shown) workspace. When the events are relayed, the context id is prefixed onto
         * the event name. This means that if I register a context with id "wsm" and it fires an event named
         * "change", the event name on the event bus will be "wsm_change"
         *
         */
        this.eventBus = new Ext.util.Observable();

        /**
         *@property {Ext.component.Component} viewScope
         * This is an object that will be passed into the controller's onWorkspaceShow and onWorkspaceHide methods.
         */
        this.viewScope = Ext.ComponentQuery.query("#workspaceContainer")[0];

        /**
         *@property {Ext.util.HashMap} workspaceState
         * This is an object that can contain any state that the workspace will require.
         * It will be passed into the controller's onWorkspaceShow and onWorkspaceHide methods.
         */
        this.workspaceState = new Ext.util.HashMap();

        this.mixins.loggable.constructor.apply(this, arguments);

        // Generate ids
        this.mixins.identifiable.constructor.apply(this, arguments);
        this.stateId = "workspaces/" + this.id.replace(/\//g, '_');

        // Call parent and mixin constructors
        this.callParent(arguments);
        this.mixins.observable.constructor.apply(this, arguments);
        this.mixins.securable.constructor.apply(this, arguments);
        this.mixins.stateful.constructor.apply(this, arguments);

        /**
         *@property {Object} views
         * Contains the instantiated views, keyed by area
         * @private
         */
        if (!Ext.isDefined(this.views)) {
            this.views = {};
        }

        /**
         *@property
         * @protected
         */
        this.supportedViewTypes = [];

        this.processActionCfgs();
        this.processWidgetCfgs();
        this.processViewCfgs();
        this.addWidgetsToViews();

        this.onCreate();
    },

    /**
     * @return {Array} of strings
     */
    getSupportedViewTypes : function() {
        return this.supportedViewTypes;
    },

    /**
     * Gets the view for the specified view type.
     * @param {String} viewType
     */
    getView : function(viewType) {
        return this.views[viewType];
    },

    /**
     * Goes through action configs on a workspace and instantiates the required actions
     *
     *@private
     */
    processActionCfgs : function() {
        this.actions = [];
        if (this.actionCfgs) {
            Ext.each(this.actionCfgs, function(cfg, index, cfgs) {
                var newAction = null;
                if (Ext.isString(cfg)) {
                    newAction = Ext.create(cfg);
                } else if (Ext.isObject(cfg)) {
                    if ( cfg instanceof AppShell.core.Action) {
                        newAction = cfg;
                    } else {
                        newAction = Ext.create("AppShell.core.Action", cfg);
                    }
                } else {
                    this.logger.error("Unknown action configuration: " + cfg + " for workspace: " + this.id);
                }

                if (newAction) {
                    newAction.workspace = this;
                    this.actions.push(newAction);
                }
            }, this);
        }
    },

    /**
     * Goes through the widget configs on a workspace and instantiates the required widgets,
     * and makes sure the optional widgets are factory functions
     *
     *@private
     */
    processWidgetCfgs : function() {
        // Load widgets
        /**
         *@property {Object} widgets
         * Object of widget instance arrays currently on the workspace.
         */
        this.widgets = {};
        if (!this.numWidgetsAdded) {
            this.numWidgetsAdded = {};
        }
        if (!this.numInstancesByCfgId) {
            this.numInstancesByCfgId = {};
        }
        this.layoutHintsByCfgId = {};

        var optionalWidgets = undefined;
        if (this.widgetCfg) {
            var addedWidgetCfgs = {};
            Ext.Object.each(this.widgetCfg, function(region, widgetCfg, widgetCfgs) {

                if (!this.widgets[region]) {
                    this.widgets[region] = [];
                }

                if (!this.numWidgetsAdded[region]) {
                    this.numWidgetsAdded[region] = 0;
                }

                if (!Ext.Array.contains(this.supportedViewTypes, region)) {
                    this.supportedViewTypes.push(region);
                }

                if (!Ext.isArray(widgetCfg)) {
                    widgetCfg = [widgetCfg];
                }

                Ext.each(widgetCfg, function(widgetCfg) {
                    var widget = null;

                    var layoutHints = this.getLayoutHints(widgetCfg);

                    // If the widget is closable, rely on the addedWidgetCfgs to add it back, if available
                    if (layoutHints && layoutHints.closable === true) {
                        // Store optional widget configs by cfgId, so we can match up stateful info with widget cfgs
                        if (!Ext.isString(layoutHints.cfgId)) {
                            this.logger.error("Closable widget configs must specify a String cfgId property that is unique in the workspace. WS=" + this.id + ". Widget=" + Ext.JSON.encode(widgetCfg));
                            return;
                        }
                        var optionalWidgetsByCfgId = (this.optionalWidgets || (this.optionalWidgets = {}));
                        optionalWidgetsByCfgId[layoutHints.cfgId] = widgetCfg;

                        if (!optionalWidgets) {
                            optionalWidgets = {};
                        }
                        var arr = optionalWidgets[region] || (optionalWidgets[region] = []);
                        arr.push(widgetCfg);

                        // If it hasn't been closed, show it immediately
                        if (layoutHints.visible !== false && (!Ext.isDefined(this.closedWidgetCfgs) || !this.closedWidgetCfgs[layoutHints.cfgId])) {

                            // Keep track of the number of instances for widgets where it matters.
                            if (Ext.isDefined(layoutHints.maxInstances)) {
                                var numInstances = this.numInstancesByCfgId[layoutHints.cfgId] || 0;
                                if (numInstances >= layoutHints.maxInstances) {
                                    return;
                                } else {
                                    this.numInstancesByCfgId[layoutHints.cfgId] = numInstances + 1;
                                }
                            }

                            widget = AppShell.WorkspaceManager.createWidget(widgetCfg, region, widgetCfg.id, this);
                            addedWidgetCfgs[widget.getId()] = layoutHints.cfgId;
                            // Add the instantiated widget to the array
                            this.widgets[region].push(widget);
                            this.numWidgetsAdded[region]++;

                        }
                    } else {
                        // Not closable, so it is always on the workspace, unless it isn't visible for some reason
                        if (!widgetCfg.layoutHints || widgetCfg.layoutHints.visible !== false) {
                            widget = AppShell.WorkspaceManager.createWidget(widgetCfg, region, widgetCfg.id, this);
                            // Add the instantiated widget to the array
                            this.widgets[region].push(widget);
                            this.numWidgetsAdded[region]++;
                        }
                    }
                }, this);
            }, this);

            // Process added addtional widgets
            if (this.addedWidgetCfgs) {
                var addedWidgetCfgsToRemove = [];
                Ext.Object.each(this.addedWidgetCfgs, function(id, cfgId) {
                    if (!Ext.isString(cfgId)) {
                        addedWidgetCfgsToRemove.push(id);
                        return;
                    }
                    var cfg = this.optionalWidgets[cfgId];
                    if (!cfg) {
                        // The widget was probably removed from the workspace. Clean up.
                        addedWidgetCfgsToRemove.push(id);
                        if (this.closedWidgetCfgs) {
                            delete this.closedWidgetCfgs[id];
                        }
                        Ext.state.Manager.clear(id);
                        return;
                    }

                    var layoutHints = this.getLayoutHints(cfg);

                    // Keep track of the number of instances for widgets where it matters.
                    if (Ext.isDefined(layoutHints.maxInstances)) {
                        var numInstances = this.numInstancesByCfgId[layoutHints.cfgId] || 0;
                        if (numInstances >= layoutHints.maxInstances) {
                            return;
                        } else {
                            this.numInstancesByCfgId[layoutHints.cfgId] = numInstances + 1;
                        }
                    }

                    var widget = AppShell.WorkspaceManager.createWidget(cfg, 'main', id, this);
                    this.widgets['main'].push(widget);
                    this.numWidgetsAdded['main']++;
                }, this);

                // Since we are done looping through this.addedWidgetCfgs, it is safe to remove items from it.
                if (addedWidgetCfgsToRemove.length > 0) {
                    Ext.each(addedWidgetCfgsToRemove, function(id) {
                        delete this.addedWidgetCfgs[id];
                    }, this);
                    this.saveState();
                }
            } else {
                // There is no stored 'addedWidgetCfgs' configuration. So seed it with
                // all optional widgets which were added above.
                this.addedWidgetCfgs = {};
                Ext.Object.each(addedWidgetCfgs, function(id, cfgId) {
                    this.addedWidgetCfgs[id] = cfgId;
                }, this);
            }

            this.createAddAWidgetAction(optionalWidgets);

            this.onWidgetsInstantiated();
        }
    },

    /**
     * If there are optional widgets, create an "Additional Action" item to add them.
     * @private
     */
    createAddAWidgetAction : function(optionalWidgets) {
        if (optionalWidgets) {
            this.actions.push(Ext.create("AppShell.core.Action", {
                bundleName : 'com.verint.web.core.appshell.l10n.AppShellBundle',
                i18nCfg : {
                    text : "Add a Widget"
                },
                handler : function() {
                    var menuItems = [];
                    Ext.Object.each(optionalWidgets, function(type, cfgArr) {

                        Ext.each(cfgArr, function(cfg) {
                            var fnCfg = AppShell.WorkspaceManager.getWidgetConstructorAndConfig(this, cfg);
                            // This fnCfg object contains a {fn: constructor, cfg: config} that is used to instantiate
                            // a widget. We can get the title from these objects

                            var authorized = false;
                            if (fnCfg.cfg.licenses || fnCfg.cfg.privileges) {
                                authorized = AppShell.security.SecurityManager.isAuthorized(fnCfg.cfg);
                            } else {
                                authorized = AppShell.security.SecurityManager.isAuthorized(fnCfg.fn.prototype);
                            }
                            if (!authorized)
                                return;

                            var actionCfg = {
                                bundleName : fnCfg.cfg.bundleName || fnCfg.fn.prototype.bundleName,
                                i18nCfg : {
                                },
                                handler : function() {
                                    this.addWidget(cfg);
                                },
                                scope : this
                            };
                            var title = (fnCfg.cfg.i18nCfg && fnCfg.cfg.i18nCfg.title) || (fnCfg.fn.prototype.i18nCfg && fnCfg.fn.prototype.i18nCfg.title);
                            if (title) {
                                actionCfg.i18nCfg.text = title;
                            } else {
                                title = actionCfg.text = fnCfg.cfg.title || fnCfg.fn.prototype.title
                            }
                            if (title) {
                                var menuItem = Ext.create("Ext.menu.Item", Ext.create('AppShell.core.Action', actionCfg));
                                menuItems.push(menuItem);

                                // Enable or disable based on maxInstances
                                var layoutHints = this.getLayoutHints(cfg);
                                if (Ext.isDefined(layoutHints.maxInstances)) {
                                    if (this.numInstancesByCfgId && Ext.isDefined(this.numInstancesByCfgId[layoutHints.cfgId])) {
                                        menuItem.setVisible(this.numInstancesByCfgId[layoutHints.cfgId] < layoutHints.maxInstances);
                                    }
                                }
                            } else {
                                this.logger.error("Need a title for optional widget on workspace: " + (this.id));
                            }
                        }, this);
                    }, this);

                    AppShell.WorkspaceManager.showModalWidget({
                        bundleName : 'com.verint.web.core.appshell.l10n.AppShellBundle',
                        i18nCfg : {
                            title : "Add a Widget"
                        },
                        viewCfg : {
                            xtype : "menu",
                            floating : false,
                            cls : 'v-add-widget-menu',
                            items : menuItems,
                            listeners : {
                                click : function(menu, menuItem) {
                                    if (Ext.isDefined(menuItem)) {
                                        AppShell.WorkspaceManager.hideModalWindow();
                                    }
                                }
                            }
                        }
                    }, undefined, 300, 200);
                },
                scope : this
            }));
        }
    },

    processViewCfgs : function() {
        /**
         *@cfg {Object} viewCfg
         * This is an object specifying the view configurations, keyed by area (main, selector, etc).
         *
         * In general, the views specified should be containers. Any widgets instantiated via the widgetCfg
         * property will be added to the appropriate view via the add method.
         *
         * For example, here is a viewCfg
         *
         * viewCfg: {
         *     main: {
         *     xtype: "container",
         *      layout: "vbox"
         * }
         * }
         *
         */
        if (Ext.isDefined(this.viewCfg)) {
            Ext.Object.each(this.viewCfg, function(viewType, cfg) {
                if (!Ext.Array.contains(this.supportedViewTypes, viewType)) {
                    this.supportedViewTypes.push(viewType);
                }
                cfg.workspace = this;
                this.views[viewType] = Ext.widget(cfg);
            }, this);
        }

        Ext.each(this.supportedViewTypes, function(viewType) {
            if (!Ext.isDefined(this.views[viewType])) {
                this.views[viewType] = Ext.widget("rowview", {
                    workspace : this,
                    id: this.id + '/' + viewType,
                    stateId: this.stateId + '/' + viewType + '/view'
                });
            }
        }, this);
    },

    addWidgetsToViews : function() {
        Ext.each(["selector", "main"], function(viewType) {
            var view = this.getView(viewType);
            if (view && Ext.isFunction(view.add)) {
                view.add(this.widgets[viewType]);
            }
        }, this);
    },

    getLayoutHints : function(widgetCfg) {
        /*
         * Get an object that contains all static configuration for this widget.
         */
        var cfgObj = {};
        // If it is a config object, use all specified properties
        if (Ext.isObject(widgetCfg)) {
            Ext.apply(cfgObj, widgetCfg);
        }
        // If there is a type defined, use all of it's prototype's properties
        // First get the type.
        var type = undefined;
        if (Ext.isString(cfgObj)) {
            type = cfgObj;
        } else {
            if (widgetCfg.type) {
                type = widgetCfg.type
            }
        }
        // Now loop through the prototype chain and get the properties
        if (type) {
            Ext.Loader.syncRequire(cfgObj);
            type = eval(cfgObj);
            var proto = type.prototype;
            while (proto) {
                Ext.applyIf(cfgObj, proto);
                proto = proto.__proto__;
            }
        }

        return cfgObj.layoutHints;
    },

    /**
     * Add an optional widget to the workspace
     * @param {String / Object} widgetCfg Either the name of a widget class or a widget config
     */
    addWidget : function(widgetCfg) {
        var layoutHints = this.getLayoutHints(widgetCfg);

        // Keep track of the number of instances for widgets where it matters.
        if (Ext.isDefined(layoutHints.maxInstances)) {
            var numInstances = this.numInstancesByCfgId[layoutHints.cfgId] || 0;
            if (numInstances >= layoutHints.maxInstances) {
                return;
            } else {
                this.numInstancesByCfgId[layoutHints.cfgId] = numInstances + 1;
            }
        }

        var type = "main";
        var widget = AppShell.WorkspaceManager.createWidget(widgetCfg, type, widgetCfg.id, this);

        if (!Ext.isDefined(this.addedWidgetCfgs)) {
            this.addedWidgetCfgs = {};
        }

        if (Ext.isFunction(widgetCfg)) {
            widgetCfg = widgetCfg.$className;
        }
        this.addedWidgetCfgs[widget.getId()] = layoutHints.cfgId;

        // If we don't yet have an array, create one
        if (!Ext.isDefined(this.widgets[type])) {
            this.widgets[type] = [];
        }

        this.widgets[type].push(widget);
        this.numWidgetsAdded[type]++;

        if (this.views[type]) {
            this.views[type].add(widget);
        }

        if (widget.onAdd) {
            widget.onAdd();
        }
        this.fireEvent("widgetadd", widget, type, this);
        return widget;
    },

    /**
     * Removes an optional widget from the workspace
     */
    removeWidget : function(widget) {
        if (this.views.main) {
            this.views.main.remove(widget);
        }
        widget.onRemove();
        if (this.addedWidgetCfgs && Ext.isDefined(this.addedWidgetCfgs[widget.id])) {
            delete this.addedWidgetCfgs[widget.id];
        }

        if (!this.closedWidgetCfgs) {
            this.closedWidgetCfgs = {};
        }
        this.closedWidgetCfgs[widget.layoutHints.cfgId] = true;
        this.numInstancesByCfgId[widget.layoutHints.cfgId] = (this.numInstancesByCfgId[widget.layoutHints.cfgId] || 1) - 1;

        var stateId = undefined;
        if (widget.getStateId) {
            stateId = widget.getStateId() || widget.getId();
        }
        Ext.destroy(widget);

        // Make sure the widget cleaned up it's state
        if (stateId) {
            if (Ext.state.Manager.get(stateId, undefined) !== undefined) {
                this.logger.warn("Stateful widgets should clean up their state by calling 'Ext.state.Manager.clear(this.getStateId() || this.getId())' in their onRemove method. They should also set this.stateful to false.");
                widget.stateful = false;
                Ext.state.Manager.clear(stateId);
            }
        }
        this.fireEvent("widgetremove", widget, "optional", this);
    },

    stateful : true,
    getState : function() {
        return {
            widgets : {
                "main" : {
                    addedWidgetCfgs : this.addedWidgetCfgs,
                    numWidgetsAdded : this.numWidgetsAdded,
                    closedWidgetCfgs : this.closedWidgetCfgs
                }
            }
        };
    },

    applyState : function(newState) {
        if (newState.widgets && newState.widgets.main) {
            Ext.apply(this, newState.widgets.main);
        }
    },

    addListener : function() {
        this.mixins.observable.addListener.apply(this, arguments);
    },

    destroy : function() {
        this.onDestroy();
        Ext.each(this.actions, function(action, index, actions) {
            Ext.destroy(action);
        }, this);
        Ext.Object.each(this.views, function(sectionId, view, views) {
            Ext.destroy(view);
        });
        Ext.Object.each(this.widgets, function(sectionId, widget, widgets) {
            Ext.destroy(widget);
        }, this);
        this.clearManagedListeners();
    },

    getControllerInstancesFromWidgets : function() {
        var controllers = new Ext.util.MixedCollection();
        if (this.widgets) {
            var viewTypes = this.getSupportedViewTypes();
            Ext.each(viewTypes, function(viewType) {
                if (this.widgets[viewType]) {
                    Ext.each(this.widgets[viewType], function(widget) {
                        if (widget.getControllerInstances) {
                            var controllerInstances = widget.getControllerInstances();
                            Ext.each(controllerInstances, function(controller) {
                                controllers.add(Ext.getClassName(controller), controller);
                            }, this);
                        }
                    }, this);
                }
            }, this);
        }
        return controllers;
    },

    show : function() {
        // Relay all context events to workspace event bus
        this.eventBusRelayFn = function(contextId, context) {
            if (context.isObservable) {
                Ext.util.Observable.releaseCapture(context);
                Ext.util.Observable.capture(context, function() {
                    var args = Ext.toArray(arguments);
                    args[0] = (contextId + "_" + args[0]).toLowerCase();
                    this.eventBus.fireEvent.apply(this.eventBus, args);
                }, this);
            }
        };
        AppShell.ContextManager.addListener("available", this.eventBusRelayFn, this);

        var controllers = this.getControllerInstancesFromWidgets();
        controllers.each(function(controller) {
            if (controller.onWorkspaceShow) {
                controller.onWorkspaceShow({
                    eventBus : this.eventBus,
                    viewScope : this.viewScope,
                    workspaceState : this.workspaceState,
                    workspaceId : this.id
                });
            }
        }, this);
        this.onShow();
        
        Ext.Object.each(this.widgets, function(area, widgets) {
            Ext.each(widgets, function(widget){
                if (Ext.isFunction(widget.onShow)) {
                    widget.onShow();
                };
            }, this);
        }, this);
    },

    hide : function() {
        // End relaying of new context events
        AppShell.ContextManager.removeListener("available", this.eventBusRelayFn, this);

        var controllers = this.getControllerInstancesFromWidgets();
        controllers.each(function(controller) {
            if (controller.onWorkspaceHide) {
                controller.onWorkspaceHide({
                    eventBus : this.eventBus,
                    viewScope : this.viewScope,
                    workspaceState : this.workspaceState,
                    workspaceId : this.id
                });
            }
        }, this);
        this.onHide();
        
        Ext.Object.each(this.widgets, function(area, widgets) {
            Ext.each(widgets, function(widget){
                if (Ext.isFunction(widget.onHide)) {
                    widget.onHide();
                };
            }, this);
        }, this);
        
    },

    /**
     *
     * @template
     */
    onShow : Ext.emptyFn,
    /**
     *
     * @template
     */
    onHide : Ext.emptyFn,

    /**
     *@template
     */
    onCreate : Ext.emptyFn,

    /**
     *@template
     */
    onDestroy : Ext.emptyFn,

    /**
     *@template
     */
    onWidgetsInstantiated : Ext.emptyFn

    /**
     *
     * @cfg {String[]} navPath
     * Path of the workspace in the navigation Hierarchy represented as an array of string identifiers
     * 		ex) navPath: ["Performance Management", "sc_Scorecards", "sc_MyScores"]
     */

    /**
     * @cfg {Object} widgetCfg
     * A config object that contains the widgets on this page, keyed by area.
     * So far the areas are "main", "selector".
     * A special area is "optional", this should contain an array of widget names/configs
     */

    /**
     *
     * @cfg {Array} actionCfgs
     * An array of Action configs representing Additional Actions that may be present on this workspace
     *
     */

    /**
     * @property {AppShell.core.Module} module
     * The Module that defines this workspace.
     */
});

/**
 * Private utility class that serves as a popup window.
 * @private
 */
Ext.define("AppShell.view.ModalWindow", {
    extend : "Ext.window.Window",
    mixins : {
        loggable : "AppShell.core.Loggable"
    },
    
    config: {
    	/**
		 * @cfg {Boolean} [resizable=false]
		 * True to allow resizing of the window
		 */
    	resizable: false,
	    
	    /**
		 * @cfg {Boolean} [draggable=true]
		 * True to allow dragging of the window
		 */
	    draggable: true,
	    
	    /**
		 * @cfg {Boolean} [constrain=true]
		 * True to allow keep the window within the bounries of its creator component
		 */
    	constrain: true,
	    
	    /**
		 * @cfg {Boolean/Function} [ghost=false]
		 * Set to false to disable the ghost panel during dragging the window. 
		 * Do note that you should not set this to true, by default it is a function.
		 */
    	ghost: false,
	    
	    /**
		 * @cfg {Boolean} [closable=true]
		 * True to display the 'close' tool button and allow the user to close the window, 
		 * false to hide the button
		 */
	    closable: true,
	    
	    /**
	    * @cfg {String}
	    * Possible values are: 
	    * 'auto' to enable automatic horizontal scrollbar
	    * 'scroll' to always enable horizontal scrollbar 
	    * 'hidden' to never show horizontal scrollbar
	    * The default is 'auto'
	    */
	    overflowX: 'auto',
	    
	    /**
	    * @cfg {String}
	    * Possible values are: 
	    * 'auto' to enable automatic vertical scrollbar
	    * 'scroll' to always enable vertical scrollbar 
	    * 'hidden' to never show veritcal scrollbar
	    * The default is 'auto'
	    */
	    overflowY: 'auto'	    	    
    },    
       
    /**
     * @property {Boolean} [modal=true]
     * Defines the window as modal
     * @private
     */
    modal: true, 
   
    constructor: function(config) {
    	this.callParent(arguments);
        this.initConfig(config);
        this.mixins.loggable.constructor.apply(this, arguments);
				
	    if (config.component) {
	    	this.add(config.component);	    	
	    }	    	      
    }          
});
Ext.define("AppShell.view.UtilityPane", {
    extend : "Ext.container.Container",
    alias : "widget.as_utilitypane",
    layout : {
        type : "hbox",
        align : "stretch"
    },

    items : [{
        xtype : "box",
        height : 111,
        width : 64,
        style : {
            background : "url('AppShell/images/header_blue.png')"
        }
    }, {
        xtype : "box",
        height : 111,
        width : 186,
        style : {
            background : "url('AppShell/images/header_bg_blue.png')",
            "margin-right" : "5px"
        }
    }, {
        xtype : "image",
        height : 113,
        width : 6,
        src : "AppShell/images/header_bg_gray_left.png"
    }, {
        xtype : "container",
        flex: 1,
        layout: {
            type: "vbox",
            align: "stretch"
        },
        style : {
            background : "url('AppShell/images/header_graybg.png')"
        },
        items : [{
            xtype : "toolbar",
            height: 36,
            style : {
                background : "none"
            },
            layout : {
                type : "hbox",
                align : "middle"
            },
            items : [{
                xtype : "tbfill"
            }, {
                xtype : "combo",
                name : "Lang",
                id : "lang",
                allowBlank : false,
                forceSelection : true,
                autoSelect : true,
                editable : false,
                mode : "local",
                value : "en",
                store : [['en', "English"], ["de", "German"], ['te', 'Telugu']],
                fieldLabel : "Language",
                listeners : {
                    change : function(field, newLang) {
                        AppShell.i18n.Localizer.setLocale(newLang);
                    }
                }
            }, {
                xtype : "combo",
                name : "Country",
                id : "country",
                allowBlank : false,
                forceSelection : true,
                autoSelect : true,
                editable : false,
                mode : "local",
                value : "us",
                store : [['us', "US"], ["de", "Germany"], ['IN', 'India']],
                fieldLabel : "Country",
                listeners : {
                    change : function(field, country) {
                        AppShell.i18n.Localizer.setLocale(null, country);
                    }
                }
            }]
        }, {
            id : "navToolbar",
            height: 77,
            style : {
                background : "none"
            },
            xtype : "container",
            items : []
        }]
    }]

});

Ext.define("AppShell.view.Actions", {
    extend : 'Ext.container.Container',
    id : "actions",
    alias : "widget.actions",
    floating : true,
    style : {
        position : "fixed !important",
        right : "-280px",
        left : null,
        overflow : "visible"
    },
    x : null,
    y : 50,
    height : 0,
    cls : 'v-drawer',

    imgPlus : "AppShell/images/open_nav.png",
    imgOff : "AppShell/images/close_nav.png",

    imagePanelWidth : 60,
    imagePanelHeight : 59,
    menuOptionsPanelWidth : 220,
    menuOptionsPanelHeight : 280,

    border : 1,
    shadow : false,

    layout : {
        type : "absolute"
    },

    initComponent : function() {
        try {
            // When the workspace changes, close the drawer
            AppShell.ContextManager.on("available", function(contextId, context) {
                if (contextId === "wsm") {
                    context.addListener("change", function() {
                        this.closeMenu();
                    }, this);
                }
            }, this);

            this.createChildComponents();
        } catch (e) {
            Ext.log(e);
        } finally {
            this.callParent(arguments);
        }
    },

    createChildComponents : function() {
        var me = this;
        this.width = this.imagePanelWidth;

        this.items = [{
            xtype : "container",
            x : 0,
            y : 0,
            width : this.imagePanelWidth,
            height : this.imagePanelHeight,
            layout : {
                type : "vbox",
                align : "stretch"
            },
            items : [{
                xtype : "image",
                itemId : "additionalActionsPlusImage",
                src : this.imgPlus,
                width : this.imagePanelWidth,
                height : this.imagePanelHeight,
                listeners : {
                    afterrender : function() {
                        this.getEl().on("click", me.onCollapseExpandMenu, me);
                    }
                },
                style : {
                    cursor : "pointer"
                }
            }]
        }, {
            xtype : "container",
            itemId : "additionalActionsMenuContainer",
            x : this.imagePanelWidth / 2,
            y : this.imagePanelHeight - 5,
            cls : "additionalActionsMenuContainer",
            flex : 1,
            height : this.menuOptionsPanelHeight,
            layout : {
                type : "vbox",
                align : "stretch"
            },
            shadow : true
        }, {
            xtype : 'container',
            cls : 'v-drawer-header-padding',
            border : 0,
            height : this.imagePanelHeight / 2,
            x : this.imagePanelWidth,
            y : this.imagePanelHeight / 2
        }];
        this.setWidth(this.imagePanelWidth + this.menuOptionsPanelWidth);
    },

    addMenuOptions : function(workspace) {

        var menu = Ext.create('Ext.menu.Menu', {
            floating : false,
            width : 50,
            listeners : {
                click : Ext.bind(this.onMenuClick, this)
            },
            flex : 1,
            cls : 'v-drawer-menu'
        });

        if (workspace) {
            Ext.each(workspace.actions, function(action, index, actions) {
                menu.add(Ext.create('Ext.menu.Item', action));
            }, this);
        }

        var menuContainer = this.down("[itemId=additionalActionsMenuContainer]");
        if (menuContainer !== null) {
            menuContainer.removeAll();
            menuContainer.add({
                xtype : 'container',
                cls : 'v-drawer-header',
                items : [{
                    xtype : 'component',
                    cls : 'v-drawer-header-text',
                    bundleName : 'com.verint.web.core.appshell.l10n.AppShellBundle',
                    i18nCfg : {
                        title : "ADDITIONAL ACTIONS"
                    },

                    setTitle : function(newTitle) {
                        this.update(newTitle);
                    }
                }]
            });
            menuContainer.add(menu);
            menuContainer.doLayout();
        }

        this.slideMenuContainer();
    },

    onMenuClick : function(menu, item, e) {
        if (item) {
            this.onCollapseExpandMenu();
            //only close the drawer when an item is clicked
        }
    },

    closeMenu : function() {
        this.isMenuPanelVisible = false;
        this.slideMenuContainer();
    },

    onCollapseExpandMenu : function() {
        this.isMenuPanelVisible = !this.isMenuPanelVisible;
        this.slideMenuContainer();
    },

    slideMenuContainer : function() {
        var image = this.down("[itemId=additionalActionsPlusImage]");
        if (image) {
            var imgEl = image.getEl();
            if (imgEl && imgEl.dom) {
                imgEl.dom.src = this.isMenuPanelVisible ? this.imgOff : this.imgPlus;
            }
        }
        var menu = this.down("menu");
        var collapseMargin = (menu && this.down("menu").items.items.length) > 0 ? 30 : 60;
        var menuContainer = this.getEl();
        if (menuContainer) {
            menuContainer.stopAnimation();
            menuContainer.animate({
                duration : 400,
                to : {
                    right : this.isMenuPanelVisible ? 20 : -(this.menuOptionsPanelWidth + collapseMargin)
                }
            });
        }
    }
});

Ext.define("AppShell.view.Viewport", {
    extend : "Ext.container.Viewport",
    id : "viewport",
    layout : {
        type : "vbox",
        align : "stretch"
    },
    requires : ["AppShell.view.UtilityPane", "AppShell.view.Actions"],
    items : [{
        xtype : "as_utilitypane"
    }, {
        id : "workspaceContainer",
        xtype : "container",
        layout : {
            type : "hbox",
            align : "stretch"
        },
        flex : 1,
        items : [{
            id : "selectorContent",
            xtype : "container",
            width : 250,
            layout : "fit",
            autoScroll : false,
            items : [],
            padding : "10 0 10 10"
        }, {
            title : "content title",
            id : "mainContent",
            xtype : "container",
            layout : "fit",
            autoScroll : false,
            items : [],
            padding : 10,
            flex : 1
        }, {
            xtype : "actions"
        }]
    }]
});

Ext.define("AppShell.controller.Viewport", {
    extend : "Ext.app.Controller",
    views : ["Viewport"],
    uses : ["AppShell.WorkspaceManager"],
    mixins : {
        loggable : "AppShell.core.Loggable"
    },
    constructor : function() {
        this.callParent(arguments);
        this.mixins.loggable.constructor.apply(this, arguments);
    },
    onLaunch : function() {
        this.callParent(arguments);

        // Add some event listeners to the locale context so that we can update teh dropdowns
        // when loading from a URL
        AppShell.ContextManager.addListener("available", function(contextId, context) {
            if (contextId === "locale") {
                Ext.getCmp("lang").setValue(context.getLocale().languageCode);
                Ext.getCmp("country").setValue(context.getLocale().countryCode);

                context.addListener("localechange", function(lang, country, variant) {
                    Ext.getCmp("lang").setValue(lang);
                    Ext.getCmp("country").setValue(country);
                }, this);
            }
        }, this);

        var actions = this.getActions();        
       
        if (actions) {
        	
        	actions.show();
            var ws = AppShell.WorkspaceManager.getCurrentWorkspace();
            if (ws) {
            	if (ws.actions){
                actions.addMenuOptions(ws);
               
               }
            }
            
           //	console.log("Viewport.js: Actions found.");
            AppShell.WorkspaceManager.addListener("change", actions.addMenuOptions, actions); 
        } else {
            console.error("Viewport.js: Actions panel not found.");
        }
    },

    refs : [{
        ref : "actions",
        selector : "#actions"
    }]
});

Ext.Loader.setConfig({
    enabled : true
});

Ext.require(["Ext.state.Manager", "Ext.state.LocalStorageProvider"], function() {
    Ext.state.Manager.setProvider(Ext.create("Ext.state.LocalStorageProvider", {
        prefix : "Verint I360 "
    }));
});

Ext.BLANK_IMAGE_URL = "extjs4/resources/themes/images/default/tree/s.gif";

// Check to see if we are to only load certain modules.
if (window.location.search.length > 1) {
    var params = Ext.urlDecode(window.location.search.substring(1));
    if (params && params.modules) {
        var moduleJSON = "{modules: [";
        var isFirst = true;
        Ext.each(params.modules.split(","), function(moduleName) {
            if (!isFirst) {
                moduleJSON += ",";
            } else {
                isFirst = false;
            }
            moduleJSON += '{name: "' + moduleName + '"}';
        }, this);
        moduleJSON += "]}";
        var moduleStore = Ext.create("AppShell.store.Modules", {
            proxy : {
                type : "memory",
                data : eval(moduleJSON)
            }
        });
    }
}

Ext.Ajax.on('requestexception', function(con, response, op, e){
  if(response.status === 401){
    window.location = '../control/signin';
  }
});

Ext.application({
    name : "AppShell",
    appFolder : "AppShell",
    autoCreateViewport : true,
    controllers : ["Viewport"],
    views : ["Viewport"],
    stores : ["Modules"],
    requires : ["AppShell.util.AppShellUtils", "AppShell.ContextManager", "AppShell.security.SecurityContext", "AppShell.security.SecurityManager", "AppShell.i18n.Localizer", "AppShell.core.Module", "AppShell.core.Workspace", "AppShell.core.Widget", "AppShell.WorkspaceManager", "AppShell.i18n.Localizable"],
    launch : function() {
        // Initialize AppShell services
        AppShell.app = this;
        AppShell.core.Module.prototype.application = this;
        AppShell.core.Workspace.prototype.application = this;
        AppShell.core.Widget.prototype.application = this;
        
        AppShell.i18n.Localizer.registerI18nService("com.verint.web.core.appshell.l10n", {
            url: AppShell.deploymentInfo.wfoRestPrefix + 'loc/get',
            mockUrl: 'AppShell/data/ResourceBundles.json'
        });

        // Set security context
        Ext.Ajax.request({
            url : AppShell.deploymentInfo.useMockData ? "AppShell/data/security-context.json" : AppShell.deploymentInfo.wfoRestPrefix + "security/user",
            method : "GET",
            success : function(response, options) {
                var sec = Ext.JSON.decode(response.responseText, true)
                if (sec) {
                    Ext.create("AppShell.security.SecurityContext", sec.SecurityContext);
                }
                this.loadModules();
            },
            failure: function(response, options) {
               AppShell.util.Notifier.error("Could not load your privileges and licenses."); 
               AppShell.logger.error("Could not load security context from server.");
            },
            scope : this
        });

    },
    loadModules : function(modulesArray) {
        if (!modulesArray) {
            // Load Modules
            var moduleStore = Ext.getStore("Modules");
            moduleStore.load({
                scope : this,
                callback : function() {
                    this.loadModules(moduleStore.getRange());
                }
            });
            return;
        }

        var app = this;

        var modules = new Ext.util.MixedCollection();

        var modulesToLoad = new Ext.util.MixedCollection();
        modulesToLoad.addAll(modulesArray);

        while (modulesToLoad.getCount() > 0) {
            // Module model
            var record = modulesToLoad.removeAt(0);

            var name = record.get("name");

            // Set the loader so that anything under the module folder is loaded.
            var loaderPaths = {};
            loaderPaths[name] = name;
            Ext.Loader.setConfig({
                paths : loaderPaths
            });

            // Load up the module controller
            try {
                var module = Ext.create(name + "." + name);
                if (AppShell.security.SecurityManager.hasLicenses(module.licenses) && AppShell.security.SecurityManager.hasPrivileges(module.privileges)) {
                    modules.add(module);
                }
            } catch (e) {
                AppShell.logger.error("Could not load module: " + name + ". Error was: " + e);
            }
        }

        // Load bundle configs
        modules.each(function(module, index, length) {
            if (module.i18nService) {
                var i18nService = module.i18nService;
                if (!Ext.isArray(i18nService)) {
                    i18nService = [i18nService];
                }
                
                Ext.each(i18nService, function(i18nService) {
                    var namespace = i18nService.namespace;
                    if (!namespace) {
                        var className = Ext.getClassName(module);
                        if (className.indexOf(".") > 0) {
                            namespace= className.substring(className.indexOf(".") + 1)
                        }
                    }
                    if (namespace) {
                        AppShell.i18n.Localizer.registerI18nService(namespace, i18nService);
                    }
                }, this);
            }
        });
        
        
        // Load up module's css
        modules.each(function(module, index, length) {
            if (module.requiresCss) {
                var cssFiles = module.requiresCss;
                if (Ext.isString(cssFiles)) {
                    cssFiles = [cssFiles];
                }
                if (Ext.isArray(cssFiles)) {
                    if (cssFiles.length > 1) {
                        AppShell.logger.warn("Modules should only specify one concatenated css file");
                    }
                    Ext.each(cssFiles, function(cssUrl) {
                        AppShell.loadCss(cssUrl);
                    });
                }
            }
        });
        

        // Init
        modules.each(function(module, index, length) {
            if (module.init)
                module.init(this);
        });

        // Load Workspaces
        this.loadWorkspaces(modules);

        // Load contexts provided
        modules.each(function(module, index, length) {
            if (module.contexts) {
                for (var contextKey in module.contexts) {
                    var contextDef = module.contexts[contextKey];
                    if ( typeof (contextDef) === "string") {
                        var context = Ext.create(contextDef);
                        if (context) {
                            AppShell.ContextManager.addContext(contextKey, context);
                        }
                    }
                }
            }
        });
        
        AppShell.ContextManager.handleHistoryChange();

        // Launch
        modules.each(function(module, index, length) {
            if (module.onLaunch)
                module.onLaunch(this);
        });
    },

    /**
     * @private
     * @param {Object} modules
     */
    loadWorkspaces : function(modules) {
        AppShell.WorkspaceManager.registerWorkspaces(modules);
        modules.each(function(module, index, length) {
            if (module.wsCfgs) {
                var toolbar = Ext.getCmp("navToolbar");

                Ext.each(module.wsCfgs, function(wsCfg) {
                    if (AppShell.security.SecurityManager.hasLicenses(wsCfg.licenses) && AppShell.security.SecurityManager.hasPrivileges(wsCfg.privileges)) {
                        var navPath = AppShell.WorkspaceManager.getNavPath(wsCfg, module);
                        if (navPath) {
                            toolbar.add(Ext.widget("button", {
                                text : navPath[navPath.length - 1],
                                handler : Ext.bind(AppShell.WorkspaceManager.showWorkspaceCfg, AppShell.WorkspaceManager, [wsCfg, module])

                            }));
                        }
                    }
                });

            }
        }, this);
    }
});

// Just define AppShell.AppShell so we can use Ext.require for loading this file
Ext.define("AppShell.AppShell", {});


